{
  description = "CUDA devShell on Linux, cross-platform tooling shell on macOS (allow all unfree)";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
  };

  outputs =
    { self, nixpkgs }:
    let
      lib = nixpkgs.lib;

      systems = [
        "x86_64-linux"
        "aarch64-linux"
        "aarch64-darwin"
        "x86_64-darwin"
      ];

      forAllSystems = lib.genAttrs systems;

      isLinux = lib.hasSuffix "linux";

      pkgsFor =
        system:
        import nixpkgs {
          inherit system;
          config = {
            allowUnfree = true;
          }
          // lib.optionalAttrs (isLinux system) {
            cudaSupport = true;
            cudaVersion = "13";
          };
        };

      perftestFor =
        pkgs:
        pkgs.callPackage ./perftest.nix {
          cudaPackages = pkgs.cudaPackages;
          perftestSrc = builtins.path {
            path = "${builtins.getEnv "PWD"}/tools/perftest";
            name = "perftest-source";
          };
        };

      astraSimSrc = builtins.path {
        path = "${builtins.getEnv "PWD"}/tools/astra-sim";
        name = "astra-sim-source";
        filter =
          path: type:
          baseNameOf path != ".git"
          && !(lib.hasSuffix "/extern/network_backend/ns-3" path)
          && !(lib.hasSuffix "/extern/network_backend/csg-htsim" path);
      };

      astrasimFor =
        pkgs:
        pkgs.callPackage ./astrasim.nix {
          protobuf = pkgs.protobuf_29;
          inherit astraSimSrc;
        };

      chakraSrc = builtins.path {
        path = "${builtins.getEnv "PWD"}/tools/astra-sim/extern/graph_frontend/chakra";
        name = "chakra-source";
        filter = path: type: baseNameOf path != ".git";
      };

      chakraFor =
        pkgs:
        pkgs.python3Packages.callPackage ./chakra.nix {
          protobuf = pkgs.protobuf;
          protobufPython = pkgs.python3Packages.protobuf;
          inherit chakraSrc;
        };
    in
    {
      devShells = forAllSystems (
        system:
        let
          pkgs = pkgsFor system;
          linux = isLinux system;
          perftest = perftestFor pkgs;
          astrasim = astrasimFor pkgs;
          chakra = chakraFor pkgs;
          qemu = pkgs.qemu.overrideAttrs {
            version = "10.1.5";
            src = pkgs.fetchurl {
              url = "https://download.qemu.org/qemu-10.1.5.tar.xz";
              hash = "sha256-HxIJtNuC5sRBfq9ufgsHNWNXKgQtn7dJKwhLplqcBpM=";
            };
          };
        in
        {
          default = pkgs.mkShell rec {
            buildInputs =
              # Cross-platform toolchain, editors/LSPs, Rust and Python stack.
              (with pkgs; [
                gnumake
                cmake
                ninja
                clang-tools
                pkg-config
                bear
                fzf
                openssl
                bc
                gmp
                libmpc
                mpfr
                graphviz

                nixd
                nixfmt
                statix

                rustc
                cargo
                rustfmt
                clippy
                rust-analyzer

                (python3.withPackages (
                  ps:
                  (with ps; [
                    matplotlib
                    seaborn
                    psutil
                    pandas
                    numpy
                    protobuf
                    sympy
                    graphviz
                    tqdm
                  ])
                  ++ [ chakra ]
                ))
                yq

                typst
                imagemagick
                ghostscript
                d2
                libertine
                libertinus
              ])
              # astram sim binary
              ++ [ astrasim ]
              # linux only packages
              ++ lib.optionals linux (
                with pkgs;
                [
                  gcc
                  gdb
                  linuxHeaders
                  elfutils

                  cudaPackages.cudatoolkit
                  cudaPackages.cudnn
                  cudaPackages.cuda_nvcc
                  cudaPackages.cuda_cudart
                  cudaPackages.nvidia_fs
                  cudaPackages.gdrcopy

                  libguestfs-with-appliance
                  guestfs-tools
                  qemu

                  rdma-core
                  autoconf
                  automake
                  libtool
                  pciutils
                  dpdk
                  numactl
                  perftest
                ]
              )
              # macos extras
              ++ lib.optionals (!linux) (
                with pkgs;
                [
                  lldb
                ]
              );

            shellHook = ''
              export RUST_SRC_PATH=${pkgs.rustPlatform.rustLibSrc}
              export PATH="$PWD/bin:$PATH"
              # Bundled fonts so Typst renders Libertine instead of falling back.
              export TYPST_FONT_PATHS="${pkgs.libertine}/share/fonts:${pkgs.libertinus}/share/fonts"
            ''
            + lib.optionalString linux ''
              export QEMU_SYSTEM=${qemu}/bin/qemu-system-x86_64
              export CUDA_PATH=${pkgs.cudatoolkit}
              export CUDA_H_PATH=${pkgs.cudatoolkit}/include/cuda.h
              export CPPFLAGS="-I${pkgs.cudatoolkit}/include $CPPFLAGS"

              # Set CC to GCC 13 to avoid the version mismatch error
              export CC=${pkgs.gcc13}/bin/gcc
              export CXX=${pkgs.gcc13}/bin/g++
              export PATH=${pkgs.gcc13}/bin:$PATH

              # Add necessary paths for dynamic linking
              export LD_LIBRARY_PATH=${
                lib.makeLibraryPath (
                  [
                    "/run/opengl-driver" # Needed to find libGL.so
                  ]
                  ++ buildInputs
                )
              }:$LD_LIBRARY_PATH

              # Set LIBRARY_PATH to help the linker find the CUDA static libraries
              export LIBRARY_PATH=${
                lib.makeLibraryPath [
                  pkgs.cudatoolkit
                  pkgs.cudaPackages.cuda_cudart
                ]
              }:$LIBRARY_PATH
            '';
          };
        }
      );
    };
}
