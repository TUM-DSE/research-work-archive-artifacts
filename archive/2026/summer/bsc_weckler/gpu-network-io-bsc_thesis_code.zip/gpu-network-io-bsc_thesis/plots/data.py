# Schema-aware data access. Everything (paths, dtypes, labels, units, value order,
# baseline filters) comes from plots/schema.json — never hard-code any of it elsewhere.

import json
from functools import cache
from pathlib import Path

import pandas as pd

PLOTS_DIR = Path(__file__).resolve().parent
ROOT = PLOTS_DIR.parent

_DTYPES = {"string": "str", "integer": "int64", "float": "float64", "bool": "bool"}


@cache
def schema() -> dict:
    with open(PLOTS_DIR / "schema.json") as f:
        return json.load(f)


def dataset(dataset_id: str) -> dict:
    datasets = schema()["datasets"]
    if dataset_id not in datasets:
        raise KeyError(f"unknown dataset '{dataset_id}' — available: {', '.join(datasets)}")
    return datasets[dataset_id]


def column(dataset_id: str, name: str) -> dict:
    for col in dataset(dataset_id)["columns"]:
        if col["name"] == name:
            return col
    raise KeyError(f"dataset '{dataset_id}' has no column '{name}'")


def label(dataset_id: str, name: str, value=None) -> str:
    col = column(dataset_id, name)
    if value is None:
        return col["label"]
    entry = value_meta(dataset_id, name, value)
    if entry is not None:
        return entry["label"]
    return str(value)


def value_meta(dataset_id: str, name: str, value) -> dict | None:
    for entry in column(dataset_id, name).get("values", []):
        if entry["value"] == value:
            return entry
    return None


def style_tokens(dataset_id: str, name: str, value) -> tuple[str, ...]:
    entry = value_meta(dataset_id, name, value)
    return tuple(entry.get("style", ())) if entry else ()


def axis_label(dataset_id: str, name: str) -> str:
    col = column(dataset_id, name)
    return f"{col['label']} [{col['unit']}]" if "unit" in col else col["label"]


def levels(dataset_id: str, name: str, df: pd.DataFrame | None = None) -> list:
    values = [entry["value"] for entry in column(dataset_id, name).get("values", [])]
    if values:
        return values
    return sorted(df[name].unique()) if df is not None else []


def better(dataset_id: str, name: str) -> str | None:
    return column(dataset_id, name).get("better")


def fmt_size(n: int) -> str:
    for shift, suffix in ((30, "GiB"), (20, "MiB"), (10, "KiB")):
        if n >= 1 << shift:
            return f"{n >> shift}{suffix}"
    return f"{n}B"


def load(dataset_id: str, raw: bool = False) -> pd.DataFrame:
    ds = dataset(dataset_id)
    path = ROOT / ds["path"]
    dtypes = {c["name"]: _DTYPES[c["type"]] for c in ds["columns"] if c["type"] != "datetime"}
    datetimes = [c["name"] for c in ds["columns"] if c["type"] == "datetime"]

    if not path.is_file():
        return pd.DataFrame({c["name"]: pd.Series(dtype=dtypes.get(c["name"], "object"))
                             for c in ds["columns"]})

    df = pd.read_csv(path, dtype=dtypes, parse_dates=datetimes)
    expected = [c["name"] for c in ds["columns"]]
    if list(df.columns) != expected:
        raise ValueError(f"{path} does not match schema for {dataset_id}:\n"
                         f"  expected: {expected}\n  found:    {list(df.columns)}")

    if not raw:
        for name, value in ds.get("baseline_filter", {}).items():
            df = df[df[name] == value]
    return df.reset_index(drop=True)
