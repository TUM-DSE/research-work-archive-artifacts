# Chair paper styling — figure geometry, fonts, palettes. Do not change values;
# they define the look shared across the chair's papers.

from dataclasses import dataclass, fields, replace
from typing import Iterable

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Standard axis dimensions (inches)
AX_WIDTH = 1.85
AX_WIDTH_WIDE = 2.8
AX_HEIGHT = 1.15 * 0.75
AX_LEFT_MARGIN = 0.4
AX_RIGHT_MARGIN = 0.05
AX_TOP_MARGIN = 0.65
AX_BOTTOM_MARGIN = 0.5

TITLE_FONTSIZE = 6
AXIS_LABEL_FONTSIZE = 6
TICKS_FONTSIZE = 5
LEGEND_FONTSIZE = 6
ANNOTATION_SIZE = 4
LEGEND_BBOX_HEIGHT = 1.2
LEGEND_ALIGN = "lower center"

PALETTE_REGULAR = sns.color_palette("deep")
VALIDATION_MODEL_TINT = 0.22

HATCHES = ["", "//", "\\\\", "..", "xx"] * 3
MARKERS = ["o", "s", "^", "D", "v", "*", "P"] * 3


@dataclass(frozen=True)
class SeriesStyle:
    color: object | None = None
    color_slot: int | None = None
    palette: str | None = None
    marker: str | None = None
    linestyle: str | None = None
    hatch: str | None = None


# Tokens describe semantic identity; palette entries remain local to the plotting
# layer. Namespaces deliberately reuse the chair palette when they cannot appear as
# competing series (for example, datapaths and collective algorithms).
_STYLE_TOKENS = {
    # End-to-end paths and designs.
    "path_gpu_direct": SeriesStyle(color_slot=0, marker="o"),
    "path_cpu_bounce": SeriesStyle(color_slot=1, marker="s"),
    "path_design1": SeriesStyle(color_slot=2),
    "path_design2": SeriesStyle(color_slot=3, marker="D"),
    "path_sealed_bounce": SeriesStyle(color_slot=4, marker="P"),
    "path_vm_gpu_bounce": SeriesStyle(color_slot=5, marker="D"),
    "path_host_ram": SeriesStyle(color_slot=7),
    "variant_single": SeriesStyle(marker="v"),
    "variant_e2e": SeriesStyle(marker="^", palette="regular"),
    "variant_vm": SeriesStyle(marker="o", palette="regular"),
    "variant_cvm": SeriesStyle(marker="s"),

    # How a value was obtained. This composes with a path identity.
    "source_measured": SeriesStyle(linestyle="-", palette="regular"),
    "source_modeled": SeriesStyle(linestyle="--"),
    "source_proxy": SeriesStyle(linestyle=":", palette="regular"),

    # Logical collective algorithms form an independent palette namespace.
    "algorithm_ring": SeriesStyle(
        color_slot=0, marker="o", linestyle="-"
    ),
    "algorithm_direct": SeriesStyle(
        color_slot=1, marker="s", linestyle="--"
    ),
    "algorithm_halving_doubling": SeriesStyle(
        color_slot=2, marker="^", linestyle=":"
    ),
    "algorithm_double_binary_tree": SeriesStyle(
        color_slot=3, marker="D", linestyle="-."
    ),

    # GPU-copy backend is the primary identity; VM/CVM is a marker variant.
    "copy_cuda": SeriesStyle(color_slot=0, marker="o"),
    "copy_ce": SeriesStyle(color_slot=1, marker="s"),
    "copy_nvbandwidth": SeriesStyle(color_slot=2, marker="^"),
    "copy_cpr_non_cpr": SeriesStyle(color_slot=3, marker="D"),
    "copy_cpu_crypto": SeriesStyle(color_slot=3, marker="D"),
    "copy_env_vm": SeriesStyle(marker="o", linestyle="-", palette="regular"),
    "copy_env_cvm": SeriesStyle(marker="s", linestyle="-"),

    # Environment is the primary identity in the latency-split comparison.
    "environment_vm": SeriesStyle(color_slot=0),
    "environment_cvm": SeriesStyle(color_slot=1),

    # Fixed-latency comparisons use direction colors so D2H/H2D do not inherit
    # GPUDirect's blue merely because both paths use cudaMemcpy.
    "fixed_d2h": SeriesStyle(color_slot=2),
    "fixed_h2d": SeriesStyle(color_slot=4),

    # Components use hatching when rendered as stacked bars.
    "component_total": SeriesStyle(hatch=""),
    "component_crypto": SeriesStyle(hatch="xx"),
    "component_command": SeriesStyle(hatch="", palette="regular"),
    "component_copy": SeriesStyle(hatch="//"),
}


def resolve(tokens: Iterable[str] = (), fallback_index: int = 0) -> SeriesStyle:
    """Compose schema style tokens over a deterministic palette fallback."""
    resolved = SeriesStyle(
        color_slot=fallback_index % len(PALETTE_REGULAR),
        palette="regular",
        marker=MARKERS[fallback_index % len(MARKERS)],
        linestyle="-",
        hatch="",
    )
    values = {field.name: getattr(resolved, field.name) for field in fields(SeriesStyle)}
    for token in tokens:
        if token not in _STYLE_TOKENS:
            raise KeyError(f"unknown plot style token: {token}")
        token_style = _STYLE_TOKENS[token]
        for field in fields(SeriesStyle):
            value = getattr(token_style, field.name)
            if value is not None:
                values[field.name] = value
    if values["color"] is None:
        if values["palette"] not in (None, "regular"):
            raise ValueError(f"unsupported global palette: {values['palette']}")
        values["color"] = PALETTE_REGULAR[values["color_slot"] % len(PALETTE_REGULAR)]
    return SeriesStyle(**values)


def validation_model_style(tokens: Iterable[str] = (), fallback_index: int = 0) -> SeriesStyle:
    """Resolve a model series with a restrained tint for paired validation plots.

    Validation plots compare a model against the measurement that parameterized or
    motivates it. A lightened version of the same base hue makes that pairing
    visible while the dashed line remains the primary measured/model distinction.
    Other figures should use ``resolve`` so that pale colors do not become a
    global semantic encoding.
    """
    series_style = resolve(tokens, fallback_index=fallback_index)
    if series_style.color is None:
        return series_style
    color = tuple(float(channel) + VALIDATION_MODEL_TINT * (1.0 - float(channel))
                  for channel in series_style.color[:3])
    return replace(series_style, color=color)

LINE_WIDTH = 1.0
MARKER_SIZE = 2.0
ERROR_BAR_CAP_SIZE = 1.0
ERROR_BAR_LINE_WIDTH = 0.4
GRID_LINE_WIDTH = 0.5
GRID_ALPHA = 0.7
BORDER_LINE_WIDTH = 0.6

LOWER_BETTER_TITLE = "Lower is better ↓"
HIGHER_BETTER_TITLE = "Higher is better ↑"


def apply_mpl_settings():
    mpl.use("Agg")
    mpl.rcParams["text.latex.preamble"] = r"\usepackage{amsmath}"
    mpl.rcParams["pdf.fonttype"] = 42
    mpl.rcParams["ps.fonttype"] = 42
    mpl.rcParams["font.family"] = "libertine"

    sns.set_style("whitegrid")
    sns.set_style("ticks", {"xtick.major.size": 8, "ytick.major.size": 8})
    sns.set_context("paper", rc={"font.size": 5, "axes.titlesize": 5, "axes.labelsize": 8})


def create_standardized_plot(ax_width=AX_WIDTH, ax_height=AX_HEIGHT,
                             left_margin=AX_LEFT_MARGIN, right_margin=AX_RIGHT_MARGIN,
                             top_margin=AX_TOP_MARGIN, bottom_margin=AX_BOTTOM_MARGIN):
    fig_width = ax_width + left_margin + right_margin
    fig_height = ax_height + top_margin + bottom_margin

    fig = plt.figure(figsize=(fig_width, fig_height))
    ax = fig.add_axes([
        left_margin / fig_width,
        bottom_margin / fig_height,
        ax_width / fig_width,
        ax_height / fig_height,
    ])
    return fig, ax


def create_standardized_subplots(nrows=1, ncols=2, ax_width=AX_WIDTH, ax_height=AX_HEIGHT,
                                 left_margin=AX_LEFT_MARGIN, right_margin=AX_RIGHT_MARGIN,
                                 top_margin=AX_TOP_MARGIN, bottom_margin=AX_BOTTOM_MARGIN,
                                 wspace=0.4, hspace=0.3):
    fig_width = left_margin + (ax_width * ncols) + (wspace * ax_width * (ncols - 1)) + right_margin
    fig_height = bottom_margin + (ax_height * nrows) + (hspace * ax_height * (nrows - 1)) + top_margin

    fig = plt.figure(figsize=(fig_width, fig_height))
    plt.subplots_adjust(
        left=left_margin / fig_width,
        bottom=bottom_margin / fig_height,
        right=1 - (right_margin / fig_width),
        top=1 - (top_margin / fig_height),
        wspace=wspace,
        hspace=hspace,
    )

    axes = [fig.add_subplot(nrows, ncols, i) for i in range(1, nrows * ncols + 1)]
    if nrows > 1 and ncols > 1:
        axes = np.array(axes).reshape(nrows, ncols)

    for ax in np.array(axes).flatten():
        ax.tick_params(axis="both", which="major", labelsize=TICKS_FONTSIZE, pad=3,
                       length=2.5, width=BORDER_LINE_WIDTH, direction="in")
        ax.tick_params(axis="both", which="minor", labelsize=TICKS_FONTSIZE, length=1.5, width=0.4, direction="in")
        ax.grid(True, linestyle="--", alpha=GRID_ALPHA, linewidth=GRID_LINE_WIDTH)
        for spine in ax.spines.values():
            spine.set_linewidth(BORDER_LINE_WIDTH)

    return fig, axes


def apply_consistent_style(ax, title=None, xlabel=None, ylabel=None, grid=True):
    if title:
        ax.set_title(title, fontsize=TITLE_FONTSIZE, pad=3, color="navy")
    ax.set_xlabel(xlabel or "", fontsize=AXIS_LABEL_FONTSIZE)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=AXIS_LABEL_FONTSIZE)

    ax.tick_params(axis="both", which="major", labelsize=TICKS_FONTSIZE, pad=3,
                   length=2.5, width=BORDER_LINE_WIDTH, direction="in")
    ax.tick_params(axis="both", which="minor", labelsize=TICKS_FONTSIZE, length=1.5, width=0.4, direction="in")

    if grid:
        ax.grid(True, linestyle="--", alpha=GRID_ALPHA, linewidth=GRID_LINE_WIDTH)

    for spine in ax.spines.values():
        spine.set_linewidth(BORDER_LINE_WIDTH)


apply_mpl_settings()
