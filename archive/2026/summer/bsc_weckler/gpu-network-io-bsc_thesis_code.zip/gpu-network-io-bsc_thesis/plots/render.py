# Renders every Figure spec to plots/output/<group>/<name>.png under the chair style.
#
#   python plots/render.py              # all figures (output/ is rebuilt)
#   python plots/render.py bw_read ...  # named figures only

import shutil
import sys
from math import ceil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import ticker

import data
import style
from figures import FIGURES, Figure

# Bandwidth columns are stored in MiB/s; plots display GB/s to match the paper's numbers.
MIBPS_TO_GBPS = 2**20 / 1e9

OUTPUT = Path(__file__).resolve().parent / "output"
PAPER_ASSETS = Path(__file__).resolve().parent.parent / "paper" / "assets" / "benchmarks"

_BETTER_TITLES = {"higher": style.HIGHER_BETTER_TITLE, "lower": style.LOWER_BETTER_TITLE}


def render(spec: Figure):
    if spec.draw:
        return spec.draw(spec)

    df = data.load(spec.dataset)
    if spec.transform is not None:
        df = spec.transform(df)
    for name, value in spec.filter.items():
        df = df[df[name].isin(value)] if isinstance(value, (list, tuple)) else df[df[name] == value]
    if df.empty:
        return None

    if spec.facet_row or spec.facet_col:
        return _facet_matrix(spec, df)
    if spec.facet:
        return _facet_grid(spec, df)

    fig, ax = style.create_standardized_plot(
        ax_width=style.AX_WIDTH_WIDE if spec.wide else style.AX_WIDTH
    )
    _draw_axis(ax, spec, df, title=_title(spec))
    legend = ax.legend(loc=style.LEGEND_ALIGN, bbox_to_anchor=(0.5, style.LEGEND_BBOX_HEIGHT),
                       frameon=True, fontsize=style.LEGEND_FONTSIZE, ncols=2)
    legend.get_frame().set_edgecolor("black")
    return fig


def _facet_grid(spec: Figure, df):
    facets = [v for v in data.levels(spec.dataset, spec.facet, df) if (df[spec.facet] == v).any()]
    ncols = 2 if len(facets) == 4 else min(3, len(facets))
    nrows = ceil(len(facets) / ncols)
    # Facets keep their own (rotated) tick labels — their x ranges differ — so rows
    # need enough spacing for labels of one row plus the title of the next.
    fig, axes = style.create_standardized_subplots(
        nrows=nrows, ncols=ncols,
        ax_width=style.AX_WIDTH_WIDE if spec.wide else style.AX_WIDTH,
        top_margin=0.8, hspace=1.0,
    )
    axes = np.asarray(axes).ravel()

    for ax, facet_value in zip(axes, facets):
        _draw_axis(
            ax,
            spec,
            df[df[spec.facet] == facet_value],
            title=_facet_title(spec, facet_value),
            context={spec.facet: facet_value},
        )
    for ax in axes[len(facets):]:
        ax.set_visible(False)

    legend = axes[0].legend(frameon=True, fontsize=style.LEGEND_FONTSIZE - 1, loc="best")
    legend.get_frame().set_edgecolor("black")
    fig.suptitle(_title(spec), fontsize=style.TITLE_FONTSIZE + 1, color="navy")
    return fig


def _facet_matrix(spec: Figure, df):
    rows = [v for v in data.levels(spec.dataset, spec.facet_row, df) if (df[spec.facet_row] == v).any()]
    cols = [v for v in data.levels(spec.dataset, spec.facet_col, df) if (df[spec.facet_col] == v).any()]
    fig, axes = style.create_standardized_subplots(
        nrows=len(rows), ncols=len(cols),
        ax_width=style.AX_WIDTH_WIDE if spec.wide else style.AX_WIDTH,
        left_margin=0.6, top_margin=0.8, hspace=1.0,
    )
    axes = np.asarray(axes).reshape(len(rows), len(cols))

    for r, row_value in enumerate(rows):
        for c, col_value in enumerate(cols):
            ax = axes[r][c]
            cell = df[(df[spec.facet_row] == row_value) & (df[spec.facet_col] == col_value)]
            if cell.empty:
                ax.set_visible(False)
                continue
            _draw_axis(ax, spec, cell,
                       title=data.label(spec.dataset, spec.facet_col, col_value) if r == 0 else None,
                       context={spec.facet_row: row_value, spec.facet_col: col_value})
            if c == 0:
                row_label = data.label(spec.dataset, spec.facet_row, row_value)
                ax.set_ylabel(f"{row_label}\n{_axis_label(spec, spec.y)}",
                              fontsize=style.AXIS_LABEL_FONTSIZE)

    first_visible = next(ax for ax in axes.ravel() if ax.get_visible())
    legend = first_visible.legend(frameon=True, fontsize=style.LEGEND_FONTSIZE - 1, loc="best")
    legend.get_frame().set_edgecolor("black")
    fig.suptitle(_title(spec), fontsize=style.TITLE_FONTSIZE + 1, color="navy")
    return fig


def _draw_axis(ax, spec: Figure, df, title, context: dict | None = None):
    context = context or {}
    all_levels = data.levels(spec.dataset, spec.series, df) if spec.series else []
    plotted = spec.series_order or all_levels or [None]
    if spec.series:
        df = df[df[spec.series].isin(plotted)]

    x_values = sorted(df[spec.x].unique())
    positions = {value: i for i, value in enumerate(x_values)}
    y_scale, y_unit = _y_display(spec)

    for value in plotted:
        sub = df if value is None else df[df[spec.series] == value]
        if sub.empty:
            continue
        sub = sub.sort_values(spec.x)
        color_index = all_levels.index(value) if value in all_levels else 0
        style_values = dict(context)
        if spec.series:
            style_values[spec.series] = value
        style_columns = spec.style_by or ((spec.series,) if spec.series else ())
        tokens = spec.series_style_tokens.get(value)
        if tokens is None:
            tokens = tuple(
                token
                for column in style_columns
                if column in style_values
                for token in data.style_tokens(spec.dataset, column, style_values[column])
            )
        series_style = style.resolve(tokens, fallback_index=color_index)
        ax.plot(
            [positions[v] for v in sub[spec.x]],
            sub[spec.y] * y_scale,
            label=None if value is None else spec.series_labels.get(
                value, data.label(spec.dataset, spec.series, value)
            ),
            color=series_style.color,
            marker=series_style.marker,
            linestyle=series_style.linestyle,
            markersize=style.MARKER_SIZE,
            linewidth=style.LINE_WIDTH,
            alpha=0.9,
        )

    if spec.logy:
        ax.set_yscale("log")
        if y_unit:
            ax.yaxis.set_major_formatter(ticker.LogFormatter())
            ax.yaxis.set_minor_formatter(ticker.LogFormatter(labelOnlyBase=False))

    step = max(1, ceil(len(x_values) / 8))
    ticks = list(range(0, len(x_values), step))
    ax.set_xticks(ticks)
    ax.set_xticklabels([_fmt_x(spec, x_values[i]) for i in ticks], rotation=45, ha="right")

    ylabel = f"{data.label(spec.dataset, spec.y)} [{y_unit}]" if y_unit else _axis_label(spec, spec.y)
    style.apply_consistent_style(ax, title=title,
                                 xlabel=_axis_label(spec, spec.x),
                                 ylabel=ylabel)


def _y_display(spec: Figure):
    if spec.y in spec.labels:
        return 1.0, None
    try:
        unit = data.column(spec.dataset, spec.y).get("unit")
    except KeyError:
        return 1.0, None
    if unit == "MiB/s":
        return MIBPS_TO_GBPS, "GB/s"
    return 1.0, None


def _fmt_x(spec: Figure, value) -> str:
    try:
        is_bytes = data.column(spec.dataset, spec.x).get("unit") == "bytes"
    except KeyError:
        is_bytes = False
    return data.fmt_size(int(value)) if is_bytes else str(value)


def _axis_label(spec: Figure, name: str) -> str:
    if name in spec.labels:
        return spec.labels[name]
    try:
        return data.axis_label(spec.dataset, name)
    except KeyError:
        return name


def _facet_title(spec: Figure, value) -> str:
    if value in spec.facet_titles:
        return spec.facet_titles[value]
    return data.label(spec.dataset, spec.facet, value)


def _title(spec: Figure) -> str:
    if spec.title:
        return spec.title
    parts = [data.dataset(spec.dataset)["title"]]
    parts += [data.label(spec.dataset, name, value) for name, value in spec.filter.items()]
    title = " — ".join(parts)
    try:
        suffix = _BETTER_TITLES.get(data.better(spec.dataset, spec.y))
    except KeyError:
        suffix = None
    return f"{title} ({suffix})" if suffix else title


def main() -> int:
    names = sys.argv[1:]
    catalog = {spec.name: spec for spec in FIGURES}
    assert len(catalog) == len(FIGURES), "duplicate figure names"
    unknown = [n for n in names if n not in catalog]
    if unknown:
        print(f"unknown figures: {', '.join(unknown)} — available: {', '.join(catalog)}")
        return 1

    if not names:
        shutil.rmtree(OUTPUT, ignore_errors=True)

    for spec in [catalog[n] for n in names] or FIGURES:
        fig = render(spec)
        if fig is None:
            print(f"skip  {spec.name} (no data)")
            continue
        relative = Path(spec.dataset.split("/")[0]) / f"{spec.name}.png"
        path = OUTPUT / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        asset = PAPER_ASSETS / relative
        asset.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, asset)
        print(f"wrote {path.relative_to(data.ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
