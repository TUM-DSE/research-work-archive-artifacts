"""Render the selected end-to-end comparison figures.

The thesis figures keep the current W1--W5 ordering and existing design colors.
The presentation compares the two GPT-3 175B configurations and Mixtral (W3--W5).
"""

from __future__ import annotations

import sys
from dataclasses import replace
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import data
import style


ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "paper" / "tmp" / "e2e-variants"
THESIS_ASSET_DIR = ROOT / "paper" / "assets" / "benchmarks" / "astrasim"

WORKLOADS = [
    ("W1", "GPT-3 5B (PP=8)"),
    ("W2", "GPT-3 5B (FSDP=8)"),
    ("W3", "GPT-3 175B (TP=32 + SP)"),
    ("W4", "GPT-3 175B (DP=2, TP=4, PP=8 + SP)"),
    ("W5", "Mixtral 8x7B (EP=8, PP=4)"),
]
WORKLOAD_IDS = [workload_id for workload_id, _ in WORKLOADS]

# The thesis uses W1--W5 as compact identifiers in dense multi-panel figures.
# The presentation's single-panel view has enough room to spell out the
# parallelism strategies so the audience does not need a legend lookup.
PRESENTATION_WORKLOAD_IDS = ("W3", "W4", "W5")
PRESENTATION_WORKLOAD_LABELS = {
    "W3": "GPT-3 175B\nTensor Parallelism (TP=32)\n+ Sequence Parallelism (SP)",
    "W4": "GPT-3 175B\nData Parallelism (DP=2)\nTensor Parallelism (TP=4)\nPipeline Parallelism (PP=8)\n+ Sequence Parallelism (SP)",
    "W5": "Mixtral 8x7B\nExpert Parallelism (EP=8)\nPipeline Parallelism (PP=4)",
}
PRESENTATION_DESIGN_LABELS = {
    "d1_e2e": "In-GPU Bounce",
    "d2_e2e": "Trusted NIC",
}
# W5 contains All-to-All communication. Its raw halvingDoubling CSV row uses
# ASTRA-sim's Direct fallback for that operation, so it is not a valid pure
# Halving-doubling point for the thesis comparison.
PLOTTED_WORKLOADS = {
    "ring": tuple(WORKLOAD_IDS),
    "halvingDoubling": tuple(workload_id for workload_id in WORKLOAD_IDS if workload_id != "W5"),
}
ALGORITHMS = ("ring", "halvingDoubling")
ALGORITHM_LABELS = {"ring": "Ring", "halvingDoubling": "Halving-doubling"}
DESIGNS = ("d1_e2e", "d2_e2e")
DESIGN_LABELS = {
    "d1_e2e": "Design 1 (end-to-end)",
    "d2_e2e": "Design 2 (end-to-end)",
}

DESIGN_STYLES = {
    "d1_e2e": replace(style.resolve(("path_design1",)), marker="^"),
    "d2_e2e": replace(style.resolve(("path_design2",)), marker="D"),
}

GDR_TITLE = "End-to-end completion-time ratio to GPUDirect (lower is better ↓)"
CPU_TITLE = "End-to-end completion-time ratio to CPU bounce (higher is better ↑)"
GDR_YLABEL = "Design / GPUDirect time (×)"
CPU_YLABEL = "CPU bounce / design time (×)"
E2E_FONT_SCALE = 1.0

MARKER_MODES = {
    "slight_offset": {
        "order": ("d2_e2e", "d1_e2e"),
        "marker": {"d1_e2e": "^", "d2_e2e": "D"},
        "offset": {"d1_e2e": 0.075, "d2_e2e": -0.075},
        "size": {"d1_e2e": 52, "d2_e2e": 52},
        "face": {"d1_e2e": "color", "d2_e2e": "color"},
        "edge": {"d1_e2e": "white", "d2_e2e": "white"},
        "linewidth": {"d1_e2e": 0.7, "d2_e2e": 0.7},
    },
}


def load_ratios() -> pd.DataFrame:
    raw = data.load("astrasim/e2e")
    pivot = raw.pivot_table(
        index=["trace", "npus", "algorithm"],
        columns="design",
        values="completion_us",
        aggfunc="mean",
    ).reset_index()

    trace_to_id = {trace: workload_id for workload_id, trace in WORKLOADS}
    pivot["workload"] = pivot["trace"].map(trace_to_id)
    pivot = pivot[pivot["workload"].notna() & pivot["algorithm"].isin(ALGORITHMS)].copy()
    pivot["d1_over_gdr"] = pivot["d1_e2e"] / pivot["gpudirect"]
    pivot["d2_over_gdr"] = pivot["d2_e2e"] / pivot["gpudirect"]
    pivot["cpu_over_d1"] = pivot["cpu_bounce"] / pivot["d1_e2e"]
    pivot["cpu_over_d2"] = pivot["cpu_bounce"] / pivot["d2_e2e"]
    pivot["d1_over_d2"] = pivot["d1_e2e"] / pivot["d2_e2e"]
    return pivot


def _rows(df: pd.DataFrame, algorithm: str) -> pd.DataFrame:
    rows = df[df["algorithm"] == algorithm].copy()
    order = {workload_id: i for i, workload_id in enumerate(WORKLOAD_IDS)}
    rows["workload_order"] = rows["workload"].map(order)
    return rows.sort_values("workload_order")


def _metric_config(metric: str) -> tuple[str, str, str, tuple[float, float]]:
    if metric == "gdr":
        return "d1_over_gdr", "d2_over_gdr", GDR_TITLE, (0.9, 5.8)
    if metric == "cpu":
        return "cpu_over_d1", "cpu_over_d2", CPU_TITLE, (0.9, 6.45)
    raise ValueError(f"unknown metric: {metric}")


def _base_axis(ax, *, title=None, xlabel=None, ylabel=None, y_limits=None, font_scale=1.0):
    style.apply_consistent_style(ax, title=title, xlabel=xlabel, ylabel=ylabel)
    if title:
        ax.set_title(title, fontsize=style.TITLE_FONTSIZE * font_scale, pad=4, color="navy")
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=style.AXIS_LABEL_FONTSIZE * font_scale)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=style.AXIS_LABEL_FONTSIZE * font_scale)
    if font_scale != 1.0:
        ax.tick_params(
            axis="both",
            which="major",
            labelsize=style.TICKS_FONTSIZE * font_scale,
            pad=3,
        )
        ax.tick_params(
            axis="both",
            which="minor",
            labelsize=style.TICKS_FONTSIZE * font_scale,
            pad=3,
        )
    ax.axhline(1.0, color="#666666", linestyle="--", linewidth=0.8, zorder=0)
    if y_limits:
        ax.set_ylim(*y_limits)


def _legend(fig, handles=None, labels=None, ncols=2, marker_mode="slight_offset", font_scale=1.0):
    if handles is None or labels is None:
        mode = MARKER_MODES[marker_mode]
        handles = [
            plt.Line2D(
                [0],
                [0],
                marker=mode["marker"][design],
                color=DESIGN_STYLES[design].color
                if mode["edge"][design] == "color" else mode["edge"][design],
                linestyle="None",
                markerfacecolor=DESIGN_STYLES[design].color
                if mode["face"][design] == "color" else mode["face"][design],
                markeredgecolor=DESIGN_STYLES[design].color
                if mode["edge"][design] == "color" else mode["edge"][design],
                markeredgewidth=mode["linewidth"][design],
                markersize=np.sqrt(mode["size"][design]) * 0.65,
                label=DESIGN_LABELS[design],
            )
            for design in DESIGNS
        ]
        labels = [DESIGN_LABELS[design] for design in DESIGNS]
    legend = fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        frameon=True,
        fontsize=style.LEGEND_FONTSIZE * font_scale,
        ncols=ncols,
    )
    legend.get_frame().set_edgecolor("black")


def _save(
    fig: plt.Figure,
    stem: str,
    output_dir: Path = OUTPUT_DIR,
    suffixes: tuple[str, ...] = ("png", "pdf"),
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for suffix in suffixes:
        fig.savefig(
            output_dir / f"{stem}.{suffix}",
            dpi=220,
            bbox_inches="tight",
            pad_inches=0.04,
        )
    plt.close(fig)


def plot_no_connectors(
    df: pd.DataFrame,
    metric: str,
    marker_mode="slight_offset",
    stem_prefix="01_no_connectors",
    ax_height=1.95,
    output_dir: Path = OUTPUT_DIR,
    suffixes: tuple[str, ...] = ("png", "pdf"),
    append_metric: bool = True,
) -> None:
    d1_column, d2_column, title, y_limits = _metric_config(metric)
    mode = MARKER_MODES[marker_mode]
    fig, axes = style.create_standardized_subplots(
        ncols=2,
        ax_width=2.05,
        ax_height=ax_height,
        left_margin=0.60,
        right_margin=0.12,
        top_margin=0.52,
        bottom_margin=0.55,
        wspace=0.18,
    )
    axes = np.asarray(axes).ravel()
    for panel_index, algorithm in enumerate(ALGORITHMS):
        ax = axes[panel_index]
        rows = _rows(df, algorithm).set_index("workload")
        plotted_workloads = PLOTTED_WORKLOADS[algorithm]
        columns = {"d1_e2e": d1_column, "d2_e2e": d2_column}
        for design in mode["order"]:
            column = columns[design]
            observed = [workload_id for workload_id in plotted_workloads if workload_id in rows.index]
            values = [rows.loc[workload_id, column] for workload_id in observed]
            series_style = DESIGN_STYLES[design]
            marker_face = series_style.color if mode["face"][design] == "color" else mode["face"][design]
            marker_edge = series_style.color if mode["edge"][design] == "color" else mode["edge"][design]
            ax.scatter(
                [plotted_workloads.index(workload_id) + mode["offset"][design] for workload_id in observed],
                values,
                color=series_style.color,
                marker=mode["marker"][design],
                facecolors=marker_face,
                edgecolors=marker_edge,
                linewidths=mode["linewidth"][design],
                s=mode["size"][design],
                label=DESIGN_LABELS[design],
                zorder=3,
            )
        ax.set_xticks(range(len(plotted_workloads)))
        ax.set_xticklabels(plotted_workloads)
        _base_axis(
            ax,
            title=ALGORITHM_LABELS[algorithm],
            xlabel="Workload",
            ylabel=GDR_YLABEL if metric == "gdr" and panel_index == 0 else
            CPU_YLABEL if metric == "cpu" and panel_index == 0 else None,
            y_limits=y_limits,
            font_scale=E2E_FONT_SCALE,
        )
    _legend(fig, marker_mode=marker_mode, font_scale=E2E_FONT_SCALE)
    fig.suptitle(
        title,
        y=1.055,
        fontsize=(style.TITLE_FONTSIZE + 1) * E2E_FONT_SCALE,
        color="navy",
    )
    stem = f"{stem_prefix}_{metric}" if append_metric else stem_prefix
    _save(fig, stem, output_dir=output_dir, suffixes=suffixes)


def render_thesis_figures(df: pd.DataFrame) -> None:
    """Render the two end-to-end figures referenced by the active thesis."""
    plot_no_connectors(
        df,
        "gdr",
        marker_mode="slight_offset",
        stem_prefix="astra_e2e_overhead_gpudirect_core_offset_vertical",
        ax_height=1.20,
        output_dir=THESIS_ASSET_DIR,
        suffixes=("png",),
        append_metric=False,
    )
    plot_no_connectors(
        df,
        "cpu",
        marker_mode="slight_offset",
        stem_prefix="astra_e2e_speedup_cpu_core_offset_vertical",
        ax_height=1.20,
        output_dir=THESIS_ASSET_DIR,
        suffixes=("png",),
        append_metric=False,
    )


def plot_presentation_ring(
    df: pd.DataFrame,
    stem_prefix="workloads-ring",
) -> pd.DataFrame:
    """Render grouped Ring bars used on the presentation's ML slide.

    This reuses the thesis workload loader, ratio definitions, and semantic
    design styles. It selects W3--W5 to compare GPT-3 175B under two parallelism
    configurations, followed by Mixtral as the most latency-sensitive case.
    """
    rows = _rows(df, "ring").set_index("workload").reindex(PRESENTATION_WORKLOAD_IDS)
    # Keep the single-panel presentation view compact.  The full workload names
    # are carried by multiline tick labels, so extra horizontal canvas only
    # creates whitespace when the asset is placed in the slide's fixed figure
    # region.
    fig, ax = plt.subplots(figsize=(7.2, 4.25))
    x = np.arange(len(PRESENTATION_WORKLOAD_IDS))
    bar_width = 0.30
    handles = []
    for design_index, design in enumerate(DESIGNS):
        column = "d1_over_gdr" if design == "d1_e2e" else "d2_over_gdr"
        series_style = DESIGN_STYLES[design]
        values = rows[column].to_numpy()
        bars = ax.bar(
            x + (design_index - 0.5) * (bar_width + 0.04),
            values,
            width=bar_width,
            color=series_style.color,
            edgecolor="white",
            linewidth=0.6,
            label=PRESENTATION_DESIGN_LABELS[design],
            zorder=3,
        )
        ax.bar_label(bars, labels=[f"{value:.2f}×" for value in values],
                     padding=3, fontsize=8.5)
        handles.append(bars)
    baseline = ax.axhline(1.0, color="#666666", linestyle="--", linewidth=0.9,
                          label="GPUDirect = 1", zorder=4)
    ax.set_xticks(x)
    ax.set_xticklabels(
        [PRESENTATION_WORKLOAD_LABELS[workload_id] for workload_id in PRESENTATION_WORKLOAD_IDS],
        fontsize=7.3,
        linespacing=1.05,
    )
    # Bar lengths encode the full ratio, so the axis must start at zero.
    ax.set_ylim(0, 6.0)
    ax.set_xlim(-0.55, len(PRESENTATION_WORKLOAD_IDS) - 0.45)
    ax.set_yticks([0, 1, 2, 3, 4, 5, 6])
    ax.set_ylabel("Comm. time / GPUDirect (×)", fontsize=10)
    ax.grid(axis="y", color="#dddddd", linewidth=0.7)
    ax.tick_params(axis="y", labelsize=9)
    ax.tick_params(axis="x", pad=6)
    ax.legend(handles=[*handles, baseline],
              loc="upper center", bbox_to_anchor=(0.5, 1.18), ncols=3,
              frameon=False, fontsize=9.5)
    fig.subplots_adjust(top=0.79, bottom=0.36, left=0.11, right=0.97)
    _save(fig, stem_prefix)
    return rows.reset_index()


def main() -> int:
    if sys.argv[1:] not in ([], ["--thesis"]):
        print("usage: python3 plots/e2e_variants.py [--thesis]")
        return 2
    render_thesis_figures(load_ratios())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
