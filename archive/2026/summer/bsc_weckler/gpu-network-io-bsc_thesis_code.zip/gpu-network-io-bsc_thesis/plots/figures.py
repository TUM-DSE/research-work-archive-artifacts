# The figure catalog contains the retained standard paper plots. Declarative fields
# cover the standard series-over-message-size shape; `draw` replaces rendering for
# fully custom figures.

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd

import data
import style


@dataclass(frozen=True)
class Figure:
    name: str
    dataset: str = ""
    y: str = ""
    x: str = "size_bytes"
    series: str | None = "mode"
    style_by: tuple[str, ...] | None = None
    filter: dict = field(default_factory=dict)
    series_order: list | None = None
    facet: str | None = None
    facet_row: str | None = None
    facet_col: str | None = None
    facet_titles: dict = field(default_factory=dict)
    logy: bool = False
    wide: bool = False
    title: str | None = None
    labels: dict = field(default_factory=dict)
    series_labels: dict = field(default_factory=dict)
    series_style_tokens: dict = field(default_factory=dict)
    transform: Callable[[pd.DataFrame], pd.DataFrame] | None = None
    draw: Callable[["Figure"], object] | None = None


DIRECTIONS = {"dtod": "D2D", "dtoh": "D2H", "htod": "H2D"}
FIXED_LATENCY_SIZE_BYTES = 32


def _gpucopy_bandwidth_modes() -> list[str]:
    candidates = [
        "vm_cuda_copy_dtoh",
        "cvm_uvmgpu_copy_dtoh_sealed",
        "cvm_cuda_copy_dtoh",
        "cvm_cuda_copy_dtoh_encrypt",
    ]
    available = set(data.levels("gpucopy/bw", "mode"))
    return [mode for mode in candidates if mode in available]


def draw_copy_latency_split(spec: Figure):
    df = data.load("gpucopy/lat", raw=True)
    df = df[df.component.isin(["total", "command", "copy"]) & df["mode"].str.contains("_uvmgpu_")]
    size = FIXED_LATENCY_SIZE_BYTES
    df = df[df.size_bytes <= size]
    if df.empty:
        raise ValueError(f"gpucopy/lat has no latency measurements at or below {size} B")

    fig, ax = style.create_standardized_plot(ax_width=style.AX_WIDTH_WIDE)
    width = 0.35
    for i, env in enumerate(("vm", "cvm")):
        # Percentiles are not additive even though every raw sample is. Derive
        # the displayed median residual from total-copy so the stack closes at
        # the measured total, while retaining the command rows in the dataset.
        values = {"command": [], "copy": []}
        for direction in DIRECTIONS:
            measured = df[
                df["mode"].str.startswith(f"{env}_")
                & df["mode"].str.contains(f"_{direction}")
            ]
            measured = measured[measured.size_bytes == measured.size_bytes.max()]
            total = measured[measured.component == "total"].lat_typical_us.mean()
            copy = measured[measured.component == "copy"].lat_typical_us.mean()
            command = measured[measured.component == "command"].lat_typical_us.mean()
            if np.isnan(total) or np.isnan(command) or np.isnan(copy):
                raise ValueError(
                    f"gpucopy/lat is missing total/command/copy for {env} {direction} at or below {size} B"
                )
            values["command"].append(max(total - copy, 0.0))
            values["copy"].append(copy)
        positions = [x + (i - 0.5) * width for x in range(len(DIRECTIONS))]
        env_tokens = (f"environment_{env}",)
        command_style = style.resolve(
            env_tokens + data.style_tokens("gpucopy/lat", "component", "command"),
            fallback_index=i,
        )
        copy_style = style.resolve(
            env_tokens + data.style_tokens("gpucopy/lat", "component", "copy"),
            fallback_index=i,
        )
        bar = dict(width=width * 0.9, edgecolor="black", linewidth=0.4)
        ax.bar(positions, values["command"], hatch=command_style.hatch,
               color=command_style.color, label=f"{env.upper()} — command", **bar)
        ax.bar(positions, values["copy"], bottom=values["command"], hatch=copy_style.hatch,
               color=copy_style.color, label=f"{env.upper()} — copy", **bar)

    ax.set_xticks(range(len(DIRECTIONS)))
    ax.set_xticklabels(DIRECTIONS.values())
    style.apply_consistent_style(
        ax,
        title=f"CE copy latency split at {data.fmt_size(size)} ({style.LOWER_BETTER_TITLE})",
        xlabel="Copy direction",
        ylabel="Latency (median) [µs]",
    )
    legend = ax.legend(loc=style.LEGEND_ALIGN, bbox_to_anchor=(0.5, style.LEGEND_BBOX_HEIGHT),
                       frameon=True, fontsize=style.LEGEND_FONTSIZE, ncols=2)
    legend.get_frame().set_edgecolor("black")
    return fig


def draw_write_comparison(metric: str, include_projection: bool = False):
    def draw(spec: Figure):
        is_bw = metric == "bw"
        measured_dataset = f"perftest/{metric}"
        estimate_dataset = f"estimate/{metric}"
        y = "bw_avg_mibps" if is_bw else "lat_avg_us"
        verb = "write" if is_bw else "write_imm"

        measured = data.load(measured_dataset)
        measured_modes = ["vm_gpu_direct_dmabuf"]
        if not include_projection:
            measured_modes.extend(["cvm_ram_bypass", "cvm_gpu_bb_bypass"])
        measured = measured[
            (measured["verb"] == verb)
            & measured["mode"].isin(measured_modes)
        ][["mode", "size_bytes", y]].copy()
        measured["source"] = "measured"

        frames = [measured]
        if include_projection:
            projected = data.load(estimate_dataset)
            projected = projected[
                projected["mode"].isin([
                    "rdma_cvm_cpu_bounce_e2e_synthetic",
                    "rdma_cvm_in_gpu_bounce_e2e_synthetic",
                    "rdma_cvm_ide_ipsec_e2e_synthetic",
                ])
                & (projected["source"] == "estimated")
            ][["mode", "source", "size_bytes", y]].copy()
            required = {
                "rdma_cvm_cpu_bounce_e2e_synthetic",
                "rdma_cvm_in_gpu_bounce_e2e_synthetic",
                "rdma_cvm_ide_ipsec_e2e_synthetic",
            }
            if set(projected["mode"].unique()) != required:
                return None
            frames.append(projected)

        frame = pd.concat(frames, ignore_index=True)
        if frame.empty:
            return None

        ranges = frame.groupby("mode")["size_bytes"].agg(["min", "max"])
        range_min = int(ranges["min"].max())
        range_max = int(ranges["max"].min())
        if include_projection:
            range_min = max(range_min, 512)
        frame = frame[frame["size_bytes"].between(range_min, range_max)]

        modes = [
            ("vm_gpu_direct_dmabuf", "GPUDirect RDMA", measured_dataset),
        ]
        if include_projection:
            modes[0] = (modes[0][0], "GPUDirect RDMA (measured)", modes[0][2])
            modes.append(
                ("rdma_cvm_cpu_bounce_e2e_synthetic",
                 "CPU bounce (modeled, two-sided)", estimate_dataset)
            )
            modes.append(
                ("rdma_cvm_in_gpu_bounce_e2e_synthetic",
                 "Design 1 (modeled, two-sided)", estimate_dataset)
            )
            modes.append(
                ("rdma_cvm_ide_ipsec_e2e_synthetic",
                 "Design 2 (modeled, two-sided)", estimate_dataset)
            )
        else:
            modes.append(
                ("cvm_ram_bypass", "System Memory RDMA", measured_dataset)
            )
            modes.append(
                ("cvm_gpu_bb_bypass", "one sided CPU Bounce", measured_dataset)
            )
        sizes = sorted(frame.size_bytes.unique())
        positions = {value: i for i, value in enumerate(sizes)}

        fig, ax = style.create_standardized_plot()
        scale = 2**20 / 1e9 if is_bw else 1.0
        for i, (mode, label, style_dataset) in enumerate(modes):
            sub = frame[frame["mode"] == mode].sort_values("size_bytes")
            if sub.empty:
                continue
            source = str(sub.source.iloc[0])
            series_style = style.resolve(
                data.style_tokens(style_dataset, "mode", mode)
                + data.style_tokens(estimate_dataset, "source", source),
                fallback_index=i,
            )
            ax.plot(
                [positions[v] for v in sub.size_bytes],
                sub[y] * scale,
                label=label,
                color=series_style.color,
                linestyle=series_style.linestyle,
                marker=series_style.marker,
                markersize=style.MARKER_SIZE,
                linewidth=style.LINE_WIDTH,
                alpha=0.9,
            )

        step = max(1, (len(sizes) + 7) // 8)
        ticks = list(range(0, len(sizes), step))
        ax.set_xticks(ticks)
        ax.set_xticklabels([data.fmt_size(sizes[i]) for i in ticks], rotation=45, ha="right")
        if is_bw:
            ax.set_ylim(bottom=0)
        else:
            ax.set_yscale("log")

        kind = "bandwidth" if is_bw else "latency"
        direction = style.HIGHER_BETTER_TITLE if is_bw else style.LOWER_BETTER_TITLE
        title = (
            f"Flow completion time ({direction})"
            if include_projection
            else f"RDMA {kind} — Write ({direction})"
        )
        style.apply_consistent_style(
            ax,
            title=title,
            xlabel="Message size [bytes]",
            ylabel="Bandwidth (avg) [GB/s]" if is_bw else "Completion time [µs]",
        )
        legend = ax.legend(
            loc=style.LEGEND_ALIGN,
            bbox_to_anchor=(0.5, style.LEGEND_BBOX_HEIGHT),
            frameon=True,
            fontsize=style.LEGEND_FONTSIZE,
            ncols=2,
        )
        legend.get_frame().set_edgecolor("black")
        return fig

    return draw


def draw_fixed_latency_comparison(spec: Figure):
    rdma = data.load("perftest/lat")
    rdma = rdma[(rdma["verb"] == "write_imm")]
    gpu = data.load("gpucopy/lat")
    gpu = gpu[(gpu["component"] == "total")]

    entries = [
        ("GPUDirect\nRDMA", rdma, "vm_gpu_direct_dmabuf", "perftest/lat"),
        ("System Memory\nRDMA", rdma, "cvm_ram_bypass", "perftest/lat"),
        ("D2D\n(CVM)", gpu, "cvm_uvmgpu_copy_dtod", "gpucopy/lat"),
        ("D2H\n(CVM)", gpu, "cvm_cuda_copy_dtoh", "gpucopy/lat"),
        ("D2H +\nAES-GCM", gpu, "cvm_cuda_copy_dtoh_encrypt", "gpucopy/lat"),
        ("H2D\n(CVM)", gpu, "cvm_cuda_copy_htod", "gpucopy/lat"),
        ("AES-GCM +\nH2D", gpu, "cvm_cuda_copy_decrypt_htod", "gpucopy/lat"),
    ]
    values = []
    for label, frame, mode, dataset_id in entries:
        row = frame[
            (frame["mode"] == mode)
            & (frame["size_bytes"] <= FIXED_LATENCY_SIZE_BYTES)
        ].sort_values("size_bytes")
        if row.empty:
            return None
        values.append((label, float(row.iloc[-1].lat_typical_us), mode, dataset_id))

    fig, ax = style.create_standardized_plot(
        ax_width=4.25, ax_height=1.15, bottom_margin=0.62, top_margin=0.55
    )
    for i, (label, value, mode, dataset_id) in enumerate(values):
        tokens = data.style_tokens(dataset_id, "mode", mode)
        if mode in {
            "cvm_cuda_copy_dtoh_encrypt",
            "cvm_cuda_copy_decrypt_htod",
        }:
            tokens = ("copy_cpu_crypto", "copy_env_cvm")
        elif mode == "cvm_cuda_copy_dtoh":
            tokens = ("fixed_d2h",)
        elif mode == "cvm_cuda_copy_htod":
            tokens = ("fixed_h2d",)
        series_style = style.resolve(tokens, fallback_index=i)
        ax.bar(i, value, color=series_style.color, width=0.68, edgecolor="black", linewidth=0.4)
        ax.text(
            i,
            value + max(v for _, v, _, _ in values) * 0.025,
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=style.ANNOTATION_SIZE,
        )

    ax.set_xticks(range(len(values)))
    ax.set_xticklabels([label for label, _, _, _ in values])
    ax.set_ylim(0, max(v for _, v, _, _ in values) * 1.17)
    style.apply_consistent_style(
        ax,
        title=f"Fixed latency at {FIXED_LATENCY_SIZE_BYTES} B ({style.LOWER_BETTER_TITLE})",
        ylabel="Median latency [µs]",
        grid=False,
    )
    ax.grid(axis="y", linestyle="--", alpha=style.GRID_ALPHA, linewidth=style.GRID_LINE_WIDTH)
    return fig


def draw_model_validation(spec: Figure):
    frame = data.load("estimate/lat")
    frame = frame[
        frame["mode"].isin([
            "rdma_vm_gpu_direct_measured",
            "rdma_cvm_cpu_bounce_single_synthetic",
            "rdma_cvm_in_gpu_bounce_single_synthetic",
        ])
        & frame["source"].isin(["measured", "estimated"])
        & frame["size_bytes"].between(512, 2 << 20)
    ]
    if frame.empty:
        return None

    sizes = sorted(frame.size_bytes.unique())
    positions = {value: i for i, value in enumerate(sizes)}
    panels = [
        (
            "rdma_vm_gpu_direct_measured",
            "GPUDirect RDMA",
            [("measured", "Measured"), ("estimated", "Modeled")],
        ),
        (
            "rdma_cvm_cpu_bounce_single_synthetic",
            "CPU bounce",
            [("measured", "Measured (one-sided)"),
             ("estimated", "Modeled (one-sided)")],
        ),
        (
            "rdma_cvm_in_gpu_bounce_single_synthetic",
            "Design 1",
            [("measured", "System-memory proxy"), ("estimated", "Modeled")],
        ),
    ]

    validation_ax_width = 2.35
    validation_ax_height = 1.05
    validation_bottom_margin = 0.43
    fig, axes = style.create_standardized_subplots(
        nrows=2,
        ncols=2,
        ax_width=validation_ax_width,
        ax_height=validation_ax_height,
        top_margin=0.65,
        bottom_margin=validation_bottom_margin,
        wspace=0.38,
        hspace=0.60,
        right_margin=0.1,
    )
    bottom_axis = axes[1, 0]
    axes[1, 1].remove()
    bottom_axis.set_position([
        (fig.get_figwidth() - validation_ax_width) / (2 * fig.get_figwidth()),
        validation_bottom_margin / fig.get_figheight(),
        validation_ax_width / fig.get_figwidth(),
        validation_ax_height / fig.get_figheight(),
    ])
    plot_axes = [axes[0, 0], axes[0, 1], bottom_axis]
    for panel_index, (mode, title, series) in enumerate(panels):
        ax = plot_axes[panel_index]
        panel = frame[frame["mode"] == mode]
        for i, (source, label) in enumerate(series):
            sub = frame[(frame["mode"] == mode) & (frame["source"] == source)].sort_values(
                "size_bytes"
            )
            mode_tokens = data.style_tokens("estimate/lat", "mode", mode)
            if mode == "rdma_cvm_in_gpu_bounce_single_synthetic" and source == "measured":
                mode_tokens = data.style_tokens(
                    "perftest/lat", "mode", "cvm_gpu_bb_uvmgpu"
                )
            style_tokens = mode_tokens + data.style_tokens("estimate/lat", "source", source)
            series_style = (
                style.validation_model_style(style_tokens, fallback_index=i)
                if source == "estimated"
                else style.resolve(style_tokens, fallback_index=i)
            )
            ax.plot(
                [positions[v] for v in sub.size_bytes],
                sub.lat_avg_us,
                label=label,
                color=series_style.color,
                linestyle=series_style.linestyle,
                marker=series_style.marker,
                markersize=style.MARKER_SIZE,
                linewidth=style.LINE_WIDTH,
                alpha=0.9,
            )

        step = max(1, (len(sizes) + 4) // 5)
        ticks = list(range(0, len(sizes), step))
        ax.set_xticks(ticks)
        ax.set_xticklabels([data.fmt_size(sizes[i]) for i in ticks], rotation=45, ha="right")
        ax.set_yscale("log")
        ax.set_ylim(panel.lat_avg_us.min() * 0.85, panel.lat_avg_us.max() * 1.2)
        style.apply_consistent_style(
            ax,
            title=title,
            xlabel="Message size [bytes]",
            ylabel="Completion time [µs]",
        )
        legend = ax.legend(
            loc=style.LEGEND_ALIGN,
            bbox_to_anchor=(0.5, style.LEGEND_BBOX_HEIGHT),
            frameon=True,
            fontsize=style.LEGEND_FONTSIZE,
            ncols=2,
        )
        legend.get_frame().set_edgecolor("black")

    fig.suptitle(
        "Model validation",
        y=1.01,
        fontsize=style.TITLE_FONTSIZE + 1,
        color="navy",
    )
    return fig


FIGURES = [
    Figure("bw_write_baseline", "perftest/bw", draw=draw_write_comparison("bw")),
    Figure("lat_write_baseline", "perftest/lat", draw=draw_fixed_latency_comparison),
    Figure("fct_model_validation", "estimate/lat", draw=draw_model_validation),
    Figure(
        "fct",
        "perftest/lat",
        draw=draw_write_comparison("lat", include_projection=True),
    ),
    Figure(
        "gpu_copy_bw_dtoh",
        "gpucopy/bw",
        y="bw_avg_mibps",
        series_order=_gpucopy_bandwidth_modes(),
        series_labels={
            "vm_cuda_copy_dtoh": "D2H (VM)",
            "cvm_uvmgpu_copy_dtoh_sealed": "Sealed CE copy D2H (CVM)",
            "cvm_cuda_copy_dtoh": "D2H (CVM)",
            "cvm_cuda_copy_dtoh_encrypt": "D2H + AES-GCM",
        },
        series_style_tokens={
            "cvm_cuda_copy_dtoh_encrypt": ("copy_cpu_crypto", "copy_env_cvm"),
        },
        wide=True,
        title=f"GPU copy bandwidth D2H ({style.HIGHER_BETTER_TITLE})",
    ),
    Figure("gpu_copy_latency_split", "gpucopy/lat", draw=draw_copy_latency_split),
]
