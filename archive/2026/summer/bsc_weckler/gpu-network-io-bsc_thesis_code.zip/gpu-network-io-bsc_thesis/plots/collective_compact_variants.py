"""Generate the four compact collective figures used in the thesis.

The figures show every available Design 1 and Design 2 series from the existing
ASTRA-sim results without synthesizing missing points.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import ticker

import data
import style


ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "paper" / "assets" / "benchmarks" / "astrasim"

COLLECTIVES = ("all_reduce", "all_gather", "reduce_scatter", "all_to_all")
ALGORITHMS = ("ring", "halvingDoubling")
DESIGNS = (("d1_e2e", "Design 1"), ("d2_e2e", "Design 2"))


def _save(fig: plt.Figure, stem: str) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUTPUT_DIR / f"{stem}.png", dpi=240, bbox_inches="tight", pad_inches=0.025)
    plt.close(fig)


def _pivot() -> pd.DataFrame:
    df = data.load("astrasim/micro")
    return df.pivot_table(
        index=["fabric", "algorithm", "collective", "npus", "size_bytes"],
        columns="design",
        values="completion_us",
    ).reset_index()


def _ratios() -> pd.DataFrame:
    df = _pivot()
    df["d1_over_gdr"] = df["d1_e2e"] / df["gpudirect"]
    df["d2_over_gdr"] = df["d2_e2e"] / df["gpudirect"]
    df["d1_speedup_cpu"] = df["cpu_bounce"] / df["d1_e2e"]
    df["d2_speedup_cpu"] = df["cpu_bounce"] / df["d2_e2e"]
    df["d2_speedup_d1"] = df["d1_e2e"] / df["d2_e2e"]
    return df


def _algorithm_style(algorithm: str, fallback: int):
    return style.resolve(data.style_tokens("astrasim/micro", "algorithm", algorithm), fallback_index=fallback)


def _design_style(design: str, fallback: int):
    return style.resolve(data.style_tokens("astrasim/micro", "design", design), fallback_index=fallback)


def _axes(*, one_row: bool, title: bool):
    if one_row:
        return style.create_standardized_subplots(
            nrows=1,
            ncols=4,
            ax_width=1.27,
            ax_height=0.84,
            left_margin=0.55,
            right_margin=0.04,
            top_margin=0.42 if title else 0.36,
            bottom_margin=0.46,
            wspace=0.18,
        )
    return style.create_standardized_subplots(
        nrows=2,
        ncols=2,
        ax_width=1.48,
        ax_height=0.82,
        left_margin=0.55,
        right_margin=0.08,
        top_margin=0.70 if title else 0.28,
        bottom_margin=0.38,
        wspace=0.22,
        hspace=0.18,
    )


def _draw_series(ax, cell: pd.DataFrame, x_name: str, y_name: str, x_values: list[int]) -> None:
    positions = {value: i for i, value in enumerate(x_values)}
    paired_metric = y_name.startswith("d1_") and f"d2_{y_name.removeprefix('d1_')}" in cell
    if paired_metric:
        metric_suffix = y_name.removeprefix("d1_")
        for design_index, (design, design_label) in enumerate(DESIGNS):
            design_style = _design_style(design, design_index)
            design_metric = f"{design.removesuffix('_e2e')}_{metric_suffix}"
            for algorithm_index, algorithm in enumerate(ALGORITHMS):
                series = cell[cell.algorithm == algorithm].dropna(
                    subset=[design_metric]
                ).sort_values(x_name)
                if series.empty:
                    continue
                algorithm_style = _algorithm_style(algorithm, algorithm_index)
                ax.plot(
                    [positions[int(value)] for value in series[x_name]],
                    series[design_metric],
                    color=design_style.color,
                    marker=algorithm_style.marker,
                    linestyle=algorithm_style.linestyle,
                    markersize=style.MARKER_SIZE,
                    linewidth=style.LINE_WIDTH,
                    label=f"{design_label} — {data.label('astrasim/micro', 'algorithm', algorithm)}",
                )
        return

    for algorithm_index, algorithm in enumerate(ALGORITHMS):
        series = cell[cell.algorithm == algorithm].sort_values(x_name)
        if series.empty:
            continue
        algorithm_style = _algorithm_style(algorithm, algorithm_index)
        ax.plot(
            [positions[int(value)] for value in series[x_name]],
            series[y_name],
            color=algorithm_style.color,
            marker=algorithm_style.marker,
            linestyle=algorithm_style.linestyle,
            markersize=style.MARKER_SIZE,
            linewidth=style.LINE_WIDTH,
            label=data.label("astrasim/micro", "algorithm", algorithm),
        )


def _legend(fig, axes) -> None:
    handles, labels = axes[0].get_legend_handles_labels()
    legend = fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.89),
        frameon=True,
        fontsize=style.LEGEND_FONTSIZE - 0.4,
        ncols=2,
        handlelength=2.0,
        borderpad=0.2,
        labelspacing=0.2,
    )
    legend.get_frame().set_edgecolor("black")
    legend.get_frame().set_linewidth(0.7)


def _format_axis(ax, *, logy: bool, title: str | None, ylabel: str | None,
                 xlabel: str | None, show_xticklabels: bool) -> None:
    if logy:
        ax.set_yscale("log", base=2)
        ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%g"))
    ax.tick_params(axis="x", labelbottom=show_xticklabels)
    style.apply_consistent_style(ax, title=title, xlabel=xlabel, ylabel=ylabel)


def _plot_variant(
    *,
    name: str,
    metric: str,
    x_name: str,
    xlabel: str,
    ylabel: str,
    logy: bool,
    reference: float,
    threshold: float | None = None,
    size_bytes: int | None = None,
    one_row: bool,
    title: bool,
) -> None:
    df = _ratios()
    if size_bytes is not None:
        available = sorted(int(v) for v in df.size_bytes.unique())
        size = min(available, key=lambda value: abs(value - size_bytes))
        df = df[df.size_bytes == size]

    if size_bytes is None:
        df = df[df.npus == 64]
    x_values_global = sorted(int(v) for v in df[x_name].unique())
    fig, axes = _axes(one_row=one_row, title=title)
    axes_array = np.asarray(axes)
    axes_flat = axes_array.ravel()

    for index, collective in enumerate(COLLECTIVES):
        ax = axes_flat[index]
        cell = df[df.collective == collective]
        x_values = sorted(int(v) for v in cell[x_name].unique()) or x_values_global
        _draw_series(ax, cell, x_name, metric, x_values)
        ax.axhline(reference, color="dimgray", linestyle="--", linewidth=style.GRID_LINE_WIDTH)
        if threshold is not None:
            ax.axhline(threshold, color="dimgray", linestyle=":", linewidth=style.GRID_LINE_WIDTH)
        if x_name == "size_bytes":
            tick_step = max(1, (len(x_values) + (5 if not one_row else 3)) // (6 if not one_row else 4))
            tick_positions = list(range(0, len(x_values), tick_step))
            labels = [data.fmt_size(x_values[i]) for i in tick_positions]
            rotation = 35
        else:
            tick_positions = list(range(len(x_values)))
            labels = [str(value) for value in x_values]
            rotation = 0
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(labels, rotation=rotation, ha="right" if rotation else "center")
        if one_row:
            panel_xlabel = None
            show_xticklabels = True
            panel_title = data.label("astrasim/micro", "collective", collective)
        else:
            row = index // 2
            panel_xlabel = xlabel if row == 1 else None
            show_xticklabels = row == 1
            panel_title = data.label("astrasim/micro", "collective", collective)
        _format_axis(
            ax,
            logy=logy,
            title=panel_title,
            ylabel=None,
            xlabel=panel_xlabel,
            show_xticklabels=show_xticklabels,
        )

    # One shared label avoids repeating a long y-axis label on both rows.
    fig.text(0.012, 0.50, ylabel, rotation=90, va="center", ha="center",
             fontsize=style.AXIS_LABEL_FONTSIZE)
    if one_row:
        fig.text(0.52, 0.015, xlabel, ha="center", va="bottom",
                 fontsize=style.AXIS_LABEL_FONTSIZE)
    if title:
        fig.suptitle(
            {
                "d1_over_gdr": "Design overhead over GPUDirect by logical algorithm (Lower is better ↓)",
                "d1_speedup_cpu": "Design speedup over CPU bounce by logical algorithm (Higher is better ↑)",
                "d2_speedup_d1": "Design 2 speedup over Design 1 — 64 GPUs",
            }.get(metric, "Overhead over GPUDirect by GPU count (Lower is better ↓)"),
            y=0.985,
            fontsize=style.TITLE_FONTSIZE + 1,
            color="navy",
        )
    _legend(fig, axes_flat)
    _save(fig, name)


def main() -> None:
    figures = (
        ("astra_overhead_algorithms_64gpus", "d1_over_gdr", "size_bytes", "Message size", "Completion-time overhead (×)", True, 1.0, 1.10, None),
        ("astra_speedup_cpu_algorithms_64gpus", "d1_speedup_cpu", "size_bytes", "Message size", "Speedup (×)", False, 1.0, None, None),
        ("astra_d2_speedup_d1_algorithms_64gpus", "d2_speedup_d1", "size_bytes", "Message size", "Design 2 speedup (×)", False, 1.0, None, None),
        ("astra_overhead_scaling_512mib", "d1_over_gdr", "npus", "GPUs", "Completion-time overhead (×)", False, 1.0, None, 512 << 20),
    )
    for name, metric, x_name, xlabel, ylabel, logy, reference, threshold, size_bytes in figures:
        _plot_variant(
            name=f"{name}_compact2x2",
            metric=metric,
            x_name=x_name,
            xlabel=xlabel,
            ylabel=ylabel,
            logy=logy,
            reference=reference,
            threshold=threshold,
            size_bytes=size_bytes,
            one_row=False,
            title=True,
        )


if __name__ == "__main__":
    main()
