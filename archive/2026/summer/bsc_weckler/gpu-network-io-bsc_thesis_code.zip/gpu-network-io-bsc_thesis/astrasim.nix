{
  lib,
  stdenv,
  cmake,
  protobuf,
  zlib,
  fetchFromGitHub,
  astraSimSrc,
}:

let
  version = "2.1.0";

  yaml-cpp-src = fetchFromGitHub {
    owner = "jbeder";
    repo = "yaml-cpp";
    rev = "a83cd31";
    hash = "sha256-AGLe4GL5TyeV8s5uQKTps7UZWzZopvh1TqjgG6HRrvg=";
  };
in
stdenv.mkDerivation {
  pname = "astra-sim-analytical";
  inherit version;

  src = astraSimSrc;

  nativeBuildInputs = [
    cmake
    protobuf
  ];

  buildInputs = [
    protobuf
    zlib
  ];

  env.PROTOBUF_FROM_SOURCE = "True";

  postPatch = ''
    sed -i '/#include <algorithm>/a #include <cstdint>' extern/helper/cxxopts/cxxopts.hpp
  '';

  cmakeBuildDir = "nix-build";
  cmakeDir = "../build/astra_analytical";
  cmakeFlags = [
    "-DBUILDTARGET=congestion_unaware"
    "-DFETCHCONTENT_SOURCE_DIR_YAML-CPP=${yaml-cpp-src}"
  ];

  preConfigure = ''
    protoc et_def.proto \
      --proto_path=extern/graph_frontend/chakra/schema/protobuf \
      --cpp_out=extern/graph_frontend/chakra/schema/protobuf
  '';

  installPhase = ''
    runHook preInstall
    install -Dm755 bin/AstraSim_Analytical_Congestion_Unaware -t $out/bin
    runHook postInstall
  '';

  meta = {
    description = "ASTRA-sim analytical (congestion-unaware) network simulator";
    homepage = "https://astra-sim.github.io/";
    license = lib.licenses.mit;
    platforms = lib.platforms.unix;
    mainProgram = "AstraSim_Analytical_Congestion_Unaware";
  };
}
