#!/usr/bin/env bash
set -e
JOBS=$(nproc)
cd /kernel
mkdir -p /tmp/kbuild
cp /kernel-config /tmp/kbuild/.config
make O=/tmp/kbuild olddefconfig
make O=/tmp/kbuild -j${JOBS} bindeb-pkg KDEB_COMPRESS=none
# The container creates these packages as root. Clean them here rather than
# asking the unprivileged host-side Make process to remove them.
rm -rf /kernel/out
mkdir -p /kernel/out
mv /tmp/*.deb /kernel/out/
