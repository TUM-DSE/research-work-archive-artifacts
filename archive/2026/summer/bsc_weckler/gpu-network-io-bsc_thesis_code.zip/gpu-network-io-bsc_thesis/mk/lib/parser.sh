#!/usr/bin/env bash

gpumk_repo_root_for_script() {
  cd "$(dirname "$1")/../../.." && pwd
}
