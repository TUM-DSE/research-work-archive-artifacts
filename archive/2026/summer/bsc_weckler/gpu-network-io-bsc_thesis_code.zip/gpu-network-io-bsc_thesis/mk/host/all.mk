# Shared: guest image bundle (netplan, rootfs overlay, firmware blobs under mk/host/config/vm).
VM_CONFIG := mk/host/config/vm

include mk/host/network.mk
include mk/host/images.mk
include mk/host/gpu.mk
include mk/host/rdma.mk
include mk/host/qemu-amd.mk
include mk/host/utils.mk
include mk/host/gnio.mk
include mk/host/plots.mk
