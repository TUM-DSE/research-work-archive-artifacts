#!/usr/bin/env bash

set -eu
set -x
shopt -s extglob

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO_ROOT=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")

usage() {
  echo "Usage: SWIOTLB=0|1 $0 <path/to/base-raw.qcow2> <output_prefix_without_qcow2>" >&2
  exit 1
}

[[ $# -eq 2 ]] || usage

RAW_BASE_IMAGE="$1"
TARGET="$2"
SWIOTLB="${SWIOTLB:-0}"

if [[ "${SWIOTLB}" -eq 1 ]]; then
  GRUB_CONFIG="${REPO_ROOT}/mk/host/config/vm/base/grub.swiotlb"
else
  GRUB_CONFIG="${REPO_ROOT}/mk/host/config/vm/base/grub"
fi

TARGET_IMAGE="${TARGET}.qcow2"

if [[ ! -f "${RAW_BASE_IMAGE}" ]]; then
  echo "Error: raw base image not found at ${RAW_BASE_IMAGE}" >&2
  exit 1
fi

if [[ ! -f "${GRUB_CONFIG}" ]]; then
  echo "Error: grub config not found at ${GRUB_CONFIG}" >&2
  exit 1
fi

rm -f "${TARGET_IMAGE}"
qemu-img create -f qcow2 -F qcow2 -b "$(realpath "${RAW_BASE_IMAGE}")" "${TARGET_IMAGE}"

virt-customize --format qcow2 -a "${TARGET_IMAGE}" \
  --memsize 4096 \
  --smp 4 \
  --upload "${GRUB_CONFIG}:/etc/default/grub" \
  --run-command "grub-mkconfig -o /boot/grub/grub.cfg"

echo "Built ${TARGET_IMAGE} (backing=$(realpath "${RAW_BASE_IMAGE}"), grub=$(basename "${GRUB_CONFIG}"), swiotlb=${SWIOTLB})"
