.PHONY: rdma.pf.bind rdma.pf.clean rdma.gids rdma.netconf

#### RDMA ####

IAN_RDMA_IP := 10.254.200.175/16
JAMIE_RDMA_IP := 10.254.221.31/16

HOSTNAME := $(shell hostname -s)

RDMA_HOST_IP = $(if $(filter ian,$(HOSTNAME)),$(IAN_RDMA_IP),\
               $(if $(filter jamie,$(HOSTNAME)),$(JAMIE_RDMA_IP),\
               $(error rdma.netconf: unsupported host '$(HOSTNAME)')))

RDMA_DEVICE=mlx5_0/1

RDMA_IB_DEVICE?=$(firstword $(subst /, ,${RDMA_DEVICE}))
RDMA_NETDEV:=$(shell rdma -j link show ${RDMA_DEVICE} 2>/dev/null | jq -r '.[].netdev' 2>/dev/null)
RDMA_NETDEV_VENDOR:=$(shell cat /sys/class/net/$(RDMA_NETDEV)/device/vendor 2>/dev/null | cut -b 3-)
RDMA_NETDEV_DEVICE:=$(shell cat /sys/class/net/$(RDMA_NETDEV)/device/device 2>/dev/null | cut -b 3-)

RDMA_PF?=1

RDMA_PF_PCI:=$(shell readlink -f /sys/class/net/$(RDMA_NETDEV)/device 2>/dev/null | xargs -r basename)
RDMA_PF_BDF:=$(shell echo "$(RDMA_PF_PCI)" | cut -d: -f2-)
RDMA_PF_IOMMU_GROUP:=$(shell readlink -f /sys/bus/pci/devices/${RDMA_PF_PCI}/iommu_group 2>/dev/null | grep -oE '[0-9]+$$')

RDMA_PF_VFIO=$(if $(filter 1,${RDMA_PF}),$(if ${RDMA_PF_IOMMU_GROUP},/dev/vfio/${RDMA_PF_IOMMU_GROUP}))
RDMA_PF_CLEAN=$(if $(filter 1,${RDMA_PF}),rdma.pf.clean)

RDMA_PF_PASSTHROUGH_DEV=-device vfio-pci,host=${RDMA_PF_BDF},iommufd=iommufd_rdma,bus=pci.2,romfile=
RDMA_PF_PASSTHROUGH=$(if $(filter 1,${RDMA_PF}),${RDMA_PF_PASSTHROUGH_DEV})

rdma.pf.bind:
	sudo ./tools/vfio-pci-bind/vfio-pci-bind.sh ${RDMA_PF_PCI} ${RDMA_NETDEV_VENDOR}:${RDMA_NETDEV_DEVICE}

rdma.pf.clean:
	./mk/host/scripts/rdma_pf_clean.sh

${RDMA_PF_VFIO}:
	$(MAKE) rdma.pf.bind

rdma.netconf:
	sudo ./mk/host/scripts/rdma_netconf.sh $(RDMA_DEVICE) $(RDMA_HOST_IP)

rdma.gids:
	RDMA_IB_DEVICE=$(RDMA_IB_DEVICE) ./mk/host/scripts/check_gids.sh
