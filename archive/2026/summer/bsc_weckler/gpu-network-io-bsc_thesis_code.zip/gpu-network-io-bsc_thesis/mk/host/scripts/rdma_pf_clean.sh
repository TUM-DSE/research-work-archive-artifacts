#!/usr/bin/env bash

set -euo pipefail

PCI=$(find /sys/bus/pci/drivers/vfio-pci/ -maxdepth 1 -name '????:??:??.?' \
  -exec sh -c 'cat "$1/vendor" 2>/dev/null' _ {} \; -print \
  | paste - - | awk '$1 == "0x15b3" {print $2}' | xargs -r basename | head -n1)

if [[ -z "$PCI" ]]; then
  echo "rdma_pf_clean: no Mellanox device found in vfio-pci, nothing to do"
  exit 0
fi
echo "rdma_pf_clean: auto-discovered ${PCI}"

DRIVER_PATH="/sys/bus/pci/devices/${PCI}/driver"

if [[ ! -e "$DRIVER_PATH" ]]; then
  echo "rdma_pf_clean: ${PCI} has no driver bound, nothing to do"
  exit 0
fi

CURRENT_DRIVER=$(basename "$(readlink -f "$DRIVER_PATH")")

if [[ "$CURRENT_DRIVER" != "vfio-pci" ]]; then
  echo "rdma_pf_clean: ${PCI} is bound to ${CURRENT_DRIVER}, not vfio-pci, nothing to do"
  exit 0
fi

VENDOR=$(cat "/sys/bus/pci/devices/${PCI}/vendor" | cut -b 3-)
DEVICE=$(cat "/sys/bus/pci/devices/${PCI}/device" | cut -b 3-)

echo "${VENDOR} ${DEVICE}" | sudo tee /sys/bus/pci/drivers/vfio-pci/remove_id >/dev/null 2>&1 || true

echo "rdma_pf_clean: unbinding ${PCI} from vfio-pci"
echo "${PCI}" | sudo tee /sys/bus/pci/drivers/vfio-pci/unbind >/dev/null

echo "rdma_pf_clean: reprobing ${PCI} (forcing mlx5_core)"
echo "mlx5_core" | sudo tee /sys/bus/pci/devices/${PCI}/driver_override >/dev/null
echo "${PCI}" | sudo tee /sys/bus/pci/drivers_probe >/dev/null
echo "" | sudo tee /sys/bus/pci/devices/${PCI}/driver_override >/dev/null

FINAL_DRIVER=$(basename "$(readlink -f "/sys/bus/pci/devices/${PCI}/driver" 2>/dev/null)" 2>/dev/null || echo 'no driver')
echo "rdma_pf_clean: done (now bound to ${FINAL_DRIVER})"
