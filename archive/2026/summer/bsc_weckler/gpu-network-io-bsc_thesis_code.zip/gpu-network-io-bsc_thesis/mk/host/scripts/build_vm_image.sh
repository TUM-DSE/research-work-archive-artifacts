#!/usr/bin/env bash

set -eu
set -x
shopt -s extglob

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO_ROOT=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")

usage() {
  echo "Usage: $0 <path/to/base.qcow2> <output_prefix_without_qcow2>" >&2
  exit 1
}

[[ $# -eq 2 ]] || usage

BASE_IMAGE="$1"
TARGET="$2"

TARGET_IMAGE="${TARGET}.qcow2"
HOST_NVIM_CONFIG="${HOME}/.config/nvim"
STAGING_DIR=$(mktemp -d)

cleanup() {
  rm -rf "${STAGING_DIR}"
}
trap cleanup EXIT

if [ ! -f "${BASE_IMAGE}" ]; then
  echo "Error: base image not found at ${BASE_IMAGE}" >&2
  exit 1
fi

if [ -d "${HOST_NVIM_CONFIG}" ]; then
  mkdir -p "${STAGING_DIR}/nvim-config"
  cp -a "${HOST_NVIM_CONFIG}/." "${STAGING_DIR}/nvim-config/"
fi

rm -f "${TARGET_IMAGE}"
qemu-img create -f qcow2 -F qcow2 -b "$(realpath "${BASE_IMAGE}")" "${TARGET_IMAGE}"

COPY_IN_ARGS=(--copy-in "${REPO_ROOT}/mk/host/config/vm/rootfs/.:/")
if [ -d "${STAGING_DIR}/nvim-config" ]; then
  COPY_IN_ARGS+=(--copy-in "${STAGING_DIR}/nvim-config/.:/root/.config/nvim")
fi

virt-customize --format qcow2 -a "${TARGET_IMAGE}" \
  --memsize 4096 \
  --smp 4 \
  --root-password password:root \
  --hostname GpuNetIO \
  --run-command "mkdir -p /root/.ssh /root/.config/nvim /root/gpunet /root/work" \
  "${COPY_IN_ARGS[@]}" \
  --run-command "chmod 700 /etc/netplan/99_config.yaml" \
  --run-command "chmod 600 /root/.ssh/authorized_keys" \
  --run-command "chmod 600 /etc/ssh/ssh_host_ed25519_key" \
  --run-command "chmod 644 /etc/ssh/ssh_host_ed25519_key.pub" \
  --run-command "chown -R root:root /root/.ssh /etc/netplan /etc/ssh" \
  --run-command "printf '127.0.0.1 localhost\n127.0.1.1 GpuNetIO\n' > /etc/hosts" \
  --run-command "ldconfig"

echo "Built ${TARGET_IMAGE} (backing=$(realpath "${BASE_IMAGE}"))"
