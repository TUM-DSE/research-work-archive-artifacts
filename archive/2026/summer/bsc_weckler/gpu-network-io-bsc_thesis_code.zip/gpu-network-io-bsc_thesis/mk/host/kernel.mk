LOCAL_PATH=tools/kernel-build
include tools/kernel-build/Makefile

.PHONY: clean.kernel

clean.kernel:
	$(MAKE) -C tools/kernel-build clean
	cd tools/linux && rm -rf out
