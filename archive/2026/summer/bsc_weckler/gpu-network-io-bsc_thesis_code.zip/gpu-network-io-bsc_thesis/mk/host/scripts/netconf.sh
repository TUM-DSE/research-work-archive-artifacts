#!/usr/bin/env bash

set -eu

usage() {
  echo "Usage: $0 <infile> <outfile>" >&2
  exit 1
}

[[ $# -eq 2 ]] || usage

YAMLIN="$1"
YAMLOUT="$2"

sub=$(id -u | awk '{ print $1 % 1000 }')
Addr="192.168.${sub}.10/24"
Route="192.168.${sub}.1"
RdmaAddr="10.254.${sub}.10/16"

cp "${YAMLIN}" "${YAMLOUT}"
yq -i -y '.network.ethernets.virtio.addresses[0] = "'"${Addr}"'"' "${YAMLOUT}" >/dev/null
yq -i -y '.network.ethernets.virtio.routes[0].via = "'"${Route}"'"' "${YAMLOUT}" >/dev/null
yq -i -y '.network.ethernets.rdma.addresses[0] = "'"${RdmaAddr}"'"' "${YAMLOUT}" >/dev/null
