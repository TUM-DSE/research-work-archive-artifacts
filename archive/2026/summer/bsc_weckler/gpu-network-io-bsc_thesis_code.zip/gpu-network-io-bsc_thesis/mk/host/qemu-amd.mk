.PHONY: run run.noofed run.ofed \
	run.plain run.plain.noofed.noswiotlb run.plain.noofed.swiotlb run.plain.ofed.noswiotlb run.plain.ofed.swiotlb

EPHEMERAL_DISK?=0

QEMU_SYSTEM?=qemu-system-x86_64
QEMU_AMD?=${QEMU_SYSTEM}

OVMF_AMD=$(VM_CONFIG)/OVMF.amd.fd

VFIO_COMMON?=\
	-object iommufd,id=iommufd_rdma \
	-device pcie-root-port,id=pci.1,bus=pcie.0,chassis=1,slot=1 \
	-device pcie-root-port,id=pci.2,bus=pcie.0,chassis=2,slot=2

GPU_PASSTHROUGH_AMD?=${GPU_PASSTHROUGH}

# Shared: disk, virtio-net, 9p — ${VM_IMAGE} from OFED/SWIOTLB in sub-makes.
QEMU_COMMON=\
	-enable-kvm -cpu host,host-phys-bits=true -smp 128 -m 64G \
	-drive file=${VM_IMAGE},if=none,id=disk0,format=qcow2,snapshot=$(if $(filter 1,$(EPHEMERAL_DISK)),on,off) \
	-device virtio-blk-pci,drive=disk0,bootindex=0,disable-legacy=on,iommu_platform=on \
	-netdev tap,ifname=${TAP_INTERFACE},id=net0,script=no,downscript=no \
	-device virtio-net-pci,netdev=net0,disable-legacy=on,iommu_platform=on,romfile= \
	-nographic \
	-vga none \
	-serial null \
	-device virtio-serial \
	-chardev stdio,mux=on,id=char0,signal=off \
	-mon chardev=char0,mode=readline \
	-device virtconsole,chardev=char0,id=vc0,nr=0 \
	-virtfs local,path=./,mount_tag=gpunet,security_model=passthrough

AMD_PLAIN_COMMON=\
	${QEMU_COMMON} \
	-machine q35,accel=kvm \
	-bios ${OVMF_AMD} \

AMD_CVM_COMMON=\
	${QEMU_COMMON} \
	-machine q35,confidential-guest-support=cgs0,accel=kvm \
	-object memory-backend-memfd,size=64G,id=mem0,share=true,prealloc=false,reserve=false \
	-object sev-snp-guest,id=cgs0,cbitpos=51,reduced-phys-bits=1,policy=0x30000 \
	-bios ${OVMF_AMD} \

# --- CVM (SEV-SNP): OFED only; image is always *-noswiotlb ---

run: run.noofed

run.noofed:
	$(MAKE) OFED=0 SWIOTLB=0 _run.vm

run.ofed:
	$(MAKE) OFED=1 SWIOTLB=0 _run.vm

_run.vm: ${RDMA_PF_CLEAN} ${VM_IMAGE} ${GPU_VFIO} ${RDMA_PF_VFIO} ${TAP}
	sudo ${QEMU_AMD} \
		${AMD_CVM_COMMON} \
		${VFIO_COMMON} \
		${GPU_PASSTHROUGH_AMD} \
		${RDMA_PF_PASSTHROUGH}


run.plain: run.plain.noofed.noswiotlb

run.plain.noofed.noswiotlb:
	$(MAKE) OFED=0 SWIOTLB=0 _run.vm.plain

run.plain.noofed.swiotlb:
	$(MAKE) OFED=0 SWIOTLB=1 _run.vm.plain

run.plain.ofed.noswiotlb:
	$(MAKE) OFED=1 SWIOTLB=0 _run.vm.plain

run.plain.ofed.swiotlb:
	$(MAKE) OFED=1 SWIOTLB=1 _run.vm.plain

_run.vm.plain: ${RDMA_PF_CLEAN} ${VM_IMAGE} ${GPU_VFIO} ${RDMA_PF_VFIO} ${TAP}
	sudo ${QEMU_AMD} \
		${AMD_PLAIN_COMMON} \
		${VFIO_COMMON} \
		${GPU_PASSTHROUGH_AMD} \
		${RDMA_PF_PASSTHROUGH}
