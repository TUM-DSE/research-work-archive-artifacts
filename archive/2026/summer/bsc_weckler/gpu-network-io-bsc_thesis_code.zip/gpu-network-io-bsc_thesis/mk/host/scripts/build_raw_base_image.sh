#!/usr/bin/env bash
set -eu
set -x
shopt -s extglob
usage() {
  echo "Usage: OFED=0|1 $0 <source_prefix> <target_prefix> <size_gb>" >&2
  exit 1
}
[[ $# -eq 3 ]] || usage
OFED="${OFED:-0}"
CLANG_VERSION="${CLANG_VERSION:-22}"          # <-- new: bump here to change LLVM version
SOURCE_IMAGE=$1
TARGET=$2
IMAGE_SIZE=$3
TARGET_IMAGE="${TARGET}.qcow2"
CUDAKEYRING=images/cudakeyring.deb
OFED_INSTALL_ARGS=()
if [[ "${OFED}" == 1 ]]; then
  OFED_INSTALL_ARGS+=(
    --run-command 'curl -fsSL https://linux.mellanox.com/public/repo/doca/3.4.0/ubuntu24.04/x86_64/doca_keyring.gpg -o /usr/share/keyrings/doca_keyring.gpg'
    --run-command 'printf "Types: deb\nURIs: https://linux.mellanox.com/public/repo/doca/3.4.0/ubuntu24.04/x86_64\nSuites: /\nSigned-By: /usr/share/keyrings/doca_keyring.gpg\n" > /etc/apt/sources.list.d/doca.sources'
    --run-command 'printf "Package: *\nPin: release l=DOCA-HOST\nPin-Priority: 700\n" > /etc/apt/preferences.d/doca'
    --run-command 'apt-get remove -y sosreport'
    --install "doca-ofed"
  )
fi
rm -f "${TARGET_IMAGE}"
qemu-img create -f qcow2 -o preallocation=metadata "${TARGET_IMAGE}" "$(expr "${IMAGE_SIZE}" + 10)G"
virt-resize --format qcow2 --resize /dev/sda1="$(expr "${IMAGE_SIZE}" + 0)G" "${SOURCE_IMAGE}.qcow2" "${TARGET_IMAGE}"
for filename in tools/kernel-build/out/*; do
  virt-copy-in -a "${TARGET_IMAGE}" "${filename}" /
done
virt-copy-in -a "${TARGET_IMAGE}" "${CUDAKEYRING}" /
# Extra packages: rdma-core build.sh (see linux-rdma/rdma-core debian/control Build-Depends).
virt-customize --format qcow2 -a "${TARGET_IMAGE}" \
  --memsize 65536 \
  --smp 32 \
  --run-command "systemctl disable systemd-timesyncd" \
  --run-command "systemctl mask systemd-networkd-wait-online.service" \
  --run-command "systemctl mask network-online.target network-pre.target network.target cloud-final.service cloud-config.service open-iscsi.service iscsid.service networkd-dispatcher.service" \
  --run-command "apt autoremove --purge snapd open-iscsi -y" \
  --run-command "apt-mark hold snapd" \
  --run-command "dpkg -i /linux-image*.deb /linux-headers*.deb /linux-libc-dev*.deb" \
  --run-command "dpkg --configure -a" \
  --install "curl" \
  --install "git" \
  --install "ripgrep" \
  --install "python3" \
  --install "python-is-python3" \
  --install "build-essential" \
  --install "kmod" \
  --install "iproute2" \
  --install "ethtool" \
  --install "ibverbs-utils" \
  --install "jq" \
  --run-command 'dpkg -i /cudakeyring.deb' \
  --run-command 'apt-get update' \
  ${OFED_INSTALL_ARGS[@]+"${OFED_INSTALL_ARGS[@]}"} \
  --install "nvidia-dkms-580-open" \
  --install "nvidia-driver-580-open" \
  --run-command "echo \"install nvidia /sbin/modprobe ecdsa_generic ecdh; /sbin/modprobe --ignore-install nvidia\" >> /etc/modprobe.d/nvidia-lkca.conf" \
  --install "cuda-toolkit-12-6" \
  --install "autoconf" \
  --install "automake" \
  --install "libtool" \
  --install "pkg-config" \
  --install "cmake" \
  --install "ninja-build" \
  --install "libboost-program-options-dev" \
  --install "libudev-dev" \
  --install "libnl-3-dev" \
  --install "libnl-route-3-dev" \
  --install "libsystemd-dev" \
  --install "libssl-dev" \
  --install "python3-dev" \
  --install "cython3" \
  --install "python3-docutils" \
  --install "pandoc" \
  --install "valgrind" \
  --install "libibverbs-dev" \
  --install "libibumad-dev" \
  --install "librdmacm-dev" \
  --install "libpci-dev" \
  --install "bear" \
  --run-command "wget -qO - https://apt.llvm.org/llvm-snapshot.gpg.key | gpg --dearmor -o /usr/share/keyrings/llvm-snapshot.gpg" \
  --run-command "printf \"Types: deb\nURIs: http://apt.llvm.org/noble/\nSuites: llvm-toolchain-noble-${CLANG_VERSION}\nComponents: main\nSigned-By: /usr/share/keyrings/llvm-snapshot.gpg\n\" > /etc/apt/sources.list.d/llvm.sources" \
  --run-command "apt-get update" \
  --install "clang-${CLANG_VERSION}" \
  --install "clangd-${CLANG_VERSION}" \
  --run-command "update-alternatives --install /usr/bin/clangd clangd /usr/bin/clangd-${CLANG_VERSION} 100" \
  --run-command "update-alternatives --install /usr/bin/clang clang /usr/bin/clang-${CLANG_VERSION} 100 --slave /usr/bin/clang++ clang++ /usr/bin/clang++-${CLANG_VERSION}" \
  --run-command "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /tmp/rustup-init.sh && sh /tmp/rustup-init.sh -y --profile minimal --no-modify-path && rm -f /tmp/rustup-init.sh" \
  --run-command "ln -sf /root/.cargo/bin/cargo /root/.cargo/bin/rustc /usr/local/bin/" \
  --run-command "update-initramfs -u"
