#!/usr/bin/env bash

set -eu

RDMA_DEVICE="${RDMA_IB_DEVICE:-mlx5_0}"

for i in $(ls "/sys/class/infiniband/${RDMA_DEVICE}/ports/1/gids/" | grep -E '^[0-9]+$'); do
  gid=$(cat "/sys/class/infiniband/${RDMA_DEVICE}/ports/1/gids/$i")
  type=$(cat "/sys/class/infiniband/${RDMA_DEVICE}/ports/1/gid_attrs/types/$i" 2>/dev/null || true)
  netdev=$(cat "/sys/class/infiniband/${RDMA_DEVICE}/ports/1/gid_attrs/ndevs/$i" 2>/dev/null || true)
  [ "$gid" = "0000:0000:0000:0000:0000:0000:0000:0000" ] && continue
  echo "index $i: $gid ($type) ($netdev)"
done
