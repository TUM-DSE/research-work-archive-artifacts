.PHONY: net.setup net.del

#### VM Network Configuration ####

USERADDR=$(shell expr $(shell id -u) % 1000)
TAP_INTERFACE=tap0_${USER}
TAP=/sys/class/net/${TAP_INTERFACE}
NETPLAN_YAML=$(VM_CONFIG)/rootfs/etc/netplan/99_config.yaml

${TAP}:
	$(MAKE) net.setup

${NETPLAN_YAML}: ${NETPLAN_YAML}.in mk/host/scripts/netconf.sh
	./mk/host/scripts/netconf.sh ${NETPLAN_YAML}.in ${NETPLAN_YAML}

net.setup:
	sudo ip tuntap add ${TAP_INTERFACE} mode tap 2>/dev/null || true
	sudo ip addr replace 192.168.${USERADDR}.1/24 dev ${TAP_INTERFACE}
	sudo ip link set up dev ${TAP_INTERFACE}
	sudo iptables -t nat -C POSTROUTING -s 192.168.${USERADDR}.0/24 -j MASQUERADE 2>/dev/null || \
	sudo iptables -t nat -A POSTROUTING -s 192.168.${USERADDR}.0/24 -j MASQUERADE

net.del:
	-sudo ip link delete ${TAP_INTERFACE}
	-sudo iptables -t nat -D POSTROUTING -s 192.168.${USERADDR}.0/24 -j MASQUERADE
