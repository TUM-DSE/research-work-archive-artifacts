.PHONY: clean.img image.noofed.noswiotlb image.noofed.swiotlb image.ofed.noswiotlb image.ofed.swiotlb image.all

#### Images ####

IMAGE_DIR=images
UBUNTU_IMAGE=https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img
SOURCE_IMAGE=${IMAGE_DIR}/tmp
CUDAKEYRING=https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2404/x86_64/cuda-keyring_1.1-1_all.deb

OFED?=0
SWIOTLB?=0
OFED_VARIANT=$(if $(filter 1,${OFED}),ofed,noofed)
SWIOTLB_VARIANT=$(if $(filter 1,${SWIOTLB}),swiotlb,noswiotlb)
IMAGE_VARIANT=${OFED_VARIANT}-${SWIOTLB_VARIANT}

RAW_BASE_IMAGE=${IMAGE_DIR}/base-raw-${OFED_VARIANT}.qcow2
BASE_IMAGE=${IMAGE_DIR}/base-${IMAGE_VARIANT}.qcow2
VM_IMAGE=${IMAGE_DIR}/vm-${IMAGE_VARIANT}.qcow2
IMAGE_SIZE_GB?=170

# Inputs for the expensive raw base (kernel deb, nvidia-open, CUDA, RDMA libs).
RAW_BASE_INPUTS=${SOURCE_IMAGE}.qcow2 ${KERNEL_STAMP} ${IMAGE_DIR}/cudakeyring.deb \
	mk/host/scripts/build_raw_base_image.sh

BASE_INPUTS=${RAW_BASE_IMAGE} mk/host/scripts/build_base_image.sh \
	$(if $(filter 1,${SWIOTLB}),$(VM_CONFIG)/base/grub.swiotlb,$(VM_CONFIG)/base/grub)

VM_INPUTS=${BASE_IMAGE} mk/host/scripts/build_vm_image.sh ${NETPLAN_YAML} \
	$(shell find $(VM_CONFIG)/rootfs -type f 2>/dev/null)

${IMAGE_DIR}:
	mkdir -p $@

${IMAGE_DIR}/cudakeyring.deb: ${IMAGE_DIR}
	wget ${CUDAKEYRING} -O $@

${SOURCE_IMAGE}.qcow2: ${IMAGE_DIR}
	wget -nc ${UBUNTU_IMAGE} -O $@ || test -f $@

${RAW_BASE_IMAGE}: ${RAW_BASE_INPUTS}
	OFED=$(OFED) ./mk/host/scripts/build_raw_base_image.sh ${SOURCE_IMAGE} ${IMAGE_DIR}/base-raw-${OFED_VARIANT} ${IMAGE_SIZE_GB}

${BASE_IMAGE}: ${BASE_INPUTS}
	SWIOTLB=$(SWIOTLB) ./mk/host/scripts/build_base_image.sh ${RAW_BASE_IMAGE} ${IMAGE_DIR}/base-${IMAGE_VARIANT}

${VM_IMAGE}: ${VM_INPUTS}
	./mk/host/scripts/build_vm_image.sh ${BASE_IMAGE} ${IMAGE_DIR}/vm-${IMAGE_VARIANT}

# Concrete disk paths (for parallel prefetch: make -j4 image.all).
IMAGE_VM_NOOFED_NOSW := $(IMAGE_DIR)/vm-noofed-noswiotlb.qcow2
IMAGE_VM_NOOFED_SW := $(IMAGE_DIR)/vm-noofed-swiotlb.qcow2
IMAGE_VM_OFED_NOSW := $(IMAGE_DIR)/vm-ofed-noswiotlb.qcow2
IMAGE_VM_OFED_SW := $(IMAGE_DIR)/vm-ofed-swiotlb.qcow2

image.noofed.noswiotlb:
	$(MAKE) OFED=0 SWIOTLB=0 $(IMAGE_VM_NOOFED_NOSW)

image.noofed.swiotlb:
	$(MAKE) OFED=0 SWIOTLB=1 $(IMAGE_VM_NOOFED_SW)

image.ofed.noswiotlb:
	$(MAKE) OFED=1 SWIOTLB=0 $(IMAGE_VM_OFED_NOSW)

image.ofed.swiotlb:
	$(MAKE) OFED=1 SWIOTLB=1 $(IMAGE_VM_OFED_SW)

image.all: image.noofed.noswiotlb image.noofed.swiotlb image.ofed.noswiotlb image.ofed.swiotlb

clean.img:
	rm -rf ./${IMAGE_DIR}
