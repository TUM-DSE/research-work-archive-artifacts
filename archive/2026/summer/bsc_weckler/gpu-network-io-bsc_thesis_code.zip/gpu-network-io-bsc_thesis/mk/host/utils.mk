.PHONY: vms.list

vms.list:
	./mk/host/scripts/list-vms.sh

chown.results:
	sudo chown -R ${USER} benchmarks/bw_and_lat/results/
