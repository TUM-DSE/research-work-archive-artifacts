#!/usr/bin/env bash

set -eu

usage(){
  echo "Usage: $0 <rdma device> <ip addr>"
  exit 1
}

[[ $# -ge 2 ]] || usage

RDMA_DEVICE="$1"
IP_ADDR="$2"

# find the netdev that belongs to the rdma device
NETDEV=$(rdma link show "$RDMA_DEVICE" | grep -oP '(?<=netdev )\S+')

if [[ -z "$NETDEV" ]]; then
  echo "No netdev found for device $RDMA_DEVICE"
  exit 1
fi

# remove existing ip addresses
ip addr flush dev "$NETDEV"
ip addr add "$IP_ADDR" dev "$NETDEV"
