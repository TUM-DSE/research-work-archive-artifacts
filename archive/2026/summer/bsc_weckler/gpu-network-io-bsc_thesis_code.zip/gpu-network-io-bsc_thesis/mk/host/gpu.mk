.PHONY: gpu.info gpu.cc gpu.cc.devtools gpu.cc.off gpu.cc.on

#### GPU Host ####

GPU_PCI?=$(shell lspci -Dnn | rg -i 'NVIDIA' | head -n1 | awk '{print $$1}')
GPU_BDF?=$(shell echo "$(GPU_PCI)" | cut -d: -f2-)
GPU_IOMMU_GROUP=$(shell readlink -f /sys/bus/pci/devices/${GPU_PCI}/iommu_group 2>/dev/null | grep -oE '[0-9]+$$')
GPU_DEVICE=$(shell cat /sys/bus/pci/devices/${GPU_PCI}/device 2>/dev/null | cut -b 3-)
GPU_VENDOR=$(shell cat /sys/bus/pci/devices/${GPU_PCI}/vendor 2>/dev/null | cut -b 3-)
GPU_VFIO=$(if ${GPU_IOMMU_GROUP},/dev/vfio/${GPU_IOMMU_GROUP})

GPU_CC_MODE?=devtools

GPU_PASSTHROUGH?=\
	-device vfio-pci,host=${GPU_BDF},iommufd=iommufd_rdma,bus=pci.1,romfile=

${GPU_VFIO}:
	sudo ./tools/vfio-pci-bind/vfio-pci-bind.sh ${GPU_PCI} ${GPU_VENDOR}:${GPU_DEVICE}


gpu.info:
	echo "GPU_PCI=$(GPU_PCI)"
	echo "GPU_BDF=$(GPU_BDF)"
	echo "GPU_IOMMU_GROUP=$(GPU_IOMMU_GROUP)"
	echo "GPU_DEVICE=$(GPU_DEVICE)"
	echo "GPU_VENDOR=$(GPU_VENDOR)"
	echo "GPU_VFIO=$(GPU_VFIO)"

gpu.cc:
	sudo python ./tools/nvtrust/host_tools/python/nvidia_gpu_tools.py --gpu 0 --set-cc-mode ${GPU_CC_MODE} --reset-after-cc-mode-switch --reset-with-os

gpu.cc.devtools:
	$(MAKE) gpu.cc GPU_CC_MODE=devtools

gpu.cc.off:
	$(MAKE) gpu.cc GPU_CC_MODE=off

gpu.cc.on:
	$(MAKE) gpu.cc GPU_CC_MODE=on
