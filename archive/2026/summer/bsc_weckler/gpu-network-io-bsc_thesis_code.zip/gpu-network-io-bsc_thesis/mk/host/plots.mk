.PHONY: plots

plots:
	python3 ./plots/render.py
	python3 ./plots/collective_compact_variants.py
	python3 ./plots/e2e_variants.py --thesis
