.PHONY: gnio

gnio:
	cd $(REPO_ROOT)/src/gnio && cargo build --release
	mkdir -p $(REPO_ROOT)/bin
	ln -sfn ../src/gnio/target/release/gnio $(REPO_ROOT)/bin/gnio
