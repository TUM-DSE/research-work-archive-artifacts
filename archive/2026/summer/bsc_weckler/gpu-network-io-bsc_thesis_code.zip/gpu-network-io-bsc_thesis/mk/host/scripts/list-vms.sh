#!/usr/bin/env bash

set -u

printf "%-8s %-6s %-8s %-20s %-10s\n" "PID" "CPU" "RAM" "NET" "GPU"
printf "%s\n" "--------------------------------------------------------------------"

while read -r pid; do
  [[ -r "/proc/$pid/cmdline" ]] || continue
  mapfile -d '' -t args <"/proc/$pid/cmdline"
  [[ ${#args[@]} -gt 0 ]] || continue

  argv0="${args[0]}"
  base="${argv0##*/}"

  [[ "$base" == "qemu-system-x86_64" ]] || continue

  net="-"
  gpu="-"
  cpu="-"
  mem="-"

  for ((i = 0; i < ${#args[@]}; i++)); do
    case "${args[$i]}" in
    -smp)
      ((i + 1 < ${#args[@]})) && cpu="${args[$((i + 1))]%%,*}"
      ;;
    -m)
      ((i + 1 < ${#args[@]})) && mem="${args[$((i + 1))]}"
      ;;
    -netdev)
      if ((i + 1 < ${#args[@]})); then
        val="${args[$((i + 1))]}"
        [[ "$val" =~ ifname=([^,]+) ]] && net="${BASH_REMATCH[1]}"
      fi
      ;;
    -device)
      if ((i + 1 < ${#args[@]})); then
        val="${args[$((i + 1))]}"
        if [[ "$val" == *vfio-pci* ]] && [[ "$val" =~ host=([^,]+) ]]; then
          gpu="${BASH_REMATCH[1]}"
        fi
      fi
      ;;
    esac
  done

  [[ "$mem" =~ ^[0-9]+$ ]] && mem="${mem}M"

  printf "%-8s %-6s %-8s %-20s %-10s\n" "$pid" "$cpu" "$mem" "$net" "$gpu"
done < <(pgrep -f qemu-system-x86_64 | sort -n)
