.PHONY: ssh vm.gnio.build vm.mlx5.build vm.mlx5.reload vm.mlx5 vm.perftest.build vm.perftest.only vm.perftest.system vm.uvm vm.uvm.build vm.uvm.compile_commands vm.uvm.reload vm.uvmgpu.build

# Run guest make targets over SSH (host side).
VM_HOST ?= root@192.168.${USERADDR}.10
VM_SSH ?= ssh -A -o StrictHostKeyChecking=no ${VM_HOST}
VM_REPO ?= /root/gpunet
VM_TOOLS_MAKE ?= $(MAKE) -C ${VM_REPO} -f mk/vm/Makefile

ssh:
	${VM_SSH}

vm.gnio.build:
	${VM_SSH} '$(VM_TOOLS_MAKE) gnio.build'

vm.perftest.build:
	${VM_SSH} '$(VM_TOOLS_MAKE) perftest.build'

vm.perftest.only:
	${VM_SSH} '$(VM_TOOLS_MAKE) perftest.only'

vm.perftest.system:
	${VM_SSH} '$(VM_TOOLS_MAKE) perftest.system'

vm.uvm.build:
	${VM_SSH} '$(VM_TOOLS_MAKE) uvm.build'
	$(MAKE) vm.uvm.compile_commands

vm.uvm.compile_commands:
	$(eval UVM_KERNEL_SOURCE := $(shell ${VM_SSH} 'readlink -f /lib/modules/$$(uname -r)/build'))
	$(eval UVM_KERNEL_VERSION := $(notdir $(UVM_KERNEL_SOURCE)))
	mkdir -p .cache/$(UVM_KERNEL_VERSION)
	${VM_SSH} 'tar -C $(dir $(UVM_KERNEL_SOURCE)) -cf - $(UVM_KERNEL_VERSION)' | tar -C .cache -xf -
	$(MAKE) -C tools/open-gpu-kernel-modules compile_commands.json \
		KERNEL_SOURCE=$(UVM_KERNEL_SOURCE) \
		KERNEL_HEADERS=$(abspath .cache/$(UVM_KERNEL_VERSION))

vm.uvm.reload:
	${VM_SSH} '$(VM_TOOLS_MAKE) uvm.reload'

vm.uvm:
	${VM_SSH} '$(VM_TOOLS_MAKE) uvm'

vm.uvmgpu.build:
	${VM_SSH} '$(VM_TOOLS_MAKE) uvmgpu.build'
