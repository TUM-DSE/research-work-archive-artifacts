#!/usr/bin/env bash
# Usage: build-perftest.sh [--skip-configure] [rdma-core|system]
# Default mode when omitted: rdma-core

set -eu

usage() {
  echo "Usage: $0 [--skip-configure] [rdma-core|system]" >&2
  exit 1
}

SKIP_CONFIGURE=0
MODE="rdma-core"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-configure) SKIP_CONFIGURE=1; shift ;;
    rdma-core|system) MODE="$1"; shift ;;
    *) usage ;;
  esac
done

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")
PERFTEST_DIR="${REPO}/tools/perftest"
INSTALL_DIR="/usr/local/bin"
CUDA_H_PATH="/usr/local/cuda/include/cuda.h"
CUDA_INCLUDE_DIR="$(dirname "${CUDA_H_PATH}")"
CUDA_STUB_LIB="/usr/local/cuda/lib64/stubs"
RDMA_CORE_PATH="${REPO}/tools/rdma-core"
LIBUVMGPU_DIR="${REPO}/src/uvmgpu"
JOBS="$(nproc 2>/dev/null || echo 4)"

if [[ ! -f "$CUDA_H_PATH" ]]; then
  echo "Error: CUDA headers not found at ${CUDA_H_PATH}" >&2
  exit 1
fi
if [[ ! -d "$PERFTEST_DIR" ]] || [[ -z "$(ls -A "$PERFTEST_DIR" 2>/dev/null)" ]]; then
  echo "Error: perftest dir empty or missing: ${PERFTEST_DIR}" >&2
  exit 1
fi
if [[ "${MODE}" = "rdma-core" ]] && [[ ! -d "${RDMA_CORE_PATH}/build/include" ]]; then
  echo "Error: ${RDMA_CORE_PATH}/build/include missing; run rdma-core.build first." >&2
  exit 1
fi
if [[ ! -f "${LIBUVMGPU_DIR}/libuvmgpu.a" ]]; then
  echo "Error: ${LIBUVMGPU_DIR}/libuvmgpu.a missing; run 'make vm.uvmgpu.build' first." >&2
  exit 1
fi

cd "${PERFTEST_DIR}"

needs_configure() {
  [[ ! -f Makefile ]] ||
  [[ configure.ac -nt Makefile ]] ||
  [[ Makefile.am -nt Makefile ]]
}

if [[ "${SKIP_CONFIGURE}" -eq 0 ]] && needs_configure; then
  ./autogen.sh
  case "${MODE}" in
    rdma-core)
      ./configure \
        --enable-cudart \
        --enable-uvmgpu --with-uvmgpu="${LIBUVMGPU_DIR}" \
        CUDA_H_PATH="${CUDA_H_PATH}" \
        CFLAGS="-I${RDMA_CORE_PATH}/build/include -I${RDMA_CORE_PATH}/libibverbs -I${CUDA_INCLUDE_DIR}" \
        LDFLAGS="-L${CUDA_STUB_LIB} -L${RDMA_CORE_PATH}/build/lib -Wl,-rpath,${RDMA_CORE_PATH}/build/lib"
      ;;
    system)
      ./configure \
        --enable-cudart \
        --enable-uvmgpu --with-uvmgpu="${LIBUVMGPU_DIR}" \
        CUDA_H_PATH="${CUDA_H_PATH}" \
        CFLAGS="-I${CUDA_INCLUDE_DIR}" \
        LDFLAGS="-L${CUDA_STUB_LIB}"
      ;;
  esac
fi

# libuvmgpu.a is linked via UVMGPU_LIBS but isn't an automake-tracked
# dependency, so make won't relink the binaries when only the archive changed.
# Force it.
if [[ "${LIBUVMGPU_DIR}/libuvmgpu.a" -nt ib_write_bw ]]; then
  rm -f ib_write_bw ib_read_bw ib_send_bw ib_write_lat ib_read_lat ib_send_lat
fi

make -j"${JOBS}"

install -d "${INSTALL_DIR}"
install -m 755 \
  ib_write_bw ib_read_bw ib_send_bw ib_write_lat ib_read_lat ib_send_lat \
  "${INSTALL_DIR}/"

if [[ -f libperftest_kernels.so ]]; then
  install -d /usr/local/lib
  install -m 755 libperftest_kernels.so /usr/local/lib/
  ldconfig /usr/local/lib
fi

cd "${INSTALL_DIR}" && pwd >"${PERFTEST_DIR}/.perftest-install-path"
"${INSTALL_DIR}/ib_write_bw" --version || true
