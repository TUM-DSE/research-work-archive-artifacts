#!/usr/bin/env bash

set -eu

REPO=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-${HOME}/gnio-target}"
[ -f "${HOME}/.cargo/env" ] && source "${HOME}/.cargo/env"

cd "${REPO}/src/gnio"
find src build.rs -name '*.rs' -exec touch {} +  # 9p mtimes are unreliable, force a rebuild
cargo build --release --features gpu
install -D -m755 "${CARGO_TARGET_DIR}/release/gnio" /usr/local/bin/gnio
