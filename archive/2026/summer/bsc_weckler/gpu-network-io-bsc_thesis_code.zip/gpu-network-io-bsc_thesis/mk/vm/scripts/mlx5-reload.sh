#!/usr/bin/env bash
# Reload mlx5_ib: kill common perftest binaries, rmmod, insmod built .ko.

set -eu

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")
MOD_NAME="mlx5_ib"
KO="${REPO}/tools/linux/drivers/infiniband/hw/mlx5/${MOD_NAME}.ko"

USER_PROCS=(ib_send_bw ib_write_bw ibv_rc_pingpong ib_write_lat ib_read_bw ib_read_lat ib_send_lat)
for p in "${USER_PROCS[@]}"; do
  pkill -9 -x "$p" 2>/dev/null || true
done
sleep 0.2
modprobe -r "${MOD_NAME}" 2>/dev/null || true
modprobe mlx5_core 2>/dev/null || true
insmod_err=$(timeout 30 insmod "${KO}" 2>&1) || {
  if [[ "$insmod_err" != *"File exists"* ]]; then
    echo "[mlx5-reload] insmod failed or timed out: $insmod_err" >&2
    dmesg 2>/dev/null | grep -i mlx5 | tail -10 || true
    exit 1
  fi
}

for _i in 1 2 3 4 5 6 7 8 9 10; do
  [[ -e /dev/infiniband/uverbs0 ]] && exit 0
  sleep 0.5
done
exit 1
