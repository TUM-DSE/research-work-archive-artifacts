#!/usr/bin/env bash
# Rebuild nvidia-uvm.ko from the in-tree open-gpu-kernel-modules, inside the CVM.
set -euo pipefail

REPO=${VM_REPO:-/root/gpunet}
OGKM=${OGKM:-$REPO/tools/open-gpu-kernel-modules}
KVER=${KVER:-$(uname -r)}
JOBS=${JOBS:-$(nproc)}
FULL=${FULL:-0}

echo "[build-uvm] kernel=$KVER jobs=$JOBS tree=$OGKM"

if [[ "$FULL" == "1" || ! -f "$OGKM/kernel-open/nvidia.ko" || ! -f "$OGKM/kernel-open/Module.symvers" ]]; then
  echo "[build-uvm] full build (first build / FULL=1) — regenerating conftest"
  rm -rf "$OGKM/kernel-open/conftest"
fi

# Always `make modules` (no NV_KERNEL_MODULES filter): editing only uvm_gnio*.c
# recompiles those .o and relinks nvidia-uvm.ko, while modpost still sees
# nvidia.ko's exported symbols via the shared Module.symvers. Filtering to
# nvidia-uvm alone breaks that symbol resolution. nvidia.ko is not recompiled
# when unchanged, so incremental rebuilds stay fast.
make -C "$OGKM" modules SYSSRC="/lib/modules/$KVER/build" -j"$JOBS"

echo "[build-uvm] built: $OGKM/kernel-open/nvidia-uvm.ko"
