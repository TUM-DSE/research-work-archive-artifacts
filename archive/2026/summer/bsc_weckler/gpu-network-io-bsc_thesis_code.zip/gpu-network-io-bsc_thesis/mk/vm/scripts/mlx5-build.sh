#!/usr/bin/env bash
# Build mlx5_ib.ko from the in-tree Linux tree against the running kernel.

set -eu

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")
JOBS="$(nproc 2>/dev/null || echo 4)"
KDIR="/lib/modules/$(uname -r)/build"
KSRC="${REPO}/tools/linux"
MLX5_DIR="drivers/infiniband/hw/mlx5"
MLX5_ABI_UAPI_H="${KSRC}/include/uapi/rdma/mlx5-abi.h"
KSRC_UAPI_CPPFLAGS="-include ${MLX5_ABI_UAPI_H}"

# Sanity: warn if the KSRC kernel version doesn't match the running kernel.
# A mismatch means mlx5_ib.ko was compiled against a different mlx5_core ABI.
KSRC_VER=$(make -s -C "${KSRC}" kernelversion 2>/dev/null || true)
KDIR_VER=$(uname -r)
if [[ -n "${KSRC_VER}" && "${KDIR_VER}" != "${KSRC_VER}"* ]]; then
  echo "[mlx5-build] WARNING: KSRC version (${KSRC_VER}) != running kernel (${KDIR_VER})" >&2
  echo "[mlx5-build]   Symbol mismatches are likely. Rebuild the kernel image first." >&2
fi

make -j"${JOBS}" --no-print-directory -C "${KDIR}" M="${KSRC}/${MLX5_DIR}" modules \
  KCPPFLAGS="${KSRC_UAPI_CPPFLAGS}"
