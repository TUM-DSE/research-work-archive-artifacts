.PHONY: mlx5 mlx5.build mlx5.reload

LINUX_REPO := $(REPO_ROOT)/tools/linux

mlx5:
	bash $(GUEST_SH)/mlx5-build.sh
	bash $(GUEST_SH)/mlx5-reload.sh

mlx5.build:
	bash $(GUEST_SH)/mlx5-build.sh

mlx5.reload:
	bash $(GUEST_SH)/mlx5-reload.sh
