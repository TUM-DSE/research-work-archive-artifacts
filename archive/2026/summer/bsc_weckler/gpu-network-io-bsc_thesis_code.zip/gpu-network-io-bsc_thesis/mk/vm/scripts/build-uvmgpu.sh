#!/usr/bin/env bash
# Build libuvmgpu inside the CVM.
set -euo pipefail

REPO=${VM_REPO:-/root/gpunet}
DIR="$REPO/src/uvmgpu"

echo "[build-uvmgpu] $DIR"
make -C "$DIR" clean
make -C "$DIR"
echo "[build-uvmgpu] built: $DIR/libuvmgpu.a"
