.PHONY: nvbandwidth.build nvbandwidth.clean

NVBANDWIDTH_DIR := $(REPO_ROOT)/tools/nvbandwidth
NVBANDWIDTH_INSTALL_DIR := /usr/local/bin

nvbandwidth.build:
	bash $(GUEST_SH)/build-nvbandwidth.sh

nvbandwidth.clean:
	$(RM) -rf $(NVBANDWIDTH_DIR)/build
	$(RM) -f $(NVBANDWIDTH_INSTALL_DIR)/nvbandwidth
