#!/usr/bin/env bash

set -eu

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")
NVB_DIR="${REPO}/tools/nvbandwidth"
INSTALL_DIR="/usr/local/bin"
CUDA_PATH="${CUDA_PATH:-/usr/local/cuda}"
JOBS="$(nproc 2>/dev/null || echo 4)"

if [[ ! -d "${NVB_DIR}" ]] || [[ -z "$(ls -A "${NVB_DIR}" 2>/dev/null)" ]]; then
  echo "Error: nvbandwidth dir empty or missing: ${NVB_DIR}" >&2
  echo "Run: git submodule update --init tools/nvbandwidth" >&2
  exit 1
fi
if ! command -v cmake >/dev/null 2>&1; then
  echo "Error: cmake not found" >&2
  exit 1
fi
if [[ ! -x "${CUDA_PATH}/bin/nvcc" ]] && ! command -v nvcc >/dev/null 2>&1; then
  echo "Error: nvcc not found; set CUDA_PATH or install the CUDA toolkit" >&2
  exit 1
fi
if [[ ! -f /usr/include/boost/program_options.hpp ]]; then
  echo "Boost.program_options not found; installing libboost-program-options-dev" >&2
  SUDO=""; [[ "$(id -u)" -ne 0 ]] && SUDO="sudo"
  if ! ${SUDO} apt-get install -y libboost-program-options-dev; then
    echo "Error: could not install libboost-program-options-dev; install it manually" >&2
    exit 1
  fi
fi

export PATH="${CUDA_PATH}/bin:${PATH}"

cd "${NVB_DIR}"
cmake -DCMAKE_BUILD_TYPE=Release -B build .
cmake --build build -j"${JOBS}"

install -d "${INSTALL_DIR}"
install -m 755 build/nvbandwidth "${INSTALL_DIR}/"
"${INSTALL_DIR}/nvbandwidth" -l >/dev/null 2>&1 && echo "nvbandwidth installed: $(command -v nvbandwidth)" || true
