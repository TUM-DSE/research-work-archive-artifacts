.PHONY: uvm uvm.build uvm.reload

uvm.build:
	bash $(GUEST_SH)/build-uvm.sh

uvm.reload:
	bash $(GUEST_SH)/uvm-reload.sh

uvm: uvm.build uvm.reload
