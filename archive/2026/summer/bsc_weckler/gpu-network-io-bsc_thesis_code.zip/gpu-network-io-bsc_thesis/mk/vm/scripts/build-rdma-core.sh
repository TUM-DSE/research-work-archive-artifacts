#!/usr/bin/env bash

set -eu

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"

REPO=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")
RDMA_CORE="${REPO}/tools/rdma-core"
LINUX_REPO="${REPO}/tools/linux"
BUILDDIR="${RDMA_CORE}/build"
JOBS="$(nproc 2>/dev/null || echo 4)"

# Sync mlx5 UAPI header from the local Linux tree.
cp "${LINUX_REPO}/include/uapi/rdma/mlx5-abi.h" \
   "${RDMA_CORE}/kernel-headers/rdma/mlx5-abi.h"

mkdir -p "${BUILDDIR}"
cd "${BUILDDIR}"

# Run cmake only on first configure; after that ninja re-runs it
# automatically if CMakeLists.txt changes.
if [[ ! -f CMakeCache.txt ]]; then
    cmake -DIN_PLACE=1 ${EXTRA_CMAKE_FLAGS:-} -GNinja ..
fi

ninja
