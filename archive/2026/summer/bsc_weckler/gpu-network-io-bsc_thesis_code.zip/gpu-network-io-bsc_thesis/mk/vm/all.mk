VM_MK_DIR := $(dir $(abspath $(lastword $(MAKEFILE_LIST))))
REPO_ROOT := $(abspath $(VM_MK_DIR)/../..)
GUEST_SH := $(REPO_ROOT)/mk/vm/scripts

include $(VM_MK_DIR)linux.mk
include $(VM_MK_DIR)rdma-core.mk
include $(VM_MK_DIR)dma_heap_coh.mk
include $(VM_MK_DIR)perftest.mk
include $(VM_MK_DIR)gnio.mk
include $(VM_MK_DIR)nvbandwidth.mk
include $(VM_MK_DIR)uvm.mk
include $(VM_MK_DIR)uvmgpu.mk
