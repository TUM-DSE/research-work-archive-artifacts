.PHONY: gnio.build gnio.clean

GNIO_DIR := $(REPO_ROOT)/src/gnio
GNIO_INSTALL_DIR := /usr/local/bin

gnio.build:
	bash $(GUEST_SH)/build-gnio.sh

gnio.clean:
	$(RM) -f $(GNIO_INSTALL_DIR)/gnio
