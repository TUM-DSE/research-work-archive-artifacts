.PHONY: uvmgpu.build uvmgpu.clean

UVMGPU_DIR := $(REPO_ROOT)/src/uvmgpu

uvmgpu.build:
	bash $(GUEST_SH)/build-uvmgpu.sh

uvmgpu.clean:
	$(MAKE) -C $(UVMGPU_DIR) clean
