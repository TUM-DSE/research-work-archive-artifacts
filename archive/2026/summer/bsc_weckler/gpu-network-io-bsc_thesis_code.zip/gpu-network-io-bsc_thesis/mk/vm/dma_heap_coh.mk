.PHONY: dma_heap_coh.insert dma_heap_coh.persist dma_heap_coh.unpersist

DMA_HEAP_COH_DIR := $(REPO_ROOT)/src/dma_heap_coh

dma_heap_coh.insert:
	$(MAKE) -C $(DMA_HEAP_COH_DIR) install

dma_heap_coh.persist:
	$(MAKE) -C $(DMA_HEAP_COH_DIR) persist

dma_heap_coh.unpersist:
	$(MAKE) -C $(DMA_HEAP_COH_DIR) unpersist
