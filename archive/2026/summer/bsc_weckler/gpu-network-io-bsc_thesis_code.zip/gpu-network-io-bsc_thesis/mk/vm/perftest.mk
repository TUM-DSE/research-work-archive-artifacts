.PHONY: perftest.build perftest.only perftest.system perftest.clean

PERFTEST_DIR := $(REPO_ROOT)/tools/perftest
PERFTEST_INSTALL_DIR := /usr/local/bin
PERFTEST_BUILD_MODE ?= rdma-core

perftest.build:
	PERFTEST_BUILD_MODE="$(PERFTEST_BUILD_MODE)" $(if $(BDF),BDF="$(BDF)") bash $(GUEST_SH)/build-all.sh

perftest.only:
	bash $(GUEST_SH)/build-perftest.sh --skip-configure $(PERFTEST_BUILD_MODE)

perftest.system:
	bash $(GUEST_SH)/build-perftest.sh system

perftest.clean:
	-cd $(PERFTEST_DIR) && $(MAKE) distclean
	$(RM) -rf $(PERFTEST_INSTALL_DIR)
	$(RM) -f "$(PERFTEST_DIR)/.perftest-install-path"
