#!/usr/bin/env bash

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "${HERE}/../../lib/parser.sh"
REPO=$(gpumk_repo_root_for_script "${BASH_SOURCE[0]}")
JOBS="$(nproc 2>/dev/null || echo 4)"

step() { printf '\n=== build-all: %s ===\n' "$*"; }

step "1/4 dma_heap_coh"
sudo rmmod dma_heap_coh 2>/dev/null || true
make -j"${JOBS}" -C "${REPO}/src/dma_heap_coh" install persist ${BDF:+BDF=${BDF}}
test -e /dev/dma_heap/coh || {
  echo "build-all: ERROR: /dev/dma_heap/coh missing after install" >&2
  exit 1
}

step "2/4 rdma-core"
bash "${HERE}/build-rdma-core.sh"

step "3/4 mlx5_ib"
bash "${HERE}/mlx5-build.sh"
bash "${HERE}/mlx5-reload.sh"

step "4/4 perftest"
bash "${HERE}/build-perftest.sh" "${PERFTEST_BUILD_MODE:-rdma-core}"

step "done"
