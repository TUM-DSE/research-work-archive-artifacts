.PHONY: rdma-core.build

RDMA_CORE := $(REPO_ROOT)/tools/rdma-core

rdma-core.build:
	bash $(GUEST_SH)/build-rdma-core.sh
