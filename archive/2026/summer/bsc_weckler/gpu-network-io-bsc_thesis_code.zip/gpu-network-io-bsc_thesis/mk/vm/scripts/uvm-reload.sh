#!/usr/bin/env bash
# Hot-swap nvidia-uvm.ko inside the CVM: rmmod the running module and insmod the
# freshly built one. nvidia.ko stays loaded. nvidia-persistenced is stopped first
# (it auto-reopens /dev/nvidia-uvm and can re-trigger a module load mid-swap) and
# only restarted after the new module is in. We verify the module is actually gone
# before insmod, and assert the new srcversion is loaded afterwards, so a failed
# swap is loud rather than silently leaving the old module. If the module is busy
# (refcnt != 0) we bail rather than force a wedge; recover with a full VM relaunch
# (make clean.sys && make run from the host).
set -uo pipefail

REPO=${VM_REPO:-/root/gpunet}
OGKM=${OGKM:-$REPO/tools/open-gpu-kernel-modules}
KO="$OGKM/kernel-open/nvidia-uvm.ko"

if [[ ! -f "$KO" ]]; then
  echo "[uvm-reload] $KO not found — run build-uvm.sh first" >&2
  exit 1
fi

want=$(modinfo -F srcversion "$KO")

persistenced_was_running=0
if systemctl is-active --quiet nvidia-persistenced 2>/dev/null || pgrep -x nvidia-persistenced >/dev/null; then
  persistenced_was_running=1
  echo "[uvm-reload] stopping nvidia-persistenced"
  systemctl stop nvidia-persistenced 2>/dev/null || pkill -x nvidia-persistenced || true
fi

restore_persistenced() {
  [[ "$persistenced_was_running" == "1" ]] && systemctl start nvidia-persistenced 2>/dev/null || true
}

# Wait for any persistenced-held reference to drop, then rmmod and confirm gone.
for attempt in 1 2 3 4 5; do
  lsmod | grep -q '^nvidia_uvm' || break
  refs=$(cat /sys/module/nvidia_uvm/refcnt 2>/dev/null || echo 0)
  if [[ "$refs" != "0" ]]; then
    if [[ "$attempt" == "5" ]]; then
      echo "[uvm-reload] nvidia_uvm refcnt=$refs (busy) — not forcing. Stop GPU users first." >&2
      restore_persistenced
      exit 1
    fi
    sleep 1
    continue
  fi
  echo "[uvm-reload] rmmod nvidia_uvm (attempt $attempt)"
  rmmod nvidia_uvm 2>/dev/null || true
  sleep 1
done

if lsmod | grep -q '^nvidia_uvm'; then
  echo "[uvm-reload] could not unload nvidia_uvm" >&2
  restore_persistenced
  exit 1
fi

echo "[uvm-reload] insmod $KO"
insmod_ok=0
for try in 1 2 3; do
  if insmod "$KO" 2>/dev/null; then
    insmod_ok=1
    break
  fi
  rmmod nvidia_uvm 2>/dev/null || true
  sleep 1
done
if [[ "$insmod_ok" != "1" ]]; then
  echo "[uvm-reload] insmod failed after retries" >&2
  restore_persistenced
  exit 1
fi

restore_persistenced

got=$(cat /sys/module/nvidia_uvm/srcversion 2>/dev/null || echo "")
if [[ "$got" != "$want" ]]; then
  echo "[uvm-reload] WARNING: loaded srcversion=$got != built=$want" >&2
  exit 1
fi
echo "[uvm-reload] loaded srcversion=$got (matches build)"
