{
  lib,
  buildPythonPackage,
  python,
  protobuf,
  protobufPython,
  chakraSrc,
}:

buildPythonPackage {
  pname = "chakra";
  version = "0.0.4";
  format = "other";

  src = chakraSrc;

  nativeBuildInputs = [ protobuf ];
  propagatedBuildInputs = [ protobufPython ];

  buildPhase = ''
    runHook preBuild
    protoc --python_out=. --proto_path=schema/protobuf schema/protobuf/et_def.proto
    runHook postBuild
  '';

  installPhase = ''
    runHook preInstall
    site="$out/${python.sitePackages}"
    install -Dm644 et_def_pb2.py "$site/chakra/schema/protobuf/et_def_pb2.py"
    install -Dm644 src/third_party/utils/protolib.py "$site/chakra/src/third_party/utils/protolib.py"
    for pkg in \
      chakra \
      chakra/schema chakra/schema/protobuf \
      chakra/src chakra/src/third_party chakra/src/third_party/utils; do
      touch "$site/$pkg/__init__.py"
    done
    runHook postInstall
  '';

  pythonImportsCheck = [
    "chakra.schema.protobuf.et_def_pb2"
    "chakra.src.third_party.utils.protolib"
  ];

  meta = {
    description = "Minimal Chakra execution-trace schema (et_def) + protolib, for gnio's embedded trace generator";
    homepage = "https://github.com/mlcommons/chakra";
    license = lib.licenses.mit;
  };
}
