{
  lib,
  stdenv,
  fetchFromGitHub,
  autoreconfHook,
  cudaPackages,
  pkg-config,
  rdma-core,
  pciutils,
  openssl,
  autoAddDriverRunpath,
  perftestSrc,
}:

let
  version = "26.01.5";
  cudaToolkit = cudaPackages.cudatoolkit;
  cudaCudart = cudaPackages.cuda_cudart;
  cudaStubLibDir = "${lib.getLib cudaCudart}/lib/stubs";
in
stdenv.mkDerivation {
  pname = "perftest";
  inherit version;

  # Original repo
  #  src = fetchFromGitHub {
  #    owner = "linux-rdma";
  #    repo = "perftest";
  #    #rev = "perftest-${version}";
  #    #hash = "sha256-WcFOaG5Lzn87EZCZ8w6UTI6qtfX1wOtvF/lxSDwjEq4=";
  #	rev = "ea1c778782df3ec09b5f8101017fc0140b51a63d";
  #	hash = "sha256-O29UkU0fwbGjyuT6Rbxs1imus1CHZxTLkiyuJtOnxBc=";
  #  };

  # Bounce buffer fork
  #src = fetchFromGitHub {
  #  owner = "TUM-DSE";
  #  repo = "perftest";
  #  rev = "7cf4b8570ee59fab99531ab426de59a8034b8537";
  #  hash = "sha256-GA+I30eM4Hh39P9GnsH6WkUkiHmEXeO+kP4wbPMD9Zk=";
  #};

  # Build from source for testing
  src = perftestSrc;

  nativeBuildInputs = [
    autoreconfHook
    pkg-config
    autoAddDriverRunpath
  ];

  buildInputs = [
    rdma-core
    pciutils
    openssl
    # They derive various cuda paths from the relative to the header include dir.
    # Instead of patching the project to make this work, just use the legacy package for now
    cudaToolkit
    cudaCudart
  ];

  configureFlags = [
    "--enable-cudart"
  ];

  env.CUDA_H_PATH = "${lib.getDev cudaToolkit}/include/cuda.h";
  env.LDFLAGS = "-L${cudaStubLibDir}";

  meta = {
    description = "InfiniBand verbs performance tests";
    homepage = "https://github.com/linux-rdma/perftest";
    license = lib.licenses.bsd2;
    maintainers = with lib.maintainers; [ ths-on ];
    platforms = lib.platforms.linux;
  };
}
