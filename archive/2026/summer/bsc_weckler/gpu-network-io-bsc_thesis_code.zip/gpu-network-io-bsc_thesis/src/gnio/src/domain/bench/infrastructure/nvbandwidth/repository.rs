use color_eyre::eyre::Result;

use crate::domain::bench::repository::{NvbandwidthKind, NvbandwidthRunner};
use crate::domain::shared_kernel::model::Bandwidth;

use super::command::{execute, test_name, CommandSpec};
use super::output::parse_bw;

#[derive(Default)]
pub struct NvbandwidthCli;

impl NvbandwidthCli {
    pub fn new() -> Self {
        Self
    }
}

impl NvbandwidthRunner for NvbandwidthCli {
    fn run(&self, kind: NvbandwidthKind, size_bytes: u64, samples: u32) -> Result<Bandwidth> {
        let spec = CommandSpec::new(kind, size_bytes, samples);
        let output = execute(&spec)?;
        parse_bw(&output, test_name(kind))
    }
}
