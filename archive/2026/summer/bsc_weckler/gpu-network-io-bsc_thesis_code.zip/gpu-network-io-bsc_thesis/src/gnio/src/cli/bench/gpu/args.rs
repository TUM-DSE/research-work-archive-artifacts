use clap::{Args, ValueEnum};

use crate::domain::bench::model::{
    gpucopy::{Backend, GpuCopyPlan, Mode},
    FIXED_LATENCY_SIZE_BYTES,
};
use crate::domain::shared_kernel::model::MetricKind;
use crate::libs::gpu;

const KIB: u64 = 1 << 10;
const MIB: u64 = 1 << 20;
const GIB: u64 = 1 << 30;

const DEFAULT_SIZES: &[u64] = &[
    FIXED_LATENCY_SIZE_BYTES,
    256,
    512,
    KIB,
    2 * KIB,
    4 * KIB,
    8 * KIB,
    16 * KIB,
    32 * KIB,
    64 * KIB,
    128 * KIB,
    256 * KIB,
    512 * KIB,
    MIB,
    2 * MIB,
    4 * MIB,
    8 * MIB,
    16 * MIB,
    32 * MIB,
    64 * MIB,
    128 * MIB,
    256 * MIB,
    512 * MIB,
    GIB,
];

#[derive(Args, Debug)]
pub struct GpuArgs {
    #[arg(short, long, value_delimiter = ',', value_parser = |s: &str| s.parse::<Mode>())]
    pub mode: Vec<Mode>,

    #[arg(short, long, value_delimiter = ',')]
    pub backend: Vec<BackendArg>,

    #[arg(short, long, value_delimiter = ',')]
    pub kind: Vec<KindArg>,

    #[arg(short, long, value_delimiter = ',')]
    pub size: Vec<u64>,

    #[arg(short = 'n', long)]
    pub iters: Option<u64>,

    #[arg(short, long)]
    pub log: bool,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum BackendArg {
    Cuda,
    Uvmgpu,
    Nvbw,
}

impl BackendArg {
    fn to_backend(self) -> Backend {
        match self {
            BackendArg::Cuda => Backend::Cuda,
            BackendArg::Uvmgpu => Backend::Uvmgpu,
            BackendArg::Nvbw => Backend::Nvbw,
        }
    }
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum KindArg {
    Bw,
    Lat,
}

impl KindArg {
    fn to_kind(self) -> MetricKind {
        match self {
            KindArg::Bw => MetricKind::Bw,
            KindArg::Lat => MetricKind::Lat,
        }
    }
}

impl GpuArgs {
    pub fn persist(&self) -> bool {
        self.log
    }

    pub fn plan(&self) -> GpuCopyPlan {
        GpuCopyPlan {
            kinds: self.kinds(),
            modes: self.modes(),
            sizes: self.sizes(),
            iters: self.iters,
        }
    }

    fn kinds(&self) -> Vec<MetricKind> {
        if self.kind.is_empty() {
            vec![MetricKind::Bw, MetricKind::Lat]
        } else {
            self.kind.iter().map(|k| k.to_kind()).collect()
        }
    }

    fn modes(&self) -> Vec<Mode> {
        if !self.mode.is_empty() {
            return self.mode.clone();
        }
        if !self.backend.is_empty() {
            let cvm = gpu::detect_cc();
            let backends: Vec<Backend> = self.backend.iter().map(|b| b.to_backend()).collect();
            return Mode::ALL
                .iter()
                .copied()
                .filter(|m| m.is_cvm() == cvm && backends.contains(&m.backend()))
                .collect();
        }

        let cc = gpu::detect_cc();

        Mode::ALL
            .iter()
            .copied()
            .filter(|m| cc == m.is_cvm())
            .collect()
    }

    fn sizes(&self) -> Vec<u64> {
        if self.size.is_empty() {
            DEFAULT_SIZES.to_vec()
        } else {
            self.size.clone()
        }
    }
}
