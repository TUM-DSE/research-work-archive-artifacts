use std::sync::Arc;

use color_eyre::eyre::{ContextCompat, Result, WrapErr};

use crate::domain::bench::model::{EstimationMode, GroundTruth, PerftestView, ValidationReport};
use crate::domain::bench::service::{TransportEstimatorService, ValidationService};
use crate::domain::shared_kernel::infrastructure::CsvRepository;

pub struct ValidationServiceImpl {
    store: Arc<CsvRepository>,
    estimator: Box<dyn TransportEstimatorService>,
}

impl ValidationServiceImpl {
    pub fn new(store: Arc<CsvRepository>, estimator: Box<dyn TransportEstimatorService>) -> Self {
        Self { store, estimator }
    }
}

impl ValidationService for ValidationServiceImpl {
    fn validate(
        &self,
        mode: EstimationMode,
        against: Option<EstimationMode>,
    ) -> Result<ValidationReport> {
        let model = self.estimator.estimate(mode)?;
        let against = against.unwrap_or(mode);
        let measured = match against
            .ground_truth()
            .context("estimation mode has no directly measurable ground truth")?
        {
            GroundTruth::Perftest {
                mode,
                bw_verb,
                lat_verb,
            } => PerftestView::new(self.store.load()?, self.store.load()?).measured(
                mode,
                crate::domain::bench::model::perftest::NetworkSecurity::None,
                bw_verb,
                lat_verb,
            ),
        };

        let bw = measured
            .bw
            .error_vs(&*model)
            .wrap_err("bandwidth-curve error")?;
        let lat = measured
            .lat
            .error_vs(&*model)
            .wrap_err("latency-curve error")?;

        Ok(ValidationReport {
            mode,
            against,
            model,
            bw,
            lat,
            measured,
        })
    }
}
