#!/usr/bin/env python3
import argparse
import os

from chakra.schema.protobuf.et_def_pb2 import (
    ALL_GATHER,
    ALL_REDUCE,
    ALL_TO_ALL,
    COMM_COLL_NODE,
    REDUCE_SCATTER,
    AttributeProto,
    GlobalMetadata,
    Node,
)
from chakra.src.third_party.utils.protolib import encodeMessage as encode_message

COMM_TYPE = {
    "all_reduce": ALL_REDUCE,
    "all_gather": ALL_GATHER,
    "reduce_scatter": REDUCE_SCATTER,
    "all_to_all": ALL_TO_ALL,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--collective", required=True, choices=list(COMM_TYPE))
    ap.add_argument("--npus", type=int, required=True)
    ap.add_argument("--size-bytes", type=int, required=True)
    ap.add_argument("--out-prefix", required=True)
    args = ap.parse_args()

    parent = os.path.dirname(args.out_prefix)
    if parent:
        os.makedirs(parent, exist_ok=True)

    for rank in range(args.npus):
        node = Node()
        node.id = rank
        node.name = f"{args.collective}_{args.npus}npus_{args.size_bytes}B"
        node.type = COMM_COLL_NODE
        node.attr.append(AttributeProto(name="is_cpu_op", bool_val=False))
        node.attr.append(AttributeProto(name="comm_type", int64_val=COMM_TYPE[args.collective]))
        node.attr.append(AttributeProto(name="comm_size", int64_val=args.size_bytes))
        with open(f"{args.out_prefix}.{rank}.et", "wb") as et:
            encode_message(et, GlobalMetadata(version="0.0.4"))
            encode_message(et, node)


if __name__ == "__main__":
    main()
