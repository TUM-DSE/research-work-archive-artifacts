use std::fmt;

use color_eyre::eyre::{bail, Result};
use strum::{AsRefStr, EnumString};

use crate::domain::bench::model::curve::{BwCurve, LatCurve, FIXED_LATENCY_SIZE_BYTES};
use crate::domain::bench::model::gpucopy::ComponentCost;
use crate::domain::shared_kernel::model::{AlphaBeta, Bandwidth, CostLine, Latency};
use crate::libs::id::serde_id;
use crate::libs::schema::{styled_values_of, ColumnSchema, ColumnType, StyleToken, ValueMeta};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum EstimationMode {
    // Measured or composed node-to-node RDMA transfer paths used by the thesis.
    RdmaVmGpuDirectMeasured,
    RdmaCvmCpuBounceSingleSynthetic,
    RdmaCvmCpuBounceE2eSynthetic,
    RdmaCvmInGpuBounceSingleSynthetic,
    RdmaCvmInGpuBounceE2eSynthetic,
    RdmaCvmIdeIpsecE2eSynthetic,
}

impl EstimationMode {
    pub const ALL: [EstimationMode; 6] = [
        EstimationMode::RdmaVmGpuDirectMeasured,
        EstimationMode::RdmaCvmCpuBounceSingleSynthetic,
        EstimationMode::RdmaCvmCpuBounceE2eSynthetic,
        EstimationMode::RdmaCvmInGpuBounceSingleSynthetic,
        EstimationMode::RdmaCvmInGpuBounceE2eSynthetic,
        EstimationMode::RdmaCvmIdeIpsecE2eSynthetic,
    ];

    const fn style(self) -> &'static [StyleToken] {
        match self {
            EstimationMode::RdmaVmGpuDirectMeasured => &[StyleToken::PathGpuDirect],
            EstimationMode::RdmaCvmCpuBounceSingleSynthetic
            | EstimationMode::RdmaCvmCpuBounceE2eSynthetic => &[StyleToken::PathCpuBounce],
            EstimationMode::RdmaCvmInGpuBounceSingleSynthetic => {
                &[StyleToken::PathDesign1, StyleToken::VariantSingle]
            }
            EstimationMode::RdmaCvmInGpuBounceE2eSynthetic => {
                &[StyleToken::PathDesign1, StyleToken::VariantE2e]
            }
            EstimationMode::RdmaCvmIdeIpsecE2eSynthetic => {
                &[StyleToken::PathDesign2, StyleToken::VariantE2e]
            }
        }
    }
}

impl fmt::Display for EstimationMode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            EstimationMode::RdmaVmGpuDirectMeasured => "GPUDirect RDMA (VM)",
            EstimationMode::RdmaCvmCpuBounceSingleSynthetic => {
                "CPU bounce, modeled one-sided (CVM)"
            }
            EstimationMode::RdmaCvmCpuBounceE2eSynthetic => "CPU bounce, modeled end-to-end (CVM)",
            EstimationMode::RdmaCvmInGpuBounceSingleSynthetic => {
                "In-GPU bounce, single-sided (CVM)"
            }
            EstimationMode::RdmaCvmInGpuBounceE2eSynthetic => "In-GPU bounce, end-to-end (CVM)",
            EstimationMode::RdmaCvmIdeIpsecE2eSynthetic => {
                "Design 2, IDE + IPsec, end-to-end (CVM)"
            }
        })
    }
}

serde_id!(EstimationMode);

impl ColumnSchema for EstimationMode {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(styled_values_of(
            &EstimationMode::ALL,
            EstimationMode::style,
        ))
    }
}

// Reduce a plain bandwidth + latency curve to a cost line (the gpu-copy path uses
// `ComponentCost::from_curve` instead).
impl AlphaBeta {
    pub fn from_curve(bw: BwCurve, lat: LatCurve) -> Result<Self> {
        let Some(alpha) = lat.median_at_or_below(FIXED_LATENCY_SIZE_BYTES) else {
            bail!(
                "no median latency measurement at or below {} bytes to estimate alpha from",
                FIXED_LATENCY_SIZE_BYTES
            );
        };
        let Some(beta) = bw.peak() else {
            bail!("no bandwidth measurements to estimate beta from");
        };
        Ok(AlphaBeta::new(alpha, beta))
    }
}

// Reference size for the asymptotic bandwidth a composite reports through `ab()`.
const SUMMARY_N: f64 = (1u64 << 30) as f64;

pub trait CostModel {
    fn cost(&self, n: f64) -> Latency;

    fn bandwidth(&self, n: f64) -> Bandwidth {
        Bandwidth::from_bps(n / self.cost(n).as_secs())
    }

    fn ab(&self) -> AlphaBeta {
        AlphaBeta::new(self.cost(0.0), self.bandwidth(SUMMARY_N))
    }

    // The gpu-copy decomposition, when this model reduces to a gpu copy.
    fn gpu_copy_cost(&self) -> Option<ComponentCost> {
        None
    }

    fn label(&self) -> &str {
        let name = std::any::type_name_of_val(self);
        name.rsplit("::").next().unwrap_or(name)
    }

    fn children(&self) -> Vec<&dyn CostModel> {
        Vec::new()
    }
}

macro_rules! leaf {
    ($name:ident) => {
        pub struct $name(pub AlphaBeta);
        impl CostModel for $name {
            fn cost(&self, n: f64) -> Latency {
                self.0.cost(n)
            }
            fn ab(&self) -> AlphaBeta {
                self.0
            }
        }
    };
}

macro_rules! gpu_leaf {
    ($name:ident) => {
        pub struct $name(pub ComponentCost);
        impl CostModel for $name {
            fn cost(&self, n: f64) -> Latency {
                self.0.cost(n)
            }
            fn ab(&self) -> AlphaBeta {
                self.0.line
            }
            fn gpu_copy_cost(&self) -> Option<ComponentCost> {
                Some(self.0)
            }
        }
    };
}

gpu_leaf!(CopyCvmDtoHEncryptMeasured);
gpu_leaf!(CopyCvmDecryptHtoDMeasured);
leaf!(RdmaVmGpuDirectMeasured);
leaf!(RdmaCvmRamBypassMeasured);

pub struct RdmaCvmCpuBounceSynthetic<const SIDES: u8> {
    pub sender: Box<dyn CostModel>,
    pub ram_rdma: Box<dyn CostModel>,
    pub receiver: Box<dyn CostModel>,
}

pub type RdmaCvmCpuBounceSingleSynthetic = RdmaCvmCpuBounceSynthetic<1>;
pub type RdmaCvmCpuBounceE2eSynthetic = RdmaCvmCpuBounceSynthetic<2>;

impl<const SIDES: u8> RdmaCvmCpuBounceSynthetic<SIDES> {
    pub fn new(
        sender: Box<dyn CostModel>,
        ram_rdma: Box<dyn CostModel>,
        receiver: Box<dyn CostModel>,
    ) -> Self {
        assert!(
            matches!(SIDES, 1 | 2),
            "CPU bounce supports one or two endpoints"
        );
        Self {
            sender,
            ram_rdma,
            receiver,
        }
    }
}

impl<const SIDES: u8> CostModel for RdmaCvmCpuBounceSynthetic<SIDES> {
    fn cost(&self, n: f64) -> Latency {
        self.ab().cost(n)
    }

    fn ab(&self) -> AlphaBeta {
        let sender = self.sender.ab();
        let ram = self.ram_rdma.ab();
        if SIDES == 1 {
            AlphaBeta::new(sender.alpha + ram.alpha, sender.beta.min(ram.beta))
        } else {
            let receiver = self.receiver.ab();
            AlphaBeta::new(
                sender.alpha + ram.alpha + receiver.alpha,
                sender.beta.min(ram.beta).min(receiver.beta),
            )
        }
    }

    fn children(&self) -> Vec<&dyn CostModel> {
        let mut children = vec![&*self.sender, &*self.ram_rdma];
        if SIDES == 2 {
            children.push(&*self.receiver);
        }
        children
    }
}

// Design 1: approximate each seal/unseal endpoint with the measured confidential UVMGPU D2D
// fixed latency, then transfer over GPUDirect RDMA. The measured sealed-copy bandwidth is a lower bound on the
// unknown seal bandwidth; it is used only to prove that GPUDirect is the bottleneck.
pub struct RdmaCvmInGpuBounceSynthetic<const SIDES: u8> {
    pub endpoint_latency: Latency,
    pub sealed_bandwidth_lower_bound: Bandwidth,
    pub gdr: AlphaBeta,
}

pub type RdmaCvmInGpuBounceSingleSynthetic = RdmaCvmInGpuBounceSynthetic<1>;
pub type RdmaCvmInGpuBounceE2eSynthetic = RdmaCvmInGpuBounceSynthetic<2>;

impl<const SIDES: u8> RdmaCvmInGpuBounceSynthetic<SIDES> {
    pub fn new(
        endpoint_latency: Latency,
        sealed_bandwidth_lower_bound: Bandwidth,
        gdr: AlphaBeta,
    ) -> Result<Self> {
        assert!(
            matches!(SIDES, 1 | 2),
            "Design 1 supports one or two endpoints"
        );
        if sealed_bandwidth_lower_bound < gdr.beta {
            bail!(
                "Design 1 sealed-copy bandwidth lower bound ({:.2} GB/s) is below GPUDirect \
                 bandwidth ({:.2} GB/s), so the available measurement does not prove that the \
                 model is network-bound",
                sealed_bandwidth_lower_bound.as_gbps(),
                gdr.beta.as_gbps(),
            );
        }
        Ok(Self {
            endpoint_latency,
            sealed_bandwidth_lower_bound,
            gdr,
        })
    }
}

impl<const SIDES: u8> CostModel for RdmaCvmInGpuBounceSynthetic<SIDES> {
    fn cost(&self, n: f64) -> Latency {
        self.ab().cost(n)
    }

    fn ab(&self) -> AlphaBeta {
        AlphaBeta::new(
            self.endpoint_latency * SIDES + self.gdr.alpha,
            self.gdr.beta,
        )
    }
}

pub const DESIGN2_IDE_OPERATIONS: u8 = 6;
pub const DESIGN2_IDE_OPERATION_LATENCY_NS: f64 = 210.0;
pub const DESIGN2_ESP_LATENCY_US: f64 = 2.0;
pub const DESIGN2_IDE_BANDWIDTH_GBPS: f64 = 53.8;
pub const DESIGN2_ESP_BANDWIDTH_GBPS: f64 = 27.85;

pub struct RdmaCvmIdeIpsecE2eSynthetic {
    pub gdr: AlphaBeta,
    pub ide_operations: u8,
    pub ide_operation_latency: Latency,
    pub ide_latency: Latency,
    pub esp_latency: Latency,
    pub ide_bandwidth: Bandwidth,
    pub esp_bandwidth: Bandwidth,
}

impl RdmaCvmIdeIpsecE2eSynthetic {
    pub fn new(gdr: AlphaBeta) -> Self {
        let ide_operation_latency = Latency::from_nanos(DESIGN2_IDE_OPERATION_LATENCY_NS);
        Self {
            gdr,
            ide_operations: DESIGN2_IDE_OPERATIONS,
            ide_operation_latency,
            ide_latency: ide_operation_latency * DESIGN2_IDE_OPERATIONS,
            esp_latency: Latency::from_micros(DESIGN2_ESP_LATENCY_US),
            ide_bandwidth: Bandwidth::from_gbps(DESIGN2_IDE_BANDWIDTH_GBPS),
            esp_bandwidth: Bandwidth::from_gbps(DESIGN2_ESP_BANDWIDTH_GBPS),
        }
    }
}

impl CostModel for RdmaCvmIdeIpsecE2eSynthetic {
    fn cost(&self, n: f64) -> Latency {
        self.ab().cost(n)
    }

    fn ab(&self) -> AlphaBeta {
        AlphaBeta::new(
            self.gdr.alpha + self.ide_latency + self.esp_latency,
            self.gdr
                .beta
                .min(self.ide_bandwidth)
                .min(self.esp_bandwidth),
        )
    }
}
