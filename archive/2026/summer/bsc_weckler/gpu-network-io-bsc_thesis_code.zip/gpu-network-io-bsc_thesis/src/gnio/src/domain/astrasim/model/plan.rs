use crate::domain::astrasim::model::config::{
    NetworkConfig, RemoteMemoryConfig, RunSpec, SystemConfig,
};
use crate::domain::astrasim::model::link::Link;
use crate::domain::astrasim::model::topology::Fabric;
use crate::domain::astrasim::model::workload::Workload;
use crate::domain::astrasim::model::{Collective, CollectiveImpl, Interconnect};

#[derive(Clone, Debug)]
pub struct WorkloadCase {
    pub fabric: Fabric,
    pub workload: Workload,
}

impl WorkloadCase {
    pub fn new(fabric: Fabric, workload: Workload) -> Self {
        Self { fabric, workload }
    }
}

#[derive(Clone, Debug)]
pub struct AstraSimPlan {
    pub links: Vec<Link>,
    pub algorithms: Vec<CollectiveImpl>,
    pub cases: Vec<WorkloadCase>,
}

impl AstraSimPlan {
    pub fn new(
        links: Vec<Link>,
        algorithms: Vec<CollectiveImpl>,
        cases: Vec<WorkloadCase>,
    ) -> Self {
        Self {
            links,
            algorithms,
            cases,
        }
    }

    pub fn specs(&self) -> Vec<RunSpec> {
        // Keep every design consecutive for one case, but group the sweep by
        // algorithm. This makes console output and persisted result order
        // intuitive: all workload sizes for ring, then all for the next
        // algorithm, rather than alternating algorithms at every size.
        self.algorithms
            .iter()
            .flat_map(|algorithm| {
                self.cases.iter().flat_map(move |case| {
                    self.links.iter().filter_map(move |link| {
                        Self::supports(algorithm, &case.workload)
                            .then(|| self.spec(link, &case.fabric, *algorithm, &case.workload))
                    })
                })
            })
            .collect()
    }

    fn supports(algorithm: &CollectiveImpl, workload: &Workload) -> bool {
        match algorithm {
            CollectiveImpl::DoubleBinaryTree => matches!(
                workload,
                Workload::Micro(workload) if workload.collective == Collective::AllReduce
            ),
            CollectiveImpl::HalvingDoubling | CollectiveImpl::OneHalvingDoubling => !matches!(
                workload,
                Workload::Micro(workload) if workload.collective == Collective::AllToAll
            ),
            _ => true,
        }
    }

    fn spec(
        &self,
        link: &Link,
        fabric: &Fabric,
        algorithm: CollectiveImpl,
        workload: &Workload,
    ) -> RunSpec {
        let mut topology = Vec::new();
        let mut npus_count = Vec::new();
        let mut bandwidth_gbps = Vec::new();
        let mut latency_ns = Vec::new();
        let mut algs = Vec::new();

        for dim in &fabric.dims {
            topology.push(dim.topology);
            npus_count.push(dim.npus);
            let (bw, lat) = match dim.interconnect {
                Interconnect::Network => (link.bandwidth_gbps(), link.latency_ns()),
                Interconnect::NvLink => (400.0, 936.25),
            };
            bandwidth_gbps.push(bw);
            latency_ns.push(lat);
            algs.push(algorithm);
        }

        RunSpec {
            link: link.clone(),
            fabric: fabric.clone(),
            algorithm,
            network: NetworkConfig {
                topology,
                npus_count,
                bandwidth_gbps,
                latency_ns,
            },
            system: SystemConfig::with_algorithms(algs),
            remote_memory: RemoteMemoryConfig::default(),
            workload: workload.clone(),
        }
    }
}
