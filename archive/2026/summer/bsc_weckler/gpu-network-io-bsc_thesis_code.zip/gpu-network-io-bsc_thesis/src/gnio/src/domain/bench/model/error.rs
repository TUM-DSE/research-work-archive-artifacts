use color_eyre::eyre::{bail, Result};

#[derive(Clone, Copy, Debug)]
pub struct ErrorMetrics {
    pub n: usize,
    pub mape: f64,
    pub geomean: f64,
    pub median: f64,
    pub max: f64,
    pub rmse: f64,
    pub nrmse: f64,
    pub bias: f64,
}

impl ErrorMetrics {
    pub fn from_pairs(pairs: &[(f64, f64)]) -> Result<Self> {
        if pairs.is_empty() {
            bail!("no overlapping (predicted, actual) points to compare");
        }
        let n = pairs.len();

        let mut abs_rel = Vec::with_capacity(n);
        let mut signed_sum = 0.0;
        let mut abs_log_sum = 0.0;
        let mut sq_err_sum = 0.0;
        let mut actual_sum = 0.0;

        for &(predicted, actual) in pairs {
            if actual <= 0.0 || predicted <= 0.0 {
                bail!("non-positive value in comparison (predicted {predicted}, actual {actual})");
            }
            let signed = (predicted - actual) / actual;
            abs_rel.push(signed.abs());
            signed_sum += signed;
            abs_log_sum += (predicted / actual).ln().abs();
            sq_err_sum += (predicted - actual).powi(2);
            actual_sum += actual;
        }

        let mape = abs_rel.iter().sum::<f64>() / n as f64;
        let geomean = (abs_log_sum / n as f64).exp() - 1.0;
        let rmse = (sq_err_sum / n as f64).sqrt();
        let nrmse = rmse / (actual_sum / n as f64);
        let bias = signed_sum / n as f64;
        let max = abs_rel.iter().copied().fold(0.0_f64, f64::max);

        let mut sorted = abs_rel;
        sorted.sort_by(f64::total_cmp);
        let median = if n % 2 == 1 {
            sorted[n / 2]
        } else {
            (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
        };

        Ok(Self {
            n,
            mape,
            geomean,
            median,
            max,
            rmse,
            nrmse,
            bias,
        })
    }
}
