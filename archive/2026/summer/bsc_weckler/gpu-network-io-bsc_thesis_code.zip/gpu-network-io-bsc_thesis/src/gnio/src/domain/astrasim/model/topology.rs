use std::fmt::{self};

use color_eyre::eyre::{bail, eyre, Result};
use itertools::iproduct;
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use strum::{AsRefStr, Display, EnumString};

use crate::libs::schema::{ColumnSchema, ColumnType, StyleToken, ValueMeta};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Display, AsRefStr, EnumString)]
pub enum Topology {
    Ring,
    FullyConnected,
    Switch,
}

#[derive(
    Clone,
    Copy,
    Debug,
    PartialEq,
    Eq,
    PartialOrd,
    Ord,
    Display,
    AsRefStr,
    EnumString,
    Serialize,
    Deserialize,
)]
#[strum(serialize_all = "snake_case")]
#[serde(rename_all = "camelCase")]
pub enum CollectiveImpl {
    Ring,
    OneRing,
    Direct,
    OneDirect,
    DoubleBinaryTree,
    HalvingDoubling,
    OneHalvingDoubling,
}

impl CollectiveImpl {
    pub const ALL: [CollectiveImpl; 7] = [
        CollectiveImpl::Ring,
        CollectiveImpl::OneRing,
        CollectiveImpl::Direct,
        CollectiveImpl::OneDirect,
        CollectiveImpl::DoubleBinaryTree,
        CollectiveImpl::HalvingDoubling,
        CollectiveImpl::OneHalvingDoubling,
    ];

    // ASTRA-sim's native DoubleBinaryTree implementation is All-Reduce-only.
    // With our single dataset split it also selects only one of its two trees,
    // so it is not part of the default literature-backed comparison.
    pub const DEFAULT_MICRO_SWEEP: [CollectiveImpl; 2] =
        [CollectiveImpl::Ring, CollectiveImpl::HalvingDoubling];

    pub const DEFAULT_E2E_SWEEP: [CollectiveImpl; 2] =
        [CollectiveImpl::Ring, CollectiveImpl::HalvingDoubling];

    pub const fn result_id(self) -> &'static str {
        match self {
            CollectiveImpl::Ring => "ring",
            CollectiveImpl::OneRing => "oneRing",
            CollectiveImpl::Direct => "direct",
            CollectiveImpl::OneDirect => "oneDirect",
            CollectiveImpl::DoubleBinaryTree => "doubleBinaryTree",
            CollectiveImpl::HalvingDoubling => "halvingDoubling",
            CollectiveImpl::OneHalvingDoubling => "oneHalvingDoubling",
        }
    }

    pub const fn label(self) -> &'static str {
        match self {
            CollectiveImpl::Ring => "Ring",
            CollectiveImpl::OneRing => "One ring",
            CollectiveImpl::Direct => "All-pairs (Direct)",
            CollectiveImpl::OneDirect => "One direct",
            CollectiveImpl::DoubleBinaryTree => "Double binary tree",
            CollectiveImpl::HalvingDoubling => "Halving-doubling",
            CollectiveImpl::OneHalvingDoubling => "One halving-doubling",
        }
    }

    const fn style(self) -> &'static [StyleToken] {
        match self {
            CollectiveImpl::Ring | CollectiveImpl::OneRing => &[StyleToken::AlgorithmRing],
            CollectiveImpl::Direct | CollectiveImpl::OneDirect => &[StyleToken::AlgorithmDirect],
            CollectiveImpl::DoubleBinaryTree => &[StyleToken::AlgorithmDoubleBinaryTree],
            CollectiveImpl::HalvingDoubling | CollectiveImpl::OneHalvingDoubling => {
                &[StyleToken::AlgorithmHalvingDoubling]
            }
        }
    }
}

impl ColumnSchema for CollectiveImpl {
    fn column_type() -> ColumnType {
        ColumnType::String
    }

    fn values() -> Option<Vec<ValueMeta>> {
        Some(
            CollectiveImpl::ALL
                .iter()
                .map(|algorithm| {
                    ValueMeta::new(algorithm.result_id(), algorithm.label())
                        .styles(algorithm.style())
                })
                .collect(),
        )
    }
}

impl Topology {
    pub const ALL: [Topology; 3] = [Topology::Ring, Topology::FullyConnected, Topology::Switch];
}

#[derive(Clone, Debug, Display, AsRefStr, EnumString)]
pub enum Interconnect {
    Network,
    NvLink,
}

#[derive(Clone, Debug)]
pub struct Dim {
    pub topology: Topology,
    pub npus: u32,
    pub interconnect: Interconnect,
}

impl fmt::Display for Dim {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_fmt(format_args!(
            "{}{}({})",
            self.interconnect, self.topology, self.npus
        ))
    }
}

impl Dim {
    pub fn to_id(&self) -> String {
        format!(
            "{}-{}-{}",
            self.interconnect.as_ref(),
            self.topology.as_ref(),
            self.npus
        )
    }

    pub fn from_id(s: &str) -> Result<Self> {
        let parts: Vec<_> = s.split('-').collect();
        let [i, t, n] = parts.as_slice() else {
            bail!("Invalid dimension: {s}");
        };

        Ok(Self {
            interconnect: i.parse()?,
            topology: t.parse()?,
            npus: n.parse()?,
        })
    }
}

#[derive(Default)]
pub struct FabricBuilder {
    pub dims: Vec<Dim>,
}

impl FabricBuilder {
    pub fn switch(mut self, conn: Interconnect, npus: u32) -> Self {
        let dim = Dim {
            topology: Topology::Switch,
            npus,
            interconnect: conn,
        };

        self.dims.push(dim);
        self
    }

    pub fn ring(mut self, conn: Interconnect, npus: u32) -> Self {
        let dim = Dim {
            topology: Topology::Ring,
            npus,
            interconnect: conn,
        };

        self.dims.push(dim);
        self
    }

    pub fn fully_connected(mut self, conn: Interconnect, npus: u32) -> Self {
        let dim = Dim {
            topology: Topology::FullyConnected,
            npus,
            interconnect: conn,
        };

        self.dims.push(dim);
        self
    }

    pub fn build(self) -> Fabric {
        Fabric { dims: self.dims }
    }
}

#[derive(Clone, Debug)]
pub struct Fabric {
    pub dims: Vec<Dim>,
}

impl Fabric {
    pub fn builder() -> FabricBuilder {
        FabricBuilder::default()
    }

    pub fn nvlink_ring_network_switch(gpus: u32, nodes: u32) -> Fabric {
        Fabric::builder()
            .ring(Interconnect::NvLink, gpus)
            .switch(Interconnect::Network, nodes)
            .build()
    }

    pub fn network_ring(gpus: u32) -> Fabric {
        Fabric::builder().ring(Interconnect::Network, gpus).build()
    }

    pub fn network_switch(gpus: u32) -> Fabric {
        Fabric::builder()
            .switch(Interconnect::Network, gpus)
            .build()
    }

    pub fn network_fully_connected(gpus: u32) -> Fabric {
        Fabric::builder()
            .fully_connected(Interconnect::Network, gpus)
            .build()
    }

    pub fn sweep_1d(counts: Vec<u32>, f: impl Fn(u32) -> Fabric) -> Vec<Fabric> {
        let mut out: Vec<Fabric> = Vec::new();
        for n in &counts {
            out.push(f(*n));
        }
        out
    }

    pub fn sweep_2d(
        countsa: Vec<u32>,
        countsb: Vec<u32>,
        f: impl Fn(u32, u32) -> Fabric,
    ) -> Vec<Fabric> {
        let product: Vec<(u32, u32)> = iproduct!(countsa, countsb).collect();
        let mut out: Vec<Fabric> = Vec::new();
        for (a, b) in &product {
            out.push(f(*a, *b))
        }
        out
    }
}

impl Fabric {
    pub fn to_id(&self) -> String {
        self.dims
            .iter()
            .map(|d| format!("[{}]", d.to_id()))
            .collect()
    }

    pub fn from_id(s: &str) -> Result<Self> {
        Ok(Self {
            dims: s
                .split('[')
                .skip(1)
                .map(|b| {
                    Dim::from_id(
                        b.strip_suffix(']')
                            .ok_or_else(|| eyre!("Invalid fabric: {s}"))?,
                    )
                })
                .collect::<Result<_>>()?,
        })
    }
}

impl Serialize for Fabric {
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.serialize_str(&self.to_id())
    }
}

impl crate::libs::schema::ColumnSchema for Fabric {
    fn column_type() -> crate::libs::schema::ColumnType {
        crate::libs::schema::ColumnType::String
    }
}

impl<'de> Deserialize<'de> for Fabric {
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        Fabric::from_id(&s).map_err(serde::de::Error::custom)
    }
}

impl fmt::Display for Fabric {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let dims = self
            .dims
            .iter()
            .map(|d| d.to_string())
            .collect::<Vec<String>>();
        f.write_str(&dims.join("_"))
    }
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, Display, AsRefStr, EnumString)]
pub enum FabricPreset {
    NvLinkRingNetworkSwitch,
    NetworkRing,
    NetworkSwitch,
    NetworkFullyConnected,
}

const GPUS_PER_NODE: u32 = 8;

impl FabricPreset {
    pub const ALL: [FabricPreset; 3] = [
        FabricPreset::NetworkRing,
        FabricPreset::NetworkSwitch,
        FabricPreset::NetworkFullyConnected,
    ];

    pub fn sweep(self, npus: Vec<u32>) -> Vec<Fabric> {
        match self {
            FabricPreset::NvLinkRingNetworkSwitch => Fabric::sweep_1d(npus, |nodes| {
                Fabric::nvlink_ring_network_switch(GPUS_PER_NODE, nodes)
            }),
            FabricPreset::NetworkRing => Fabric::sweep_1d(npus, Fabric::network_ring),
            FabricPreset::NetworkSwitch => Fabric::sweep_1d(npus, Fabric::network_switch),
            FabricPreset::NetworkFullyConnected => {
                Fabric::sweep_1d(npus, Fabric::network_fully_connected)
            }
        }
    }
}
