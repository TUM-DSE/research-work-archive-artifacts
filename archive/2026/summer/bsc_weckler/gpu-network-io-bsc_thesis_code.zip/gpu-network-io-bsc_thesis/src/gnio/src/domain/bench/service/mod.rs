use crate::domain::bench::model::gpucopy::{GpuCopyMeasurement, RunConfig};
use crate::domain::bench::model::{
    CostModel, EstimationMode, EvaluationData, RdmaCvmCpuBounceE2eSynthetic,
    RdmaCvmCpuBounceSingleSynthetic, RdmaCvmIdeIpsecE2eSynthetic, RdmaCvmInGpuBounceE2eSynthetic,
    RdmaCvmInGpuBounceSingleSynthetic, RdmaVmGpuDirectMeasured, ValidationReport,
};
use color_eyre::eyre::Result;

pub mod estimator;
pub mod evaluation;
#[cfg(feature = "gpu")]
pub mod gpubench;
pub mod validation;

pub use estimator::TransportEstimatorServiceImpl;
pub use evaluation::EvaluationServiceImpl;
pub use validation::ValidationServiceImpl;

#[cfg(feature = "gpu")]
pub use gpubench::GpuBenchServiceImpl;

pub trait GpuBenchService {
    fn run(&mut self, config: &RunConfig) -> Result<Vec<GpuCopyMeasurement>>;
}

pub trait TransportEstimatorService {
    fn estimate(&self, mode: EstimationMode) -> Result<Box<dyn CostModel>>;
    fn gdr(&self) -> Result<RdmaVmGpuDirectMeasured>;
    fn cpu_bounce_single(&self) -> Result<RdmaCvmCpuBounceSingleSynthetic>;
    fn cpu_bounce_end_to_end(&self) -> Result<RdmaCvmCpuBounceE2eSynthetic>;
    fn design1_single(&self) -> Result<RdmaCvmInGpuBounceSingleSynthetic>;
    fn design1_end_to_end(&self) -> Result<RdmaCvmInGpuBounceE2eSynthetic>;
    fn design2_end_to_end(&self) -> Result<RdmaCvmIdeIpsecE2eSynthetic>;
}

pub trait EvaluationService {
    fn evaluate(&self) -> Result<EvaluationData>;
}

pub trait ValidationService {
    fn validate(
        &self,
        mode: EstimationMode,
        against: Option<EstimationMode>,
    ) -> Result<ValidationReport>;
}
