use std::sync::Arc;

use color_eyre::eyre::{ContextCompat, Result};

use crate::domain::bench::model::{
    gpucopy, perftest, CopyBandwidths, CostModel, CpuBounceBandwidths, CpuBounceLatencies,
    Design1Measurements, DesignModels, EstimationMode, EvaluationData, FlowCompletionComparison,
    GpuCopyView, PerftestView, FIXED_LATENCY_SIZE_BYTES,
};
use crate::domain::bench::service::{
    EvaluationService, TransportEstimatorService, ValidationService,
};
use crate::domain::shared_kernel::infrastructure::CsvRepository;
use crate::domain::shared_kernel::model::{Latency, Verb};

const VALIDATION_MIN_SIZE: u64 = 512;
const VALIDATION_MAX_SIZE: u64 = 2 << 20;
const FLOW_COMPARISON_SIZE: u64 = 2 << 20;

pub struct EvaluationServiceImpl {
    store: Arc<CsvRepository>,
    estimator: Box<dyn TransportEstimatorService>,
    validation: Box<dyn ValidationService>,
}

impl EvaluationServiceImpl {
    pub fn new(
        store: Arc<CsvRepository>,
        estimator: Box<dyn TransportEstimatorService>,
        validation: Box<dyn ValidationService>,
    ) -> Self {
        Self {
            store,
            estimator,
            validation,
        }
    }
}

impl EvaluationService for EvaluationServiceImpl {
    fn evaluate(&self) -> Result<EvaluationData> {
        let gpu = GpuCopyView::new(self.store.load()?, self.store.load()?);
        let fixed_gpu_latency =
            |mode: gpucopy::Mode, component: gpucopy::LatComponent| -> Result<Latency> {
                let curve = gpu.component(mode);
                curve
                    .lat
                    .get(&component)
                    .and_then(|latency| latency.median_at_or_below(FIXED_LATENCY_SIZE_BYTES))
                    .with_context(|| {
                        format!(
                            "{mode} has no {component} latency measurement at or below \
                             {FIXED_LATENCY_SIZE_BYTES} bytes"
                        )
                    })
            };
        let copy_bandwidths = CopyBandwidths {
            confidential_cuda_dtoh: gpu
                .component(gpucopy::Mode::CvmCudaCopyDtoH)
                .bw
                .peak()
                .context("confidential CUDA D2H bandwidth curve is empty")?,
            plain_cuda_dtoh: gpu
                .component(gpucopy::Mode::VmCudaCopyDtoH)
                .bw
                .peak()
                .context("plain CUDA D2H bandwidth curve is empty")?,
        };
        let design1_measurements = Design1Measurements {
            d2d_latency: fixed_gpu_latency(
                gpucopy::Mode::CvmUvmgpuCopyDtoD,
                gpucopy::LatComponent::Total,
            )?,
            driver_command_latency: fixed_gpu_latency(
                gpucopy::Mode::CvmUvmgpuCopyDtoD,
                gpucopy::LatComponent::Command,
            )?,
            driver_copy_latency: fixed_gpu_latency(
                gpucopy::Mode::CvmUvmgpuCopyDtoD,
                gpucopy::LatComponent::Copy,
            )?,
            sealed_bandwidth_lower_bound: gpu
                .component(gpucopy::Mode::CvmUvmgpuCopyDtoHSealed)
                .bw
                .peak()
                .context("sealed Copy Engine D2H bandwidth curve is empty")?,
        };
        let gdr_validation = self
            .validation
            .validate(EstimationMode::RdmaVmGpuDirectMeasured, None)?;
        let design1_validation = self
            .validation
            .validate(EstimationMode::RdmaCvmInGpuBounceSingleSynthetic, None)?;
        let cpu_bounce_validation = self
            .validation
            .validate(EstimationMode::RdmaCvmCpuBounceSingleSynthetic, None)?;
        let cpu_bounce = DesignModels::new(
            self.estimator.cpu_bounce_single()?,
            self.estimator.cpu_bounce_end_to_end()?,
        );
        let cpu_bounce_bandwidths = CpuBounceBandwidths {
            sender: cpu_bounce.end_to_end.sender.ab().beta,
            system_memory_rdma: cpu_bounce.end_to_end.ram_rdma.ab().beta,
            receiver: cpu_bounce.end_to_end.receiver.ab().beta,
        };
        let cpu_bounce_latencies = CpuBounceLatencies {
            sender: cpu_bounce.end_to_end.sender.ab().alpha,
            system_memory_rdma: cpu_bounce.end_to_end.ram_rdma.ab().alpha,
            receiver: cpu_bounce.end_to_end.receiver.ab().alpha,
        };
        let design1 = DesignModels::new(
            self.estimator.design1_single()?,
            self.estimator.design1_end_to_end()?,
        );
        let design2 = self.estimator.design2_end_to_end()?;
        let perftest = PerftestView::new(self.store.load()?, self.store.load()?);
        let gdr_latency = perftest
            .lat_curve(
                perftest::Mode::VmGpuDirectDmaBuf,
                perftest::NetworkSecurity::None,
                Verb::WriteImm,
            )
            .avg_at(FLOW_COMPARISON_SIZE)
            .context("GPUDirect latency has no 2 MiB measurement")?;
        let flow_completion = FlowCompletionComparison {
            size_bytes: FLOW_COMPARISON_SIZE,
            design1: design1.end_to_end.cost(FLOW_COMPARISON_SIZE as f64),
            design2: design2.cost(FLOW_COMPARISON_SIZE as f64),
            cpu_bounce: cpu_bounce.end_to_end.cost(FLOW_COMPARISON_SIZE as f64),
            gdr: gdr_latency,
        };

        Ok(EvaluationData {
            gdr: self.estimator.gdr()?,
            cpu_bounce,
            design1,
            design1_measurements,
            design2,
            copy_bandwidths,
            cpu_bounce_bandwidths,
            cpu_bounce_latencies,
            gdr_validation: gdr_validation.measured.lat.error_vs_range(
                &*gdr_validation.model,
                VALIDATION_MIN_SIZE,
                VALIDATION_MAX_SIZE,
            )?,
            cpu_bounce_validation: cpu_bounce_validation.measured.lat.error_vs_range(
                &*cpu_bounce_validation.model,
                VALIDATION_MIN_SIZE,
                VALIDATION_MAX_SIZE,
            )?,
            cpu_bounce_bw_validation: cpu_bounce_validation.measured.bw.error_vs_range(
                &*cpu_bounce_validation.model,
                VALIDATION_MIN_SIZE,
                VALIDATION_MAX_SIZE,
            )?,
            design1_validation: design1_validation.measured.lat.error_vs_range(
                &*design1_validation.model,
                VALIDATION_MIN_SIZE,
                VALIDATION_MAX_SIZE,
            )?,
            flow_completion,
        })
    }
}
