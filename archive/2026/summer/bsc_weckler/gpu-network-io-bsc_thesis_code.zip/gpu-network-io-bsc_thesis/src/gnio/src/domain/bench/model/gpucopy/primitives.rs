use std::fmt;

use strum::{AsRefStr, EnumString};

use crate::domain::shared_kernel::model::MetricKind;
use crate::libs::id::serde_id;
use crate::libs::schema::{styled_values_of, ColumnSchema, ColumnType, StyleToken, ValueMeta};

const MIB: u64 = 1 << 20;
const GIB: u64 = 1 << 30;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
pub enum Mode {
    // vm · cuda
    #[strum(serialize = "vm_cuda_copy_dtod")]
    VmCudaCopyDtoD,
    #[strum(serialize = "vm_cuda_copy_dtoh")]
    VmCudaCopyDtoH,
    #[strum(serialize = "vm_cuda_copy_htod")]
    VmCudaCopyHtoD,
    // vm · uvmgpu
    #[strum(serialize = "vm_uvmgpu_copy_dtod")]
    VmUvmgpuCopyDtoD,
    #[strum(serialize = "vm_uvmgpu_copy_dtoh")]
    VmUvmgpuCopyDtoH,
    #[strum(serialize = "vm_uvmgpu_copy_htod")]
    VmUvmgpuCopyHtoD,
    // vm · nvbw
    #[strum(serialize = "vm_nvbw_copy_dtod")]
    VmNvbwCopyDtoD,
    #[strum(serialize = "vm_nvbw_copy_dtoh")]
    VmNvbwCopyDtoH,
    #[strum(serialize = "vm_nvbw_copy_htod")]
    VmNvbwCopyHtoD,
    // cvm · cuda
    #[strum(serialize = "cvm_cuda_copy_dtod")]
    CvmCudaCopyDtoD,
    #[strum(serialize = "cvm_cuda_copy_dtoh")]
    CvmCudaCopyDtoH,
    #[strum(serialize = "cvm_cuda_copy_htod")]
    CvmCudaCopyHtoD,
    #[strum(serialize = "cvm_cuda_copy_dtoh_encrypt")]
    CvmCudaCopyDtoHEncrypt,
    #[strum(serialize = "cvm_cuda_copy_decrypt_htod")]
    CvmCudaCopyDecryptHtoD,
    // cvm · uvmgpu
    #[strum(serialize = "cvm_uvmgpu_copy_dtod")]
    CvmUvmgpuCopyDtoD,
    #[strum(serialize = "cvm_uvmgpu_copy_dtoh_sealed")]
    CvmUvmgpuCopyDtoHSealed,
    #[strum(serialize = "cvm_uvmgpu_copy_htod_sealed")]
    CvmUvmgpuCopyHtoDSealed,
    // cvm · nvbw
    #[strum(serialize = "cvm_nvbw_copy_dtod")]
    CvmNvbwCopyDtoD,
    #[strum(serialize = "cvm_nvbw_copy_dtoh")]
    CvmNvbwCopyDtoH,
    #[strum(serialize = "cvm_nvbw_copy_htod")]
    CvmNvbwCopyHtoD,
}

impl fmt::Display for Mode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if *self == Mode::CvmCudaCopyDtoHEncrypt {
            return f.write_str("cudaMemcpy D2H + AES-GCM encrypt (CVM)");
        }
        if *self == Mode::CvmCudaCopyDecryptHtoD {
            return f.write_str("AES-GCM decrypt + cudaMemcpy H2D (CVM)");
        }

        let env = if self.is_cvm() { "CVM" } else { "VM" };
        let backend = match self.backend() {
            Backend::Cuda => "cudaMemcpy",
            Backend::Uvmgpu => "CE copy",
            Backend::Nvbw => "nvbandwidth",
        };
        let sealed = if self.sealed() { "Sealed " } else { "" };
        write!(f, "{sealed}{backend} {} ({env})", self.direction())
    }
}

serde_id!(Mode);

impl ColumnSchema for Mode {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(styled_values_of(&Mode::ALL, Mode::style))
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum LatComponent {
    #[default]
    Total,
    Crypto,
    Command,
    Copy,
}

impl LatComponent {
    pub const ALL: [LatComponent; 4] = [
        LatComponent::Total,
        LatComponent::Crypto,
        LatComponent::Command,
        LatComponent::Copy,
    ];
}

impl fmt::Display for LatComponent {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            LatComponent::Total => "Total",
            LatComponent::Crypto => "Crypto",
            LatComponent::Command => "Command",
            LatComponent::Copy => "Copy",
        })
    }
}

serde_id!(LatComponent);

impl ColumnSchema for LatComponent {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(styled_values_of(
            &LatComponent::ALL,
            |component| match component {
                LatComponent::Total => &[StyleToken::ComponentTotal],
                LatComponent::Crypto => &[StyleToken::ComponentCrypto],
                LatComponent::Command => &[StyleToken::ComponentCommand],
                LatComponent::Copy => &[StyleToken::ComponentCopy],
            },
        ))
    }
}

impl Mode {
    const fn style(self) -> &'static [StyleToken] {
        match (self.backend(), self.is_cvm()) {
            (Backend::Cuda, false) => &[StyleToken::CopyCuda, StyleToken::CopyEnvVm],
            (Backend::Cuda, true) => &[StyleToken::CopyCuda, StyleToken::CopyEnvCvm],
            (Backend::Uvmgpu, false) => &[StyleToken::CopyCe, StyleToken::CopyEnvVm],
            (Backend::Uvmgpu, true) => &[StyleToken::CopyCe, StyleToken::CopyEnvCvm],
            (Backend::Nvbw, false) => &[StyleToken::CopyNvbandwidth, StyleToken::CopyEnvVm],
            (Backend::Nvbw, true) => &[StyleToken::CopyNvbandwidth, StyleToken::CopyEnvCvm],
        }
    }

    pub fn is_nvbw(&self) -> bool {
        self.backend() == Backend::Nvbw
    }

    pub fn supports_kind(&self, kind: MetricKind) -> bool {
        match kind {
            MetricKind::Bw => true,
            MetricKind::Lat => !self.is_nvbw(),
        }
    }

    pub const ALL: [Mode; 20] = [
        Mode::VmCudaCopyDtoD,
        Mode::VmCudaCopyDtoH,
        Mode::VmCudaCopyHtoD,
        Mode::VmUvmgpuCopyDtoD,
        Mode::VmUvmgpuCopyDtoH,
        Mode::VmUvmgpuCopyHtoD,
        Mode::VmNvbwCopyDtoD,
        Mode::VmNvbwCopyDtoH,
        Mode::VmNvbwCopyHtoD,
        Mode::CvmCudaCopyDtoD,
        Mode::CvmCudaCopyDtoH,
        Mode::CvmCudaCopyHtoD,
        Mode::CvmCudaCopyDtoHEncrypt,
        Mode::CvmCudaCopyDecryptHtoD,
        Mode::CvmUvmgpuCopyDtoD,
        Mode::CvmUvmgpuCopyDtoHSealed,
        Mode::CvmUvmgpuCopyHtoDSealed,
        Mode::CvmNvbwCopyDtoD,
        Mode::CvmNvbwCopyDtoH,
        Mode::CvmNvbwCopyHtoD,
    ];

    pub fn direction(&self) -> Direction {
        match self {
            Mode::VmCudaCopyDtoD
            | Mode::VmUvmgpuCopyDtoD
            | Mode::VmNvbwCopyDtoD
            | Mode::CvmCudaCopyDtoD
            | Mode::CvmUvmgpuCopyDtoD
            | Mode::CvmNvbwCopyDtoD => Direction::DtoD,
            Mode::VmCudaCopyDtoH
            | Mode::VmUvmgpuCopyDtoH
            | Mode::VmNvbwCopyDtoH
            | Mode::CvmCudaCopyDtoH
            | Mode::CvmCudaCopyDtoHEncrypt
            | Mode::CvmUvmgpuCopyDtoHSealed
            | Mode::CvmNvbwCopyDtoH => Direction::DtoH,
            Mode::VmCudaCopyHtoD
            | Mode::VmUvmgpuCopyHtoD
            | Mode::VmNvbwCopyHtoD
            | Mode::CvmCudaCopyHtoD
            | Mode::CvmCudaCopyDecryptHtoD
            | Mode::CvmUvmgpuCopyHtoDSealed
            | Mode::CvmNvbwCopyHtoD => Direction::HtoD,
        }
    }

    pub const fn is_cvm(&self) -> bool {
        matches!(
            self,
            Mode::CvmCudaCopyDtoD
                | Mode::CvmCudaCopyDtoH
                | Mode::CvmCudaCopyHtoD
                | Mode::CvmCudaCopyDtoHEncrypt
                | Mode::CvmCudaCopyDecryptHtoD
                | Mode::CvmUvmgpuCopyDtoD
                | Mode::CvmUvmgpuCopyDtoHSealed
                | Mode::CvmUvmgpuCopyHtoDSealed
                | Mode::CvmNvbwCopyDtoD
                | Mode::CvmNvbwCopyDtoH
                | Mode::CvmNvbwCopyHtoD
        )
    }

    pub const fn backend(&self) -> Backend {
        match self {
            Mode::VmCudaCopyDtoD
            | Mode::VmCudaCopyDtoH
            | Mode::VmCudaCopyHtoD
            | Mode::CvmCudaCopyDtoD
            | Mode::CvmCudaCopyDtoH
            | Mode::CvmCudaCopyHtoD
            | Mode::CvmCudaCopyDtoHEncrypt
            | Mode::CvmCudaCopyDecryptHtoD => Backend::Cuda,
            Mode::VmUvmgpuCopyDtoD
            | Mode::VmUvmgpuCopyDtoH
            | Mode::VmUvmgpuCopyHtoD
            | Mode::CvmUvmgpuCopyDtoD
            | Mode::CvmUvmgpuCopyDtoHSealed
            | Mode::CvmUvmgpuCopyHtoDSealed => Backend::Uvmgpu,
            Mode::VmNvbwCopyDtoD
            | Mode::VmNvbwCopyDtoH
            | Mode::VmNvbwCopyHtoD
            | Mode::CvmNvbwCopyDtoD
            | Mode::CvmNvbwCopyDtoH
            | Mode::CvmNvbwCopyHtoD => Backend::Nvbw,
        }
    }

    pub fn sealed(&self) -> bool {
        matches!(
            self,
            Mode::CvmUvmgpuCopyDtoHSealed | Mode::CvmUvmgpuCopyHtoDSealed
        )
    }

    pub fn cpu_crypto(&self) -> bool {
        matches!(
            self,
            Mode::CvmCudaCopyDtoHEncrypt | Mode::CvmCudaCopyDecryptHtoD
        )
    }

    fn max_size(&self) -> u64 {
        match self {
            // a single CE secure copy into host memory can't exceed 2 MiB per op
            Mode::CvmUvmgpuCopyHtoDSealed => 2 * MIB,
            _ if self.direction() == Direction::DtoD => GIB,
            _ => 128 * MIB,
        }
    }

    fn min_size(&self) -> u64 {
        // nvbandwidth sizes buffers in whole MiB; sub-MiB requests collapse to 1 MiB.
        if self.is_nvbw() {
            MIB
        } else {
            0
        }
    }

    pub fn supports_size(&self, size: u64) -> bool {
        size <= self.max_size() && size >= self.min_size()
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Backend {
    Cuda,
    Uvmgpu,
    Nvbw,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
pub enum Direction {
    #[strum(serialize = "dtod")]
    DtoD,
    #[strum(serialize = "dtoh")]
    DtoH,
    #[strum(serialize = "htod")]
    HtoD,
}

impl Direction {
    pub const ALL: [Direction; 3] = [Direction::DtoD, Direction::DtoH, Direction::HtoD];
}

impl fmt::Display for Direction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Direction::DtoD => "D2D",
            Direction::DtoH => "D2H",
            Direction::HtoD => "H2D",
        })
    }
}

serde_id!(Direction);
