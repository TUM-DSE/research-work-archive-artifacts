use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitStatus};

use color_eyre::eyre::{bail, Result, WrapErr};

use crate::domain::astrasim::model::{NetworkConfig, RunSpec, Workload};
use crate::domain::astrasim::repository::{AstraSimRunner, RunOutcome, TraceGenerator};
use crate::libs::fs;

use super::output::{all_ranks_finished, has_simulator_error};

const ASTRA_BIN: &str = "AstraSim_Analytical_Congestion_Unaware";

#[cfg(unix)]
fn is_known_cleanup_crash(status: &ExitStatus) -> bool {
    use std::os::unix::process::ExitStatusExt;

    matches!(status.signal(), Some(libc::SIGABRT) | Some(libc::SIGSEGV))
}

#[cfg(not(unix))]
fn is_known_cleanup_crash(_status: &ExitStatus) -> bool {
    false
}

pub struct AstraSimRunnerImpl {
    pub run_dir: PathBuf,
    pub trace_dir: PathBuf,
    pub trace_gen: Box<dyn TraceGenerator>,
}

struct ConfigFiles {
    network: PathBuf,
    system: PathBuf,
    remote_memory: PathBuf,
}

impl AstraSimRunnerImpl {
    fn run_subdir(&self, spec: &RunSpec) -> PathBuf {
        self.run_dir.join(spec.slug())
    }

    fn write_configs(&self, dir: &Path, spec: &RunSpec) -> Result<ConfigFiles> {
        let network = dir.join("network.yml");
        let system = dir.join("system.json");
        let remote_memory = dir.join("remote_memory.json");

        fs::atomic_write(&network, network_yaml(&spec.network).as_bytes())?;
        let sys_json = serde_json::to_string_pretty(&spec.system).wrap_err("serialize system")?;
        fs::atomic_write(&system, sys_json.as_bytes())?;
        let mem_json = serde_json::to_string_pretty(&spec.remote_memory)
            .wrap_err("serialize remote memory")?;
        fs::atomic_write(&remote_memory, mem_json.as_bytes())?;

        Ok(ConfigFiles {
            network,
            system,
            remote_memory,
        })
    }

    fn workload_prefix(&self, spec: &RunSpec) -> String {
        match &spec.workload {
            Workload::Micro(workload) => self
                .trace_dir
                .join(format!(
                    "{}_{}_{}",
                    workload.collective.as_ref(),
                    spec.npus(),
                    workload.size_bytes
                ))
                .to_string_lossy()
                .into_owned(),
            Workload::E2e(workload) => workload.trace_prefix.to_string_lossy().into_owned(),
        }
    }

    fn comm_group_configuration(spec: &RunSpec) -> String {
        match &spec.workload {
            Workload::Micro(_) => "empty".to_string(),
            Workload::E2e(workload) => workload.comm_group_path.to_string_lossy().into_owned(),
        }
    }
}

impl AstraSimRunner for AstraSimRunnerImpl {
    fn prepare(&self) -> Result<()> {
        fs::reset_dir(&self.run_dir)
    }

    fn generate_traces(&self, specs: &[RunSpec]) -> Result<()> {
        let mut seen = HashSet::new();
        for spec in specs {
            if matches!(spec.workload, Workload::E2e(_)) {
                continue;
            }
            let prefix = self.workload_prefix(spec);
            if seen.insert(prefix.clone()) {
                self.trace_gen.generate(spec, &prefix)?;
            }
        }
        Ok(())
    }

    fn run(&self, spec: &RunSpec) -> Result<RunOutcome> {
        let dir = self.run_subdir(spec);
        let files = self.write_configs(&dir, spec)?;
        let workload = self.workload_prefix(spec);

        let args = vec![
            format!("--workload-configuration={workload}"),
            format!("--system-configuration={}", files.system.display()),
            format!("--network-configuration={}", files.network.display()),
            format!(
                "--remote-memory-configuration={}",
                files.remote_memory.display()
            ),
            format!(
                "--comm-group-configuration={}",
                Self::comm_group_configuration(spec)
            ),
        ];

        let output = Command::new(ASTRA_BIN)
            .args(&args)
            // ASTRA-sim writes a `./log` file. Keep each concurrent run's
            // diagnostics isolated instead of letting processes race on the
            // repository-level log file.
            .current_dir(&dir)
            .output()
            .wrap_err_with(|| format!("spawn {ASTRA_BIN}"))?;
        let tail = |bytes: &[u8], n: usize| -> String {
            let text = String::from_utf8_lossy(bytes);
            let lines: Vec<&str> = text.lines().collect();
            lines[lines.len().saturating_sub(n)..].join("\n")
        };
        let stdout_text = String::from_utf8_lossy(&output.stdout);
        let status_success = output.status.success();
        let completed_without_simulator_error =
            all_ranks_finished(&stdout_text, spec.npus()) && !has_simulator_error(&stdout_text);
        let recoverable_cleanup_crash =
            is_known_cleanup_crash(&output.status) && completed_without_simulator_error;
        if !status_success && !recoverable_cleanup_crash {
            let status = output.status;
            let stderr = tail(&output.stderr, 25);
            let stdout = tail(&output.stdout, 25);
            bail!(
                "ASTRA-sim run directory: {}\n\
                 ASTRA-sim exited with {status}.\n\
                 ASTRA-sim writes its real error to stdout and ./log, not stderr.\n\
                 --- stderr ---\n{stderr}\n\
                 --- stdout (last 25 lines) ---\n{stdout}",
                dir.display()
            );
        }
        if recoverable_cleanup_crash {
            eprintln!(
                "warning: ASTRA-sim completed all {} NPUs for {} but exited with {} during cleanup; accepting the completed result.\n\
                 ASTRA-sim run directory: {}\n\
                 --- stderr (last 10 lines) ---\n{}",
                spec.npus(),
                spec.slug(),
                output.status,
                dir.display(),
                tail(&output.stderr, 10),
            );
        }
        Ok(RunOutcome {
            dir,
            stdout: stdout_text.into_owned(),
        })
    }
}

fn network_yaml(net: &NetworkConfig) -> String {
    let list = |items: Vec<String>| format!("[ {} ]", items.join(", "));
    let topology = list(net.topology.iter().map(|t| t.to_string()).collect());
    let npus = list(net.npus_count.iter().map(|n| n.to_string()).collect());
    let bandwidth = list(net.bandwidth_gbps.iter().map(|b| format!("{b}")).collect());
    let latency = list(net.latency_ns.iter().map(|l| format!("{l}")).collect());
    format!(
        "# generated by `gnio astra-sim`\n\
         topology: {topology}       # Ring, Switch, FullyConnected\n\
         npus_count: {npus}         # NPUs per dimension\n\
         bandwidth: {bandwidth}     # GB/s per dimension (beta)\n\
         latency: {latency}         # ns per dimension (alpha)\n",
    )
}
