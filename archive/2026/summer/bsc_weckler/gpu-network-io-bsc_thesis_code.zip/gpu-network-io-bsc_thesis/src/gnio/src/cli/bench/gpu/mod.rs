mod args;
pub mod render;

pub use args::GpuArgs;

use color_eyre::eyre::Result;

use crate::cli::di;
use render::ConsoleObserver;

pub fn run(args: GpuArgs) -> Result<()> {
    let mut app = di::gpu_benchmark();
    let plan = args.plan();
    let mut observer = ConsoleObserver::new();
    let report = app.run_bench(&plan, args.persist(), &mut observer)?;
    crate::cli::common::run_summary(report.planned, report.persisted);
    Ok(())
}
