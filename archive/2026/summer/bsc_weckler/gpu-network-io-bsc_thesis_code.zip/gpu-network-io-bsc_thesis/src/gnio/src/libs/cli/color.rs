use std::io::IsTerminal;

use owo_colors::OwoColorize;

pub fn enabled() -> bool {
    if std::env::var_os("NO_COLOR").is_some() {
        return false;
    }
    if std::env::var_os("CLICOLOR_FORCE").is_some() {
        return true;
    }
    std::io::stdout().is_terminal()
}

pub fn dim(s: &str, on: bool) -> String {
    if on {
        s.dimmed().to_string()
    } else {
        s.to_string()
    }
}

pub fn bold(s: &str, on: bool) -> String {
    if on {
        s.bold().to_string()
    } else {
        s.to_string()
    }
}

pub fn cyan(s: &str, on: bool) -> String {
    if on {
        s.cyan().to_string()
    } else {
        s.to_string()
    }
}

pub fn green_bold(s: &str, on: bool) -> String {
    if on {
        s.green().bold().to_string()
    } else {
        s.to_string()
    }
}

pub fn magenta(s: &str, on: bool) -> String {
    if on {
        s.magenta().to_string()
    } else {
        s.to_string()
    }
}

pub fn plain(s: &str, _on: bool) -> String {
    s.to_string()
}

pub fn graded(s: &str, frac: f64, on: bool) -> String {
    if !on {
        return s.to_string();
    }
    let a = frac.abs();
    if a <= 0.10 {
        s.green().to_string()
    } else if a <= 0.20 {
        s.truecolor(255, 165, 0).to_string()
    } else {
        s.red().to_string()
    }
}

pub fn indexed(s: &str, i: usize, on: bool) -> String {
    if !on {
        return s.to_string();
    }
    use colored::Colorize;
    const PALETTE: [colored::Color; 8] = [
        colored::Color::Cyan,
        colored::Color::Green,
        colored::Color::Magenta,
        colored::Color::Yellow,
        colored::Color::Blue,
        colored::Color::Red,
        colored::Color::BrightCyan,
        colored::Color::BrightMagenta,
    ];
    s.color(PALETTE[i % PALETTE.len()]).to_string()
}
