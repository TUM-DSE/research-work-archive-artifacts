use serde::{Deserialize, Serialize};
use strum::{AsRefStr, EnumString};

use crate::libs::id::serde_id;
use crate::libs::schema::{values_of, ColumnSchema, ColumnType, ValueMeta};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct QpCount(pub u32);

impl ColumnSchema for QpCount {
    fn column_type() -> ColumnType {
        ColumnType::Integer
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum MetricKind {
    Bw,
    Lat,
}

impl MetricKind {
    pub fn as_str(self) -> &'static str {
        match self {
            MetricKind::Bw => "bw",
            MetricKind::Lat => "lat",
        }
    }
}

impl std::fmt::Display for MetricKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum Verb {
    Read,
    Write,
    WriteImm,
}

impl Verb {
    pub const ALL: [Verb; 3] = [Verb::Read, Verb::Write, Verb::WriteImm];
}

impl std::fmt::Display for Verb {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Verb::Read => "Read",
            Verb::Write => "Write",
            Verb::WriteImm => "Write (imm)",
        })
    }
}

serde_id!(Verb);

impl ColumnSchema for Verb {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(values_of(&Verb::ALL))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum Direction {
    Uni,
    Bidir,
}

impl Direction {
    pub const ALL: [Direction; 2] = [Direction::Uni, Direction::Bidir];
}

impl std::fmt::Display for Direction {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Direction::Uni => "Unidirectional",
            Direction::Bidir => "Bidirectional",
        })
    }
}

serde_id!(Direction);

impl ColumnSchema for Direction {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(values_of(&Direction::ALL))
    }
}
