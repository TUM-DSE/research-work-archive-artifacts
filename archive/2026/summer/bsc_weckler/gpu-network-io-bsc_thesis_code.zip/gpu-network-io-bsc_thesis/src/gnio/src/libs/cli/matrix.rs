use crate::libs::cli::{color, fmt, table};

pub enum Column {
    Series(usize),
    Delta { vm: usize, cvm: usize },
}

pub fn render(
    labels: &[String],
    cols: &[Column],
    sizes: &[u64],
    value: impl Fn(usize, u64) -> Option<f64>,
    c: bool,
) -> String {
    let mut header = vec!["size".to_string()];
    for col in cols {
        match col {
            Column::Series(i) => header.push(labels[*i].clone()),
            Column::Delta { .. } => header.push(color::dim("Δ", c)),
        }
    }
    let href: Vec<&str> = header.iter().map(String::as_str).collect();

    let rows: Vec<Vec<String>> = sizes
        .iter()
        .map(|&n| {
            let mut row = vec![fmt::size(n)];
            for col in cols {
                match col {
                    Column::Series(i) => row.push(cell(value(*i, n), c)),
                    Column::Delta { vm, cvm } => {
                        row.push(delta_cell(value(*vm, n), value(*cvm, n), c))
                    }
                }
            }
            row
        })
        .collect();

    table::psql(&href, rows, 1)
}

fn cell(v: Option<f64>, c: bool) -> String {
    match v {
        Some(x) => format!("{x:.2}"),
        None => color::dim("-", c),
    }
}

fn delta_cell(vm: Option<f64>, cvm: Option<f64>, c: bool) -> String {
    match (vm, cvm) {
        (Some(v), Some(cv)) if v != 0.0 => {
            let frac = (cv - v) / v;
            color::graded(&format!("{:+.0}%", frac * 100.0), frac, c)
        }
        _ => color::dim("-", c),
    }
}
