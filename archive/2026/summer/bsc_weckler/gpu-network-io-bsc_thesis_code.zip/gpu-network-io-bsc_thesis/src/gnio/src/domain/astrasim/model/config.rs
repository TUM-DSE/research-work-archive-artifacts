use serde::Serialize;

use crate::domain::astrasim::model::topology::{CollectiveImpl, Topology};
use crate::domain::astrasim::model::workload::Workload;
use crate::domain::astrasim::model::{Fabric, Link};

pub const LOCAL_MEMORY_BANDWIDTH_GBPS: u32 = 3_350;
pub const REDUCTION_MEMORY_ACCESSES: u8 = 3;

#[derive(Debug, Clone)]
pub struct NetworkConfig {
    pub topology: Vec<Topology>,
    pub npus_count: Vec<u32>,
    pub bandwidth_gbps: Vec<f64>,
    pub latency_ns: Vec<f64>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct SystemConfig {
    pub scheduling_policy: String,
    pub endpoint_delay: u32,
    pub active_chunks_per_dimension: u32,
    pub preferred_dataset_splits: u32,
    pub all_reduce_implementation: Vec<CollectiveImpl>,
    pub all_gather_implementation: Vec<CollectiveImpl>,
    pub reduce_scatter_implementation: Vec<CollectiveImpl>,
    pub all_to_all_implementation: Vec<CollectiveImpl>,
    pub collective_optimization: String,
    pub local_mem_bw: u32,
}

impl SystemConfig {
    pub fn with_algorithms(algs: Vec<CollectiveImpl>) -> Self {
        // ASTRA-sim's halving/doubling implementation does not support
        // All-to-All. E2E traces can mix All-to-All with supported
        // collectives, so use Direct for only those operations.
        let all_to_all_implementation = algs
            .iter()
            .map(|algorithm| match algorithm {
                CollectiveImpl::HalvingDoubling | CollectiveImpl::OneHalvingDoubling => {
                    CollectiveImpl::Direct
                }
                algorithm => *algorithm,
            })
            .collect();
        Self {
            scheduling_policy: "LIFO".to_string(),
            endpoint_delay: 1,
            active_chunks_per_dimension: 1,
            preferred_dataset_splits: 1,
            all_reduce_implementation: algs.clone(),
            all_gather_implementation: algs.clone(),
            reduce_scatter_implementation: algs.clone(),
            all_to_all_implementation,
            collective_optimization: "localBWAware".to_string(),
            local_mem_bw: LOCAL_MEMORY_BANDWIDTH_GBPS,
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct RemoteMemoryConfig {
    #[serde(rename = "memory-type")]
    pub memory_type: String,
}

impl Default for RemoteMemoryConfig {
    fn default() -> Self {
        Self {
            memory_type: "NO_MEMORY_EXPANSION".to_string(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct RunSpec {
    pub link: Link,
    pub fabric: Fabric,
    pub algorithm: CollectiveImpl,
    pub network: NetworkConfig,
    pub system: SystemConfig,
    pub remote_memory: RemoteMemoryConfig,
    pub workload: Workload,
}

impl RunSpec {
    pub fn npus(&self) -> u32 {
        self.network.npus_count.iter().product()
    }

    pub fn slug(&self) -> String {
        format!(
            "{}__{}__{}__{}",
            self.link.design.as_ref(),
            self.fabric.to_id(),
            self.algorithm.as_ref(),
            self.workload.to_id()
        )
    }
}
