use color_eyre::eyre::{eyre, Result};

use crate::domain::bench::model::{BwPoint, LatPoint};
use crate::domain::shared_kernel::model::{Bandwidth, Latency};

pub fn parse_bw(text: &str, size: u64) -> Result<BwPoint> {
    let mut rows: Vec<(u64, BwPoint)> = Vec::new();
    for line in text.lines() {
        let Some(tokens) = numeric_row(line) else {
            continue;
        };
        if tokens.len() < 5 {
            continue;
        }
        let Some(row_size) = tokens[0].parse::<u64>().ok() else {
            continue;
        };
        let (Some(peak), Some(avg), Some(rate)) = (
            leading_f64(tokens[2]),
            leading_f64(tokens[3]),
            leading_f64(tokens[4]),
        ) else {
            continue;
        };
        rows.push((
            row_size,
            BwPoint {
                peak: Bandwidth::from_mibps(peak),
                avg: Bandwidth::from_mibps(avg),
                msg_rate_mpps: rate,
            },
        ));
    }
    pick(rows, size).ok_or_else(|| eyre!("no bandwidth result row in perftest output"))
}

pub fn parse_lat(text: &str, size: u64) -> Result<LatPoint> {
    let mut rows: Vec<(u64, LatPoint)> = Vec::new();
    for line in text.lines() {
        let Some(tokens) = numeric_row(line) else {
            continue;
        };
        if tokens.len() < 9 {
            continue;
        }
        let Some(row_size) = tokens[0].parse::<u64>().ok() else {
            continue;
        };
        let Some(v) = tokens[2..9]
            .iter()
            .map(|t| leading_f64(t))
            .collect::<Option<Vec<f64>>>()
        else {
            continue;
        };
        rows.push((
            row_size,
            LatPoint {
                min: Latency::from_micros(v[0]),
                max: Latency::from_micros(v[1]),
                typical: Latency::from_micros(v[2]),
                avg: Latency::from_micros(v[3]),
                stdev: Latency::from_micros(v[4]),
                p99: Latency::from_micros(v[5]),
                p999: Latency::from_micros(v[6]),
            },
        ));
    }
    pick(rows, size).ok_or_else(|| eyre!("no latency result row in perftest output"))
}

fn pick<M>(mut rows: Vec<(u64, M)>, size: u64) -> Option<M> {
    if let Some(i) = rows.iter().rposition(|(s, _)| *s == size) {
        Some(rows.swap_remove(i).1)
    } else {
        rows.pop().map(|(_, m)| m)
    }
}

fn numeric_row(line: &str) -> Option<Vec<&str>> {
    let tokens: Vec<&str> = line.split_whitespace().collect();
    if tokens.len() >= 2 && tokens[0].parse::<u64>().is_ok() && tokens[1].parse::<u64>().is_ok() {
        Some(tokens)
    } else {
        None
    }
}

fn leading_f64(token: &str) -> Option<f64> {
    let end = token
        .find(|c: char| !(c.is_ascii_digit() || c == '.'))
        .unwrap_or(token.len());
    token[..end].parse().ok()
}
