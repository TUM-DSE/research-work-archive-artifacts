use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::OnceLock;

use color_eyre::eyre::{bail, Result, WrapErr};

use crate::domain::astrasim::model::{RunSpec, Workload};
use crate::domain::astrasim::repository::TraceGenerator;
use crate::libs::fs;

const SCRIPT: &str = include_str!("../../../../../assets/astra_gen_trace.py");

pub struct PyTraceGenerator {
    python: String,
    script_path: OnceLock<PathBuf>,
}

impl PyTraceGenerator {
    pub fn new() -> Self {
        Self {
            python: std::env::var("GNIO_PYTHON").unwrap_or_else(|_| "python3".to_string()),
            script_path: OnceLock::new(),
        }
    }

    fn script(&self) -> Result<&Path> {
        if let Some(p) = self.script_path.get() {
            return Ok(p.as_path());
        }
        let path = std::env::temp_dir().join("gnio_astra_gen_trace.py");
        fs::atomic_write(&path, SCRIPT.as_bytes())?;
        let _ = self.script_path.set(path);
        Ok(self.script_path.get().expect("just set").as_path())
    }
}

impl Default for PyTraceGenerator {
    fn default() -> Self {
        Self::new()
    }
}

impl TraceGenerator for PyTraceGenerator {
    fn generate(&self, spec: &RunSpec, prefix: &str) -> Result<()> {
        let (collective, size_bytes) = match &spec.workload {
            Workload::Micro(workload) => (workload.collective, workload.size_bytes),
            Workload::E2e(_) => return Ok(()),
        };
        let npus = spec.npus();

        if (0..npus).all(|r| Path::new(&format!("{prefix}.{r}.et")).exists()) {
            return Ok(());
        }

        let out = Command::new(&self.python)
            .arg(self.script()?)
            .arg("--collective")
            .arg(collective.as_ref())
            .arg("--npus")
            .arg(npus.to_string())
            .arg("--size-bytes")
            .arg(size_bytes.to_string())
            .arg("--out-prefix")
            .arg(prefix)
            .output()
            .wrap_err_with(|| format!("spawn `{}` for trace generation", self.python))?;
        if !out.status.success() {
            bail!(
                "trace generation failed for {prefix}: {}",
                String::from_utf8_lossy(&out.stderr).trim()
            );
        }
        Ok(())
    }
}
