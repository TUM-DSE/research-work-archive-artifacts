use std::sync::Arc;

use color_eyre::eyre::{Result, WrapErr};

use crate::domain::bench::model::gpucopy::ComponentCost;
use crate::domain::bench::model::{
    gpucopy, perftest, CopyCvmDecryptHtoDMeasured, CopyCvmDtoHEncryptMeasured, CostModel,
    EstimationMode, GpuCopyView, PerftestView, RdmaCvmCpuBounceE2eSynthetic,
    RdmaCvmCpuBounceSingleSynthetic, RdmaCvmCpuBounceSynthetic, RdmaCvmIdeIpsecE2eSynthetic,
    RdmaCvmInGpuBounceE2eSynthetic, RdmaCvmInGpuBounceSingleSynthetic, RdmaCvmInGpuBounceSynthetic,
    RdmaCvmRamBypassMeasured, RdmaVmGpuDirectMeasured,
};
use crate::domain::bench::service::TransportEstimatorService;
use crate::domain::shared_kernel::infrastructure::CsvRepository;
use crate::domain::shared_kernel::model::{AlphaBeta, Verb};

pub struct TransportEstimatorServiceImpl {
    store: Arc<CsvRepository>,
}

impl TransportEstimatorServiceImpl {
    pub fn new(store: Arc<CsvRepository>) -> Self {
        Self { store }
    }

    fn gpu_leaf(&self, mode: gpucopy::Mode) -> Result<ComponentCost> {
        let view = GpuCopyView::new(self.store.load()?, self.store.load()?);
        ComponentCost::from_curve(view.component(mode))
            .wrap_err_with(|| format!("gpu-copy leaf {mode}"))
    }

    fn perftest_leaf(
        &self,
        mode: perftest::Mode,
        bw_verb: Verb,
        lat_verb: Verb,
    ) -> Result<AlphaBeta> {
        let view = PerftestView::new(self.store.load()?, self.store.load()?);
        AlphaBeta::from_curve(
            view.bw_curve(mode, perftest::NetworkSecurity::None, bw_verb),
            view.lat_curve(mode, perftest::NetworkSecurity::None, lat_verb),
        )
        .wrap_err_with(|| format!("perftest leaf {mode} (bw={bw_verb}, lat={lat_verb})"))
    }

    fn design1<const SIDES: u8>(&self) -> Result<RdmaCvmInGpuBounceSynthetic<SIDES>> {
        let d2d = self.gpu_leaf(gpucopy::Mode::CvmUvmgpuCopyDtoD)?;
        let sealed = self.gpu_leaf(gpucopy::Mode::CvmUvmgpuCopyDtoHSealed)?;
        RdmaCvmInGpuBounceSynthetic::new(d2d.line.alpha, sealed.line.beta, self.gdr()?.0)
    }

    fn cpu_bounce<const SIDES: u8>(&self) -> Result<RdmaCvmCpuBounceSynthetic<SIDES>> {
        Ok(RdmaCvmCpuBounceSynthetic::new(
            Box::new(CopyCvmDtoHEncryptMeasured(
                self.gpu_leaf(gpucopy::Mode::CvmCudaCopyDtoHEncrypt)?,
            )),
            Box::new(RdmaCvmRamBypassMeasured(self.perftest_leaf(
                perftest::Mode::CvmRamBypass,
                Verb::Write,
                Verb::WriteImm,
            )?)),
            Box::new(CopyCvmDecryptHtoDMeasured(
                self.gpu_leaf(gpucopy::Mode::CvmCudaCopyDecryptHtoD)?,
            )),
        ))
    }
}

impl TransportEstimatorService for TransportEstimatorServiceImpl {
    fn estimate(&self, mode: EstimationMode) -> Result<Box<dyn CostModel>> {
        use EstimationMode as M;
        Ok(match mode {
            M::RdmaVmGpuDirectMeasured => Box::new(self.gdr()?),
            M::RdmaCvmCpuBounceSingleSynthetic => Box::new(self.cpu_bounce_single()?),
            M::RdmaCvmCpuBounceE2eSynthetic => Box::new(self.cpu_bounce_end_to_end()?),
            M::RdmaCvmInGpuBounceSingleSynthetic => Box::new(self.design1_single()?),
            M::RdmaCvmInGpuBounceE2eSynthetic => Box::new(self.design1_end_to_end()?),
            M::RdmaCvmIdeIpsecE2eSynthetic => Box::new(self.design2_end_to_end()?),
        })
    }

    fn gdr(&self) -> Result<RdmaVmGpuDirectMeasured> {
        Ok(RdmaVmGpuDirectMeasured(self.perftest_leaf(
            perftest::Mode::VmGpuDirectDmaBuf,
            Verb::Write,
            Verb::WriteImm,
        )?))
    }

    fn cpu_bounce_single(&self) -> Result<RdmaCvmCpuBounceSingleSynthetic> {
        self.cpu_bounce::<1>()
    }

    fn cpu_bounce_end_to_end(&self) -> Result<RdmaCvmCpuBounceE2eSynthetic> {
        self.cpu_bounce::<2>()
    }

    fn design1_single(&self) -> Result<RdmaCvmInGpuBounceSingleSynthetic> {
        self.design1::<1>()
    }

    fn design1_end_to_end(&self) -> Result<RdmaCvmInGpuBounceE2eSynthetic> {
        self.design1::<2>()
    }

    fn design2_end_to_end(&self) -> Result<RdmaCvmIdeIpsecE2eSynthetic> {
        Ok(RdmaCvmIdeIpsecE2eSynthetic::new(self.gdr()?.0))
    }
}
