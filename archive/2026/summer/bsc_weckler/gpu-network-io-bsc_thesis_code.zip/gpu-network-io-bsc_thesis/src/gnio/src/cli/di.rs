use std::path::PathBuf;
use std::sync::Arc;

use crate::domain::astrasim::infrastructure::astrasim::{
    AstraSimRunnerImpl, PyTraceGenerator, ResultParserImpl, StageTraceRepository,
};
use crate::domain::astrasim::presentation::{AstraResultsApplication, AstraSimApplication};
use crate::domain::astrasim::service::AstraSimService;
use crate::domain::bench::infrastructure::perftest::PerftestCli;
use crate::domain::bench::presentation::{
    EstimationApplication, EvaluationApplication, PerftestApplication, ValidationApplication,
};
use crate::domain::bench::service::{
    EvaluationServiceImpl, TransportEstimatorServiceImpl, ValidationServiceImpl,
};
use crate::domain::shared_kernel::infrastructure::CsvRepository;
use crate::domain::thesis::infrastructure::astrasim_results::AstraSimResultsRepository;
use crate::domain::thesis::infrastructure::bench_results::BenchResultsRepository;
use crate::domain::thesis::infrastructure::typst::TypstRepository;
use crate::domain::thesis::presentation::ThesisApplication;
use crate::domain::thesis::service::EvaluationServiceImpl as ThesisEvaluationService;
use crate::libs::fs;

#[cfg(feature = "gpu")]
use crate::domain::bench::infrastructure::nvbandwidth::NvbandwidthCli;
#[cfg(feature = "gpu")]
use crate::domain::bench::presentation::GpuApplication;
#[cfg(feature = "gpu")]
use crate::domain::bench::service::GpuBenchServiceImpl;

const ASTRA_RUNS: &str = "benchmarks/astra-sim/runs";
const ASTRA_TRACES: &str = "benchmarks/astra-sim/traces";
const STAGE: &str = "tools/stage";

pub fn results_dir(sub: &str) -> PathBuf {
    resolve(sub)
}

fn resolve(sub: &str) -> PathBuf {
    match fs::repo_root() {
        Some(root) => root.join(sub),
        None => PathBuf::from(sub),
    }
}

pub fn astra_runs_dir() -> PathBuf {
    resolve(ASTRA_RUNS)
}

pub fn astra_traces_dir() -> PathBuf {
    resolve(ASTRA_TRACES)
}

pub fn stage_dir() -> PathBuf {
    resolve(STAGE)
}

fn store() -> Arc<CsvRepository> {
    Arc::new(CsvRepository::new(
        fs::repo_root().unwrap_or_else(|| PathBuf::from(".")),
    ))
}

#[cfg(feature = "gpu")]
pub fn gpu_benchmark() -> GpuApplication {
    GpuApplication::new(
        Box::new(GpuBenchServiceImpl::new(0, Box::new(NvbandwidthCli::new()))),
        store(),
    )
}

pub fn perftest_benchmark() -> PerftestApplication {
    PerftestApplication::new(Box::new(PerftestCli::new()), store())
}

pub fn estimation() -> EstimationApplication {
    let estimator = TransportEstimatorServiceImpl::new(store());
    EstimationApplication::new(Box::new(estimator), store())
}

pub fn validation() -> ValidationApplication {
    let estimator = TransportEstimatorServiceImpl::new(store());
    ValidationApplication::new(Box::new(ValidationServiceImpl::new(
        store(),
        Box::new(estimator),
    )))
}

pub fn bench_evaluation() -> EvaluationApplication {
    let estimator = Box::new(TransportEstimatorServiceImpl::new(store()));
    let validation_estimator = Box::new(TransportEstimatorServiceImpl::new(store()));
    let validation = Box::new(ValidationServiceImpl::new(store(), validation_estimator));
    EvaluationApplication::new(Box::new(EvaluationServiceImpl::new(
        store(),
        estimator,
        validation,
    )))
}

pub fn astrasim_results() -> AstraResultsApplication {
    AstraResultsApplication::new(store())
}

pub fn thesis_export(output: PathBuf) -> ThesisApplication {
    ThesisApplication::new(
        Box::new(ThesisEvaluationService::new(
            Box::new(BenchResultsRepository::new(Box::new(bench_evaluation()))),
            Box::new(AstraSimResultsRepository::new(Box::new(astrasim_results()))),
        )),
        Box::new(TypstRepository::new(output)),
    )
}

pub fn astrasim() -> AstraSimApplication {
    AstraSimApplication::new(
        AstraSimService::new(
            Box::new(AstraSimRunnerImpl {
                run_dir: astra_runs_dir(),
                trace_dir: astra_traces_dir(),
                trace_gen: Box::new(PyTraceGenerator::new()),
            }),
            Box::new(StageTraceRepository::new(stage_dir(), astra_traces_dir())),
            Box::new(ResultParserImpl),
        ),
        store(),
    )
}
