use crate::domain::bench::model::{gpucopy, perftest};
use crate::domain::shared_kernel::model::{Bandwidth, Latency};

#[derive(Clone, Copy, Debug)]
pub struct BwPoint {
    pub peak: Bandwidth,
    pub avg: Bandwidth,
    pub msg_rate_mpps: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct LatPoint {
    pub min: Latency,
    pub max: Latency,
    pub typical: Latency,
    pub avg: Latency,
    pub stdev: Latency,
    pub p99: Latency,
    pub p999: Latency,
}

pub trait Sample {
    fn size_bytes(&self) -> u64;
}

impl From<&gpucopy::BwMeasurement> for BwPoint {
    fn from(m: &gpucopy::BwMeasurement) -> Self {
        Self {
            peak: m.bw_peak,
            avg: m.bw_avg,
            msg_rate_mpps: m.msg_rate_mpps,
        }
    }
}

impl From<&perftest::BwMeasurement> for BwPoint {
    fn from(m: &perftest::BwMeasurement) -> Self {
        Self {
            peak: m.bw_peak,
            avg: m.bw_avg,
            msg_rate_mpps: m.msg_rate_mpps,
        }
    }
}

impl From<&gpucopy::LatMeasurement> for LatPoint {
    fn from(m: &gpucopy::LatMeasurement) -> Self {
        Self {
            min: m.lat_min,
            max: m.lat_max,
            typical: m.lat_typical,
            avg: m.lat_avg,
            stdev: m.lat_stdev,
            p99: m.lat_p99,
            p999: m.lat_p999,
        }
    }
}

impl From<&perftest::LatMeasurement> for LatPoint {
    fn from(m: &perftest::LatMeasurement) -> Self {
        Self {
            min: m.lat_min,
            max: m.lat_max,
            typical: m.lat_typical,
            avg: m.lat_avg,
            stdev: m.lat_stdev,
            p99: m.lat_p99,
            p999: m.lat_p999,
        }
    }
}

impl Sample for gpucopy::BwMeasurement {
    fn size_bytes(&self) -> u64 {
        self.size_bytes
    }
}

impl Sample for gpucopy::LatMeasurement {
    fn size_bytes(&self) -> u64 {
        self.size_bytes
    }
}

impl Sample for perftest::BwMeasurement {
    fn size_bytes(&self) -> u64 {
        self.size_bytes
    }
}

impl Sample for perftest::LatMeasurement {
    fn size_bytes(&self) -> u64 {
        self.size_bytes
    }
}
