use color_eyre::eyre::{bail, eyre, Result, WrapErr};
use serde::Deserialize;

use crate::domain::shared_kernel::model::Bandwidth;

#[derive(Deserialize)]
struct Root {
    nvbandwidth: Body,
}

#[derive(Deserialize)]
struct Body {
    testcases: Vec<Testcase>,
}

#[derive(Deserialize)]
struct Testcase {
    name: String,
    #[serde(default)]
    sum: Option<f64>,
    #[serde(default)]
    error: Option<String>,
}

pub fn parse_bw(text: &str, test_name: &str) -> Result<Bandwidth> {
    let root: Root = serde_json::from_str(text).wrap_err("parse nvbandwidth json output")?;
    let tc = root
        .nvbandwidth
        .testcases
        .iter()
        .find(|t| t.name == test_name)
        .ok_or_else(|| eyre!("no testcase '{test_name}' in nvbandwidth output"))?;
    if let Some(err) = &tc.error {
        bail!("nvbandwidth '{test_name}' failed: {err}");
    }
    let sum = tc
        .sum
        .ok_or_else(|| eyre!("nvbandwidth '{test_name}' produced no bandwidth"))?;
    Ok(Bandwidth::from_gbps(sum))
}
