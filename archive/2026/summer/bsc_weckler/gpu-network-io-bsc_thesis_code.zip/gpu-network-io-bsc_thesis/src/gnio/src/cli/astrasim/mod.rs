mod args;
mod render;

use std::collections::BTreeSet;

pub use args::AstraSimArgs;

use color_eyre::eyre::Result;
use itertools::iproduct;

use crate::cli::di;
use crate::domain::astrasim::model::{
    AstraSimPlan, CollectiveImpl, Design, Fabric, Link, RunSpec, Workload, WorkloadCase,
};
use crate::domain::astrasim::presentation::{ComparisonSink, ContinuationStatus};
use crate::domain::bench::model::EstimationMode;
use crate::libs::cli::color;
use crate::libs::nofile;
use render::{ConsoleSink, E2eConsoleSink};

pub fn run(args: AstraSimArgs) -> Result<()> {
    let app = di::astrasim();
    let e2e_workloads = args
        .e2e_workloads()
        .map(|selected| app.ensure_e2e_traces(&selected))
        .transpose()?;

    if args.generate_only {
        for workload in e2e_workloads
            .as_ref()
            .expect("--generate-only requires --e2e")
        {
            println!(
                "ensured {} trace(s) for {} under {}",
                workload.npu_count,
                workload.name,
                workload
                    .trace_prefix
                    .parent()
                    .expect("STAGE trace prefix has a parent")
                    .display()
            );
        }
        return Ok(());
    }

    let estimation = di::estimation();
    use EstimationMode as M;
    let links = vec![
        Link::new(
            Design::GpuDirect,
            estimation.estimate(M::RdmaVmGpuDirectMeasured)?.model.ab(),
        ),
        Link::new(
            Design::CpuBounce,
            estimation
                .estimate(M::RdmaCvmCpuBounceE2eSynthetic)?
                .model
                .ab(),
        ),
        Link::new(
            Design::D1E2e,
            estimation
                .estimate(M::RdmaCvmInGpuBounceE2eSynthetic)?
                .model
                .ab(),
        ),
        Link::new(
            Design::D2E2e,
            estimation
                .estimate(M::RdmaCvmIdeIpsecE2eSynthetic)?
                .model
                .ab(),
        ),
    ];

    println!("design links fed into ASTRA-sim (alpha / beta):");
    for link in &links {
        println!(
            "  {:<10} alpha {:>8.2} us   beta {:>7.2} GB/s",
            link.design,
            link.ab.alpha.as_micros(),
            link.ab.beta.as_gbps(),
        );
    }

    let algorithms = args.algorithms();
    let designs: Vec<Design> = links.iter().map(|l| l.design).collect();

    let (plan, sink): (AstraSimPlan, Box<dyn ComparisonSink>) =
        if let Some(workloads) = e2e_workloads {
            let cases = workloads
                .into_iter()
                .map(|workload| {
                    let fabric =
                        Fabric::sweep_1d(vec![workload.npu_count], Fabric::network_fully_connected)
                            .into_iter()
                            .next()
                            .expect("one-dimensional fabric produces one case");
                    WorkloadCase::new(fabric, Workload::E2e(workload))
                })
                .collect();
            (
                AstraSimPlan::new(links, algorithms, cases),
                Box::new(E2eConsoleSink::new(designs)),
            )
        } else {
            // The measured alpha is an endpoint-to-endpoint cost. A fully
            // connected analytical fabric gives every logical transfer one hop.
            let fabrics = Fabric::sweep_1d(args.npus.clone(), Fabric::network_fully_connected);
            let workloads: Vec<Workload> = iproduct!(args.collectives(), args.sizes())
                .map(|(collective, size)| Workload::micro(collective, size))
                .collect();
            let cases = iproduct!(fabrics, workloads)
                .map(|(fabric, workload)| WorkloadCase::new(fabric, workload))
                .collect();
            (
                AstraSimPlan::new(links, algorithms, cases),
                Box::new(ConsoleSink::new(designs)),
            )
        };

    nofile::raise();
    if args.continue_run {
        print_continuation_status(&plan, &app.continuation_status(&plan)?);
    }
    let outcome = app.run(&plan, args.jobs(), args.persist(), args.continue_run, sink)?;

    println!(
        "\n{} link(s) x {} workload case(s) x {} algorithm(s) -> {} run(s) prepared ({} skipped) under {}",
        plan.links.len(),
        plan.cases.len(),
        plan.algorithms.len(),
        outcome.prepared,
        outcome.skipped,
        di::astra_runs_dir().display(),
    );

    if outcome.persisted {
        println!(
            "wrote {} result(s) to {}",
            outcome.completed,
            di::results_dir(crate::domain::astrasim::model::RESULTS_DIR).display()
        );
    }

    if !outcome.failures.is_empty() {
        eprintln!("\n{} ASTRA-sim run(s) failed:", outcome.failures.len());
        for failure in &outcome.failures {
            eprintln!("  {}", failure.spec);
            for line in failure.error.lines() {
                eprintln!("    {line}");
            }
        }
        eprintln!(
            "  Failed runs were not added to the results CSV and will be retried by --continue."
        );
    }

    Ok(())
}

fn print_continuation_status(plan: &AstraSimPlan, status: &ContinuationStatus) {
    struct Group {
        algorithm: CollectiveImpl,
        workload: String,
        fabric: String,
        npus: u32,
        designs: Vec<(Design, bool)>,
    }

    let completed: BTreeSet<String> = status.completed.iter().map(RunSpec::slug).collect();
    let mut groups: Vec<Group> = Vec::new();
    for spec in plan.specs() {
        let workload = match &spec.workload {
            Workload::E2e(workload) => workload.display_name.clone(),
            Workload::Micro(workload) => {
                format!("{} ({} B)", workload.collective, workload.size_bytes)
            }
        };
        let fabric = spec.fabric.to_string();
        let index = groups.iter().position(|group| {
            group.algorithm == spec.algorithm
                && group.workload == workload
                && group.fabric == fabric
                && group.npus == spec.npus()
        });
        let done = completed.contains(&spec.slug());
        if let Some(index) = index {
            groups[index].designs.push((spec.link.design, done));
        } else {
            groups.push(Group {
                algorithm: spec.algorithm,
                workload,
                fabric,
                npus: spec.npus(),
                designs: vec![(spec.link.design, done)],
            });
        }
    }

    let c = color::enabled();
    println!("\n{}", color::bold("Continuation status", c));
    println!(
        "  {} completed · {} pending",
        color::green_bold(&status.completed.len().to_string(), c),
        color::magenta(&status.pending.len().to_string(), c)
    );
    println!(
        "  Legend: [{} GPUDirect, {} CPU bounce, {} Design 1 (end-to-end), {} Design 2 (end-to-end)]",
        color::indexed("A", 0, c),
        color::indexed("B", 1, c),
        color::indexed("C", 2, c),
        color::indexed("D", 3, c),
    );

    let workload_width = groups
        .iter()
        .map(|group| group.workload.chars().count())
        .max()
        .unwrap_or(8)
        .max("workload".len());
    let fabric_width = groups
        .iter()
        .map(|group| group.fabric.chars().count())
        .max()
        .unwrap_or(6)
        .max("fabric".len());
    let gpu_width = groups
        .iter()
        .map(|group| group.npus.to_string().chars().count())
        .max()
        .unwrap_or(4)
        .max("GPUs".len());

    let mut last_algorithm = None;
    for group in groups {
        if last_algorithm != Some(group.algorithm) {
            println!("\n  {}", color::bold(group.algorithm.label(), c));
            println!(
                "    {:<workload_width$}  {:<fabric_width$}  {:>gpu_width$}  status",
                "workload",
                "fabric",
                "GPUs",
                workload_width = workload_width,
                fabric_width = fabric_width,
                gpu_width = gpu_width,
            );
            last_algorithm = Some(group.algorithm);
        }
        let states = group
            .designs
            .iter()
            .map(|(_, done)| {
                if *done {
                    color::green_bold("✓", c)
                } else {
                    color::magenta("→", c)
                }
            })
            .collect::<Vec<_>>()
            .join(", ");
        println!(
            "    {:<workload_width$}  {:<fabric_width$}  {:>gpu_width$}  [{states}]",
            group.workload,
            group.fabric,
            group.npus,
            workload_width = workload_width,
            fabric_width = fabric_width,
            gpu_width = gpu_width,
            states = states,
        );
    }
}
