use crate::domain::bench::model::error::ErrorMetrics;
use crate::domain::bench::model::estimator::{CostModel, EstimationMode};
use crate::domain::bench::model::{perftest, CurvePair};
use crate::domain::shared_kernel::model::Verb;

#[derive(Clone, Copy, Debug)]
pub enum GroundTruth {
    Perftest {
        mode: perftest::Mode,
        bw_verb: Verb,
        lat_verb: Verb,
    },
}

impl GroundTruth {
    pub fn label(self) -> String {
        match self {
            GroundTruth::Perftest { mode, .. } => mode.to_string(),
        }
    }
}

impl EstimationMode {
    pub fn ground_truth(self) -> Option<GroundTruth> {
        Some(match self {
            EstimationMode::RdmaVmGpuDirectMeasured => GroundTruth::Perftest {
                mode: perftest::Mode::VmGpuDirectDmaBuf,
                bw_verb: Verb::Write,
                lat_verb: Verb::WriteImm,
            },
            EstimationMode::RdmaCvmCpuBounceSingleSynthetic => GroundTruth::Perftest {
                mode: perftest::Mode::CvmGpuBBBypass,
                bw_verb: Verb::Write,
                lat_verb: Verb::WriteImm,
            },
            EstimationMode::RdmaCvmCpuBounceE2eSynthetic
            | EstimationMode::RdmaCvmInGpuBounceE2eSynthetic
            | EstimationMode::RdmaCvmIdeIpsecE2eSynthetic => return None,
            EstimationMode::RdmaCvmInGpuBounceSingleSynthetic => GroundTruth::Perftest {
                mode: perftest::Mode::CvmGpuBBUvmgpu,
                bw_verb: Verb::Write,
                lat_verb: Verb::WriteImm,
            },
        })
    }
}

pub struct ValidationReport {
    pub mode: EstimationMode,
    pub against: EstimationMode,
    pub model: Box<dyn CostModel>,
    pub bw: ErrorMetrics,
    pub lat: ErrorMetrics,
    pub measured: CurvePair,
}
