use color_eyre::eyre::Result;

use crate::domain::bench::model::perftest::{
    BwMeasurement, LatMeasurement, PerftestMeasurement, Profile, Role, RunConfig,
};
use crate::domain::bench::repository::PerftestRunner;

use super::command::{execute, CommandSpec};
use super::output::{parse_bw, parse_lat};

#[derive(Default)]
pub struct PerftestCli;

impl PerftestCli {
    pub fn new() -> Self {
        Self
    }
}

impl PerftestRunner for PerftestCli {
    fn run(&self, config: &RunConfig) -> Result<Vec<PerftestMeasurement>> {
        let spec = CommandSpec::from_config(config)?;
        let output = execute(&spec)?;
        if matches!(config.role, Role::Server) {
            return Ok(Vec::new());
        }
        let row = match config.profile {
            Profile::Bw { .. } => PerftestMeasurement::Bw(BwMeasurement::from_run(
                config,
                &parse_bw(&output, config.size_bytes)?,
            )),
            Profile::Lat => PerftestMeasurement::Lat(LatMeasurement::from_run(
                config,
                &parse_lat(&output, config.size_bytes)?,
            )),
        };
        Ok(vec![row])
    }
}
