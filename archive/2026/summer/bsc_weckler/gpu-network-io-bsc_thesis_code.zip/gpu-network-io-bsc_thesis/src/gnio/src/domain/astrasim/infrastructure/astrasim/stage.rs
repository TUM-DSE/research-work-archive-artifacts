use std::path::{Path, PathBuf};
use std::process::Command;

use color_eyre::eyre::{bail, Result, WrapErr};

use crate::domain::astrasim::model::{E2eWorkload, StageConfig, StageWorkload};
use crate::domain::astrasim::repository::E2eTraceRepository;
use crate::libs::fs;

const STAGE_ENTRYPOINT: &str = r#"
import os
import runpy
import sys

# Do not rely on Python implicitly adding the current directory to sys.path.
# Nix/production launchers may enable safe-path mode, while STAGE is a source
# tree rather than an installed package.
stage_root = os.environ["GNIO_STAGE_ROOT"]
sys.path.insert(0, stage_root)

import symbolic_tensor_graph.graph.graph as graph

# STAGE defaults to /dev/shm, which is unavailable on macOS. Keep all of its
# temporary graph copies inside the generated-trace cache instead.
graph.TMP_DIR_ROOT = os.environ["GNIO_STAGE_TMPDIR"]
sys.argv = ["main.py", *sys.argv[2:]]
runpy.run_path("main.py", run_name="__main__")
"#;

/// Materializes STAGE workloads under the ASTRA-sim trace cache.
///
/// The cache is intentionally the only state this repository needs: if every
/// expected rank trace and its communication-group sidecar exist, no generator
/// process is spawned.
pub struct StageTraceRepository {
    pub stage_dir: PathBuf,
    pub trace_dir: PathBuf,
    python: String,
}

impl StageTraceRepository {
    pub fn new(stage_dir: PathBuf, trace_dir: PathBuf) -> Self {
        Self {
            stage_dir,
            trace_dir,
            python: std::env::var("GNIO_PYTHON").unwrap_or_else(|_| "python3".to_string()),
        }
    }

    fn artifact_dir(&self, workload: StageWorkload) -> PathBuf {
        self.trace_dir.join("stage").join(workload.as_ref())
    }

    fn materialized_workload(&self, workload: StageWorkload) -> E2eWorkload {
        let dir = self.artifact_dir(workload);
        E2eWorkload {
            name: workload.as_ref().to_string(),
            display_name: workload.to_string(),
            trace_prefix: dir.join("workload"),
            comm_group_path: dir.join("workload.json"),
            npu_count: workload.npu_count(),
        }
    }

    fn complete(workload: &E2eWorkload) -> bool {
        workload.comm_group_path.is_file()
            && (0..workload.npu_count).all(|rank| {
                Path::new(&format!("{}.{}.et", workload.trace_prefix.display(), rank)).is_file()
            })
    }

    fn run_stage(&self, workload: StageWorkload, artifact: &E2eWorkload) -> Result<()> {
        let output_dir = artifact
            .trace_prefix
            .parent()
            .expect("trace prefix always has an artifact directory");
        fs::reset_dir(output_dir)?;
        let tmp_dir = self.trace_dir.join("stage").join(".tmp");
        std::fs::create_dir_all(&tmp_dir)
            .wrap_err_with(|| format!("create STAGE temporary directory {}", tmp_dir.display()))?;

        let config = workload.config();
        let output = Command::new(&self.python)
            .arg("-c")
            .arg(STAGE_ENTRYPOINT)
            // The shim removes this placeholder before STAGE parses argv.
            .arg("main.py")
            .current_dir(&self.stage_dir)
            .env("GNIO_STAGE_ROOT", &self.stage_dir)
            .env("GNIO_STAGE_TMPDIR", &tmp_dir)
            .args(stage_arguments(config))
            .arg("--output_dir")
            .arg(output_dir)
            .arg("--output_name")
            .arg("workload.%d.et")
            .output()
            .wrap_err_with(|| format!("spawn STAGE with `{}`", self.python))?;
        if !output.status.success() {
            bail!(
                "STAGE failed for {workload}: {}",
                String::from_utf8_lossy(&output.stderr).trim()
            );
        }
        Ok(())
    }
}

impl E2eTraceRepository for StageTraceRepository {
    fn ensure(&self, workload: StageWorkload) -> Result<E2eWorkload> {
        let artifact = self.materialized_workload(workload);
        if Self::complete(&artifact) {
            return Ok(artifact);
        }

        self.run_stage(workload, &artifact)?;
        if !Self::complete(&artifact) {
            bail!(
                "STAGE completed for {workload}, but expected traces or communication groups are missing under {}",
                artifact
                    .trace_prefix
                    .parent()
                    .expect("trace prefix always has an artifact directory")
                    .display()
            );
        }
        Ok(artifact)
    }
}

fn stage_arguments(config: StageConfig) -> Vec<String> {
    let bool_arg = |value: bool| value.to_string();
    [
        ("--model_type", config.model_type.to_string()),
        ("--dp", config.dp.to_string()),
        ("--tp", config.tp.to_string()),
        ("--sp", config.sp.to_string()),
        ("--ep", config.ep.to_string()),
        ("--pp", config.pp.to_string()),
        ("--weight_sharded", bool_arg(config.weight_sharded)),
        ("--tpsp", bool_arg(config.tpsp)),
        ("--dmodel", config.dmodel.to_string()),
        ("--dff", config.dff.to_string()),
        ("--head", config.head.to_string()),
        ("--kvhead", config.kvhead.to_string()),
        ("--batch", config.batch.to_string()),
        ("--micro_batch", config.micro_batch.to_string()),
        ("--seq", config.sequence_length.to_string()),
        ("--dvocal", config.vocabulary_size.to_string()),
        ("--num_stacks", config.num_stacks.to_string()),
        ("--experts", config.experts.to_string()),
        ("--kexperts", config.kexperts.to_string()),
        ("--mixed_precision", bool_arg(config.mixed_precision)),
        ("--activation_recompute", "false".to_string()),
        ("--chakra_schema_version", "v0.0.4".to_string()),
    ]
    .into_iter()
    .flat_map(|(key, value)| [key.to_string(), value])
    .collect()
}
