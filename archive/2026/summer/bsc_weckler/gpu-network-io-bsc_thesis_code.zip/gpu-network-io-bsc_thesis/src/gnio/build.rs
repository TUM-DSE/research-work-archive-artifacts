use std::path::PathBuf;
use std::process::Command;

fn main() {
    println!("cargo:rerun-if-changed=build.rs");

    if std::env::var_os("CARGO_FEATURE_GPU").is_none() {
        return;
    }

    link_cuda();
    build_uvmgpu_bench();
}

fn link_cuda() {
    println!("cargo:rerun-if-env-changed=CUDA_PATH");
    for dir in cuda_search_dirs() {
        if dir.is_dir() {
            println!("cargo:rustc-link-search=native={}", dir.display());
        }
    }
    println!("cargo:rustc-link-lib=cuda");
}

fn cuda_search_dirs() -> Vec<PathBuf> {
    let mut dirs = vec![PathBuf::from("/run/opengl-driver/lib")];
    let mut roots: Vec<PathBuf> = Vec::new();
    if let Some(root) = std::env::var_os("CUDA_PATH") {
        roots.push(PathBuf::from(root));
    }
    roots.push(PathBuf::from("/usr/local/cuda"));
    for root in roots {
        for sub in ["lib/stubs", "lib64/stubs", "lib", "lib64"] {
            dirs.push(root.join(sub));
        }
    }
    dirs
}

fn build_uvmgpu_bench() {
    let manifest = PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").unwrap());
    let dir = manifest.join("../uvmgpu");
    let output = PathBuf::from(std::env::var("OUT_DIR").unwrap()).join("uvmgpu_bench");

    for source in [
        "Makefile",
        "benchmark.cpp",
        "include/uvmgpu.hpp",
        "src/uvmgpu.cpp",
    ] {
        println!("cargo:rerun-if-changed={}", dir.join(source).display());
    }
    println!(
        "cargo:rerun-if-changed={}",
        manifest
            .join("../../tools/open-gpu-kernel-modules/kernel-open/nvidia-uvm/uvm_gnio_abi.h")
            .display()
    );

    let status = Command::new("make")
        .arg("-C")
        .arg(&dir)
        .arg("build")
        .status()
        .expect("failed to build uvmgpu_bench");
    if !status.success() {
        panic!("make failed to build uvmgpu_bench");
    }

    std::fs::copy(dir.join("uvmgpu_bench"), &output).expect("failed to copy uvmgpu_bench");
    println!("cargo:rustc-env=UVMGPU_BENCH={}", output.display());
}
