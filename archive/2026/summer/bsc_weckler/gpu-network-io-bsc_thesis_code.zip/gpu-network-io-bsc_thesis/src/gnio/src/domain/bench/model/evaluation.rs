use crate::domain::bench::model::{
    ErrorMetrics, RdmaCvmCpuBounceE2eSynthetic, RdmaCvmCpuBounceSingleSynthetic,
    RdmaCvmIdeIpsecE2eSynthetic, RdmaCvmInGpuBounceE2eSynthetic, RdmaCvmInGpuBounceSingleSynthetic,
    RdmaVmGpuDirectMeasured,
};
use crate::domain::shared_kernel::model::{Bandwidth, Latency};

pub struct DesignModels<M, N> {
    pub one_sided: M,
    pub end_to_end: N,
}

impl<M, N> DesignModels<M, N> {
    pub fn new(one_sided: M, end_to_end: N) -> Self {
        Self {
            one_sided,
            end_to_end,
        }
    }
}

// These two measured copy rates are not part of the reduced Design 1 model,
// but Section 7 compares them with its seal stage.
pub struct CopyBandwidths {
    pub confidential_cuda_dtoh: Bandwidth,
    pub plain_cuda_dtoh: Bandwidth,
}

pub struct CpuBounceBandwidths {
    pub sender: Bandwidth,
    pub system_memory_rdma: Bandwidth,
    pub receiver: Bandwidth,
}

pub struct CpuBounceLatencies {
    pub sender: Latency,
    pub system_memory_rdma: Latency,
    pub receiver: Latency,
}

pub struct Design1Measurements {
    pub d2d_latency: Latency,
    pub driver_command_latency: Latency,
    pub driver_copy_latency: Latency,
    pub sealed_bandwidth_lower_bound: Bandwidth,
}

pub struct FlowCompletionComparison {
    pub size_bytes: u64,
    pub design1: Latency,
    pub design2: Latency,
    pub cpu_bounce: Latency,
    pub gdr: Latency,
}

pub struct EvaluationData {
    pub gdr: RdmaVmGpuDirectMeasured,
    pub cpu_bounce: DesignModels<RdmaCvmCpuBounceSingleSynthetic, RdmaCvmCpuBounceE2eSynthetic>,
    pub design1: DesignModels<RdmaCvmInGpuBounceSingleSynthetic, RdmaCvmInGpuBounceE2eSynthetic>,
    pub design1_measurements: Design1Measurements,
    pub design2: RdmaCvmIdeIpsecE2eSynthetic,
    pub copy_bandwidths: CopyBandwidths,
    pub cpu_bounce_bandwidths: CpuBounceBandwidths,
    pub cpu_bounce_latencies: CpuBounceLatencies,
    pub gdr_validation: ErrorMetrics,
    pub cpu_bounce_validation: ErrorMetrics,
    pub cpu_bounce_bw_validation: ErrorMetrics,
    pub design1_validation: ErrorMetrics,
    pub flow_completion: FlowCompletionComparison,
}
