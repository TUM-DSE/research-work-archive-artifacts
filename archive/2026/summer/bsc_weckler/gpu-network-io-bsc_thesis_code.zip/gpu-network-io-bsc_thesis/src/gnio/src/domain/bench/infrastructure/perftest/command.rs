use std::io::Read;
use std::process::{Command, Stdio};

use color_eyre::eyre::{bail, Result, WrapErr};

use crate::domain::bench::model::perftest::{Mode, Profile, Role, RunConfig};
use crate::domain::shared_kernel::model::{Direction, Verb};

const DEVICE: &str = "mlx5_0";

#[derive(Clone, Debug)]
pub struct CommandSpec {
    pub program: Program,
    pub args: Args,
    pub env: Env,
}

impl CommandSpec {
    pub fn from_config(config: &RunConfig) -> Result<Self> {
        Ok(Self {
            program: Program::from_config(config),
            args: Args::from_config(config)?,
            env: Env::from_mode(config.transport.mode),
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Program {
    IbWriteBw,
    IbReadBw,
    IbWriteLat,
    IbReadLat,
}

impl Program {
    pub fn from_config(config: &RunConfig) -> Self {
        match (config.transport.verb, config.profile) {
            (Verb::Write | Verb::WriteImm, Profile::Bw { .. }) => Program::IbWriteBw,
            (Verb::Read, Profile::Bw { .. }) => Program::IbReadBw,
            (Verb::Write | Verb::WriteImm, Profile::Lat) => Program::IbWriteLat,
            (Verb::Read, Profile::Lat) => Program::IbReadLat,
        }
    }

    pub fn binary(self) -> &'static str {
        match self {
            Program::IbWriteBw => "ib_write_bw",
            Program::IbReadBw => "ib_read_bw",
            Program::IbWriteLat => "ib_write_lat",
            Program::IbReadLat => "ib_read_lat",
        }
    }
}

#[derive(Clone, Debug)]
pub struct Args(pub Vec<String>);

impl Args {
    pub fn from_config(config: &RunConfig) -> Result<Self> {
        let mut args: Vec<String> = vec![
            "-s".into(),
            config.size_bytes.to_string(),
            "-n".into(),
            config.iters.to_string(),
            "-d".into(),
            DEVICE.to_string(),
            "-F".into(),
        ];

        if matches!(config.transport.verb, Verb::WriteImm) {
            args.push("--write_with_imm".into());
        }

        if let Profile::Bw { qps, direction, .. } = config.profile {
            if qps.0 > 1 {
                args.push("-q".into());
                args.push(qps.0.to_string());
            }
            if matches!(direction, Direction::Bidir) {
                args.push("-b".into());
            }
        }

        if let Role::Client { server_ip } = &config.role {
            args.push(server_ip.to_string());
            args.extend(
                mode_extra_args(config.transport.mode)
                    .iter()
                    .map(|a| a.to_string()),
            );
        }

        if let Profile::Bw {
            data_validation: true,
            ..
        } = config.profile
        {
            args.push("--data_validation".into());
        }

        Ok(Self(args))
    }
}

#[derive(Clone, Debug)]
pub struct Env(pub Vec<(String, String)>);

impl Env {
    pub fn from_mode(mode: Mode) -> Self {
        let pairs = match mode {
            Mode::CvmRamBypass | Mode::CvmGpuBBBypass | Mode::CvmGpuBBUvmgpu => vec![
                ("MLX5_COH_CQ".to_string(), "1".to_string()),
                ("MLX5_COH_QP".to_string(), "1".to_string()),
            ],
            _ => Vec::new(),
        };
        Self(pairs)
    }
}

pub fn execute(spec: &CommandSpec) -> Result<String> {
    let mut cmd = Command::new(spec.program.binary());
    cmd.args(&spec.args.0);
    for (key, value) in &spec.env.0 {
        cmd.env(key, value);
    }
    cmd.stdout(Stdio::piped()).stderr(Stdio::inherit());
    let mut child = cmd
        .spawn()
        .wrap_err_with(|| format!("spawn {}", spec.program.binary()))?;
    let mut text = String::new();
    if let Some(mut stdout) = child.stdout.take() {
        stdout.read_to_string(&mut text).wrap_err("read stdout")?;
    }
    let status = child.wait().wrap_err("wait for child")?;
    if !status.success() {
        bail!("{} exited with {}", spec.program.binary(), status);
    }
    Ok(text)
}

fn mode_extra_args(mode: Mode) -> &'static [&'static str] {
    match mode {
        Mode::VmRam => &[],
        Mode::VmGpuBB => &["--use_cuda=0", "--cuda_mem_type=5"],
        Mode::VmGpuDirect => &["--use_cuda=0"],
        Mode::VmGpuDirectDmaBuf => &["--use_cuda=0", "--use_cuda_dmabuf"],
        Mode::CvmRamBypass => &["--use_dmabuf"],
        Mode::CvmGpuBBBypass => &["--use_cuda=0", "--cuda_mem_type=6"],
        Mode::CvmGpuBBUvmgpu => &["--use_uvmgpu=0"],
    }
}
