use crate::domain::{bench::model::gpucopy::Mode, shared_kernel::model::MetricKind};

#[derive(Clone, Debug)]
pub struct RunConfig {
    pub mode: Mode,
    pub size_bytes: u64,
    pub kind: MetricKind,
    pub iters: u64,
}
