use crate::cli::common;
use crate::domain::bench::model::perftest::{
    NetworkSecurity, PerftestMeasurement, Profile, Role, RunConfig, Transport,
};
use crate::domain::bench::presentation::PerftestObserver;
use crate::libs::cli::{color, fmt, table};

pub struct ConsoleObserver {
    role: Role,
    color: bool,
    group: Option<(Transport, NetworkSecurity, Profile)>,
}

impl ConsoleObserver {
    pub fn new(role: Role) -> Self {
        Self {
            role,
            color: color::enabled(),
            group: None,
        }
    }
}

impl PerftestObserver for ConsoleObserver {
    fn on_start(&mut self, config: &RunConfig) {
        if matches!(self.role, Role::Server) {
            println!("  {}", color::dim(&config_label(config), self.color));
            return;
        }
        let key = (config.transport, config.security, config.profile);
        if self.group != Some(key) {
            self.group = Some(key);
            println!();
            print_group_header(config, self.color);
            println!();
            let cols = match config.profile {
                Profile::Bw { .. } => common::bw_cols(),
                Profile::Lat => common::perf_lat_cols(),
            };
            println!("{}", table::indent(&table::header(&cols, self.color), 2));
        }
    }

    fn on_measured(&mut self, row: &PerftestMeasurement) {
        let c = self.color;
        let line = match row {
            PerftestMeasurement::Bw(r) => {
                table::row(&common::bw_cols(), &common::perf_bw_values(r), c)
            }
            PerftestMeasurement::Lat(r) => {
                table::row(&common::perf_lat_cols(), &common::perf_lat_values(r), c)
            }
        };
        println!("{}", table::indent(&line, 2));
    }
}

fn print_group_header(config: &RunConfig, c: bool) {
    let verb = config.transport.verb.to_string();
    let mode = config.transport.mode.to_string();
    let security = config.security.to_string();
    match config.profile {
        Profile::Bw { qps, direction, .. } => println!(
            "  {}{}",
            color::bold(&format!("bw-{verb}"), c),
            color::dim(
                &format!(
                    "  {mode} · {security} · {direction} · q{} · n={}",
                    qps.0, config.iters
                ),
                c
            )
        ),
        Profile::Lat => println!(
            "  {}{}",
            color::bold(&format!("lat-{verb}"), c),
            color::dim(&format!("  {mode} · {security} · n={}", config.iters), c)
        ),
    }
}

fn config_label(config: &RunConfig) -> String {
    let verb = config.transport.verb.to_string();
    let mode = config.transport.mode.to_string();
    let security = config.security.to_string();
    let size = fmt::size(config.size_bytes);
    match config.profile {
        Profile::Bw { qps, direction, .. } => {
            format!(
                "bw-{verb} {mode} [{security}] {direction} q: {} {size} n: {}",
                qps.0, config.iters
            )
        }
        Profile::Lat => format!("lat-{verb} {mode} [{security}] {size} n: {}", config.iters),
    }
}
