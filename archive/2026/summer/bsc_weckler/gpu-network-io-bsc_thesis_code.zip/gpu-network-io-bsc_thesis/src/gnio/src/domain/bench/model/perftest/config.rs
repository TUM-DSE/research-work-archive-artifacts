use super::primitives::{NetworkSecurity, Profile, Role, Transport};

#[derive(Clone, Debug)]
pub struct RunConfig {
    pub transport: Transport,
    pub security: NetworkSecurity,
    pub profile: Profile,
    pub role: Role,
    pub size_bytes: u64,
    pub iters: u64,
}
