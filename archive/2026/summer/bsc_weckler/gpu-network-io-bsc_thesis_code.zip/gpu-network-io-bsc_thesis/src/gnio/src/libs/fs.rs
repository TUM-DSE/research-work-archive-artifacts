use std::fs;
use std::path::{Path, PathBuf};

use color_eyre::eyre::{ContextCompat, Result, WrapErr};

pub fn atomic_write(path: &Path, bytes: &[u8]) -> Result<()> {
    let dir = path
        .parent()
        .with_context(|| format!("path '{}' has no parent", path.display()))?;
    fs::create_dir_all(dir).wrap_err_with(|| format!("create dir '{}'", dir.display()))?;
    let name = path
        .file_name()
        .and_then(|n| n.to_str())
        .with_context(|| format!("path '{}' has no file name", path.display()))?;
    let tmp = dir.join(format!(".{name}.{}.tmp", std::process::id()));
    fs::write(&tmp, bytes).wrap_err_with(|| format!("write '{}'", tmp.display()))?;
    fs::rename(&tmp, path).wrap_err_with(|| format!("rename into '{}'", path.display()))?;
    Ok(())
}

// Remove `dir` and everything under it if present, then recreate it empty.
pub fn reset_dir(dir: &Path) -> Result<()> {
    if dir.exists() {
        fs::remove_dir_all(dir).wrap_err_with(|| format!("remove dir '{}'", dir.display()))?;
    }
    fs::create_dir_all(dir).wrap_err_with(|| format!("create dir '{}'", dir.display()))?;
    Ok(())
}

pub fn repo_root() -> Option<PathBuf> {
    let mut dir = std::env::current_dir().ok()?;
    loop {
        if dir.join("flake.nix").is_file() {
            return Some(dir);
        }
        if !dir.pop() {
            return None;
        }
    }
}
