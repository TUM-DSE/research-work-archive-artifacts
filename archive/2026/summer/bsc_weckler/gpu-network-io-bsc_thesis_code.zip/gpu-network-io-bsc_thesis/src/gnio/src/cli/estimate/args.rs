use clap::Args;

use crate::cli::common;
use crate::domain::bench::model::EstimationMode;

#[derive(Args, Debug)]
pub struct EstimateArgs {
    #[arg(value_parser = common::possible_value_parser(&EstimationMode::ALL))]
    pub mode: Option<EstimationMode>,

    #[arg(short = 'l', long = "log")]
    pub log: bool,
}

impl EstimateArgs {
    pub fn modes(&self) -> Vec<EstimationMode> {
        match self.mode {
            Some(m) => vec![m],
            None => EstimationMode::ALL.to_vec(),
        }
    }
}
