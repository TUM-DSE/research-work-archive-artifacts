pub fn size(bytes: u64) -> String {
    if bytes >= 1 << 20 {
        format!("{}MiB", bytes >> 20)
    } else if bytes >= 1 << 10 {
        format!("{}KiB", bytes >> 10)
    } else {
        format!("{bytes}B")
    }
}

pub fn gbps(gbps: f64) -> String {
    format!("{gbps:.2} GB/s")
}

pub fn latency_us(us: f64) -> String {
    if us >= 1e6 {
        format!("{:.2} s", us / 1e6)
    } else if us >= 1e3 {
        format!("{:.2} ms", us / 1e3)
    } else {
        format!("{us:.2} µs")
    }
}
