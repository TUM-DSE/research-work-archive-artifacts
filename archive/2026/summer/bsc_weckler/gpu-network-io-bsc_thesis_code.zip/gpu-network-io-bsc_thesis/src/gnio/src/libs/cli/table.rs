use tabled::builder::Builder;
use tabled::settings::object::Columns;
use tabled::settings::{Alignment, Modify, Style};

use crate::libs::cli::color;

pub struct Col {
    pub header: &'static str,
    pub width: usize,
    pub right: bool,
    pub paint: fn(&str, bool) -> String,
}

pub fn header(cols: &[Col], c: bool) -> String {
    let head = cols
        .iter()
        .map(|col| wrap(&color::dim(&pad(col.header, col.width, col.right), c)))
        .collect::<Vec<_>>()
        .join("|");
    let rule = cols
        .iter()
        .map(|col| "-".repeat(col.width + 2))
        .collect::<Vec<_>>()
        .join("+");
    format!("{head}\n{}", color::dim(&rule, c))
}

pub fn row(cols: &[Col], values: &[String], c: bool) -> String {
    cols.iter()
        .zip(values)
        .map(|(col, v)| wrap(&(col.paint)(&pad(v, col.width, col.right), c)))
        .collect::<Vec<_>>()
        .join("|")
}

// Same as `Col`/`header`/`row` but with an owned header, for tables whose columns are only known
// at runtime (e.g. one column group per design in the comparison table).
pub struct DynCol {
    pub header: String,
    pub width: usize,
    pub right: bool,
    pub paint: fn(&str, bool) -> String,
}

pub fn dyn_header(cols: &[DynCol], c: bool) -> String {
    let head = cols
        .iter()
        .map(|col| wrap(&color::dim(&pad(&col.header, col.width, col.right), c)))
        .collect::<Vec<_>>()
        .join("|");
    let rule = cols
        .iter()
        .map(|col| "-".repeat(col.width + 2))
        .collect::<Vec<_>>()
        .join("+");
    format!("{head}\n{}", color::dim(&rule, c))
}

pub fn dyn_row(cols: &[DynCol], values: &[String], c: bool) -> String {
    cols.iter()
        .zip(values)
        .map(|(col, v)| wrap(&(col.paint)(&pad(v, col.width, col.right), c)))
        .collect::<Vec<_>>()
        .join("|")
}

fn pad(s: &str, width: usize, right: bool) -> String {
    let fill = " ".repeat(width.saturating_sub(s.chars().count()));
    if right {
        format!("{fill}{s}")
    } else {
        format!("{s}{fill}")
    }
}

fn wrap(s: &str) -> String {
    format!(" {s} ")
}

pub fn psql(header: &[&str], rows: Vec<Vec<String>>, right_from: usize) -> String {
    let mut b = Builder::default();
    b.push_record(header.iter().map(|s| s.to_string()).collect::<Vec<_>>());
    for row in rows {
        b.push_record(row);
    }
    let mut table = b.build();
    table
        .with(Style::psql())
        .with(Modify::new(Columns::new(right_from..)).with(Alignment::right()));
    table.to_string()
}

pub fn indent(s: &str, n: usize) -> String {
    let pad = " ".repeat(n);
    s.lines()
        .map(|l| format!("{pad}{l}"))
        .collect::<Vec<_>>()
        .join("\n")
}

pub fn beside(left: &str, right: &str, gap: usize) -> String {
    let left_lines: Vec<&str> = left.lines().collect();
    let right_lines: Vec<&str> = right.lines().collect();
    let width = left_lines
        .iter()
        .map(|l| visible_width(l))
        .max()
        .unwrap_or(0);

    let mut out = String::new();
    for i in 0..left_lines.len().max(right_lines.len()) {
        let l = left_lines.get(i).copied().unwrap_or("");
        let r = right_lines.get(i).copied().unwrap_or("");
        let pad = width.saturating_sub(visible_width(l)) + gap;
        out.push_str(l);
        out.push_str(&" ".repeat(pad));
        out.push_str(r);
        out.push('\n');
    }
    out
}

pub fn visible_width(s: &str) -> usize {
    let mut width = 0;
    let mut chars = s.chars();
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            for c in chars.by_ref() {
                if c == 'm' {
                    break;
                }
            }
        } else {
            width += 1;
        }
    }
    width
}
