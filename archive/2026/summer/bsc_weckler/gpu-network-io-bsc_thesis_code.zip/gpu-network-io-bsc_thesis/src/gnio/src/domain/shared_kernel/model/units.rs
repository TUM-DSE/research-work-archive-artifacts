use std::ops::{Add, Div, Mul, Sub};
use std::time::Duration;

use ordered_float::NotNan;

use crate::libs::schema::{Better, ColumnSchema, ColumnType, Role};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Latency(NotNan<f64>); // microseconds

impl Latency {
    fn new(us: f64) -> Self {
        Self(NotNan::new(us).expect("latency must not be NaN"))
    }
    pub fn from_secs(s: f64) -> Self {
        Self::new(s * 1e6)
    }
    pub fn from_millis(ms: f64) -> Self {
        Self::new(ms * 1e3)
    }
    pub fn from_micros(us: f64) -> Self {
        Self::new(us)
    }
    pub fn from_nanos(ns: f64) -> Self {
        Self::new(ns * 1e-3)
    }
    pub fn as_secs(self) -> f64 {
        self.0.into_inner() * 1e-6
    }
    pub fn as_millis(self) -> f64 {
        self.0.into_inner() * 1e-3
    }
    pub fn as_micros(self) -> f64 {
        self.0.into_inner()
    }
    pub fn as_nanos(self) -> f64 {
        self.0.into_inner() * 1e3
    }
    pub fn as_duration(self) -> Duration {
        Duration::from_secs_f64(self.as_secs().max(0.0))
    }
}

impl From<Duration> for Latency {
    fn from(d: Duration) -> Self {
        Self::from_secs(d.as_secs_f64())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Bandwidth(NotNan<f64>); // bytes per second

impl Bandwidth {
    fn new(bps: f64) -> Self {
        Self(NotNan::new(bps).expect("bandwidth must not be NaN"))
    }
    pub fn from_bps(bps: f64) -> Self {
        Self::new(bps)
    }
    pub fn from_mibps(mibps: f64) -> Self {
        Self::new(mibps * (1u64 << 20) as f64)
    }
    pub fn from_gibps(gibps: f64) -> Self {
        Self::new(gibps * (1u64 << 30) as f64)
    }
    pub fn from_gbps(gbps: f64) -> Self {
        Self::new(gbps * 1e9)
    }
    pub fn as_bytes_per_sec(self) -> f64 {
        self.0.into_inner()
    }
    pub fn as_mibps(self) -> f64 {
        self.0.into_inner() / (1u64 << 20) as f64
    }
    pub fn as_gibps(self) -> f64 {
        self.0.into_inner() / (1u64 << 30) as f64
    }
    pub fn as_gbps(self) -> f64 {
        self.0.into_inner() / 1e9
    }
}

macro_rules! impl_ops {
    ($t:ty) => {
        impl Add for $t {
            type Output = Self;
            fn add(self, rhs: Self) -> Self {
                Self::new(self.0.into_inner() + rhs.0.into_inner())
            }
        }
        impl Sub for $t {
            type Output = Self;
            fn sub(self, rhs: Self) -> Self {
                Self::new(self.0.into_inner() - rhs.0.into_inner())
            }
        }
        impl Mul for $t {
            type Output = Self;
            fn mul(self, rhs: Self) -> Self {
                Self::new(self.0.into_inner() * rhs.0.into_inner())
            }
        }
        impl Div for $t {
            type Output = Self;
            fn div(self, rhs: Self) -> Self {
                Self::new(self.0.into_inner() / rhs.0.into_inner())
            }
        }
        impl Mul<f64> for $t {
            type Output = Self;
            fn mul(self, rhs: f64) -> Self {
                Self::new(self.0.into_inner() * rhs)
            }
        }
        impl Div<f64> for $t {
            type Output = Self;
            fn div(self, rhs: f64) -> Self {
                Self::new(self.0.into_inner() / rhs)
            }
        }
    };
}

macro_rules! impl_int_mul {
    ($t:ty, $($int:ty),+ $(,)?) => {
        $(
            impl Mul<$int> for $t {
                type Output = Self;
                fn mul(self, rhs: $int) -> Self {
                    Self::new(self.0.into_inner() * rhs as f64)
                }
            }
        )+
    };
}

impl_ops!(Latency);
impl_ops!(Bandwidth);
impl_int_mul!(Latency, u8, u16, u32, u64, usize, i32, i64);
impl_int_mul!(Bandwidth, u8, u16, u32, u64, usize, i32, i64);

// Units match the CSV representation (serde_latency_us / serde_bandwidth_mibps).
impl ColumnSchema for Latency {
    fn column_type() -> ColumnType {
        ColumnType::Float
    }
    fn unit() -> Option<&'static str> {
        Some("µs")
    }
    fn default_role() -> Role {
        Role::Measure
    }
    fn better() -> Option<Better> {
        Some(Better::Lower)
    }
}

impl ColumnSchema for Bandwidth {
    fn column_type() -> ColumnType {
        ColumnType::Float
    }
    fn unit() -> Option<&'static str> {
        Some("MiB/s")
    }
    fn default_role() -> Role {
        Role::Measure
    }
    fn better() -> Option<Better> {
        Some(Better::Higher)
    }
}

pub mod serde_bandwidth_mibps {
    use super::Bandwidth;
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S: Serializer>(b: &Bandwidth, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_f64(b.as_mibps())
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<Bandwidth, D::Error> {
        Ok(Bandwidth::from_mibps(f64::deserialize(d)?))
    }
}

pub mod serde_latency_us {
    use super::Latency;
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S: Serializer>(l: &Latency, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_f64(l.as_micros())
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<Latency, D::Error> {
        Ok(Latency::from_micros(f64::deserialize(d)?))
    }
}
