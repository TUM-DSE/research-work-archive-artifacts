use crate::domain::shared_kernel::model::{Bandwidth, Latency};

#[derive(Clone, Copy)]
pub struct PathModel {
    pub latency: Latency,
    pub bandwidth: Bandwidth,
}

#[derive(Clone, Copy)]
pub struct Design1Measurements {
    pub d2d_latency: Latency,
    pub driver_command_latency: Latency,
    pub driver_copy_latency: Latency,
    pub sealed_bandwidth_lower_bound: Bandwidth,
}

#[derive(Clone, Copy)]
pub struct Design2Parameters {
    pub ide_operations: u8,
    pub ide_operation_latency: Latency,
    pub ide_latency: Latency,
    pub esp_latency: Latency,
    pub ide_bandwidth: Bandwidth,
    pub esp_bandwidth: Bandwidth,
}

#[derive(Clone, Copy)]
pub struct CopyBandwidths {
    pub confidential_cuda_dtoh: Bandwidth,
    pub plain_cuda_dtoh: Bandwidth,
}

#[derive(Clone, Copy)]
pub struct CpuBounceBandwidths {
    pub sender: Bandwidth,
    pub system_memory_rdma: Bandwidth,
    pub receiver: Bandwidth,
}

#[derive(Clone, Copy)]
pub struct CpuBounceLatencies {
    pub sender: Latency,
    pub system_memory_rdma: Latency,
    pub receiver: Latency,
}

#[derive(Clone, Copy)]
pub struct ErrorMetrics {
    pub mape: f64,
    pub geomean: f64,
    pub median: f64,
    pub max: f64,
    pub bias: f64,
}

#[derive(Clone, Copy)]
pub struct FlowCompletion {
    pub size_bytes: u64,
    pub design1: Latency,
    pub design2: Latency,
    pub cpu_bounce: Latency,
    pub gpudirect: Latency,
}

pub struct DatapathResults {
    pub gpudirect: PathModel,
    pub cpu_bounce_single: PathModel,
    pub cpu_bounce: PathModel,
    pub design1_single: PathModel,
    pub design1_e2e: PathModel,
    pub design2_e2e: PathModel,
    pub design1_measurements: Design1Measurements,
    pub design2_parameters: Design2Parameters,
    pub copy_bandwidths: CopyBandwidths,
    pub cpu_bounce_bandwidths: CpuBounceBandwidths,
    pub cpu_bounce_latencies: CpuBounceLatencies,
    pub gpudirect_validation: ErrorMetrics,
    pub cpu_bounce_validation: ErrorMetrics,
    pub cpu_bounce_bandwidth_validation: ErrorMetrics,
    pub design1_validation: ErrorMetrics,
    pub flow_completion: FlowCompletion,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Design {
    Gpudirect,
    CpuBounce,
    Design1Single,
    Design1E2e,
    Design2E2e,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Algorithm {
    Ring,
    HalvingDoubling,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Collective {
    AllReduce,
    AllGather,
    ReduceScatter,
    AllToAll,
}

#[derive(Clone, Debug)]
pub struct CollectiveSample {
    pub design: Design,
    pub fabric: String,
    pub algorithm: Algorithm,
    pub collective: Collective,
    pub gpus: u32,
    pub size_bytes: u64,
    pub completion: Latency,
}

pub struct CollectiveResults {
    pub samples: Vec<CollectiveSample>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum E2eWorkload {
    Gpt3_5bPp,
    Gpt3_5bFsdp,
    Gpt3_175bTpSp,
    Gpt3_175bHybrid,
    Mixtral8x7bEpPp,
}

#[derive(Clone, Debug)]
pub struct E2eSample {
    pub design: Design,
    pub fabric: String,
    pub algorithm: Algorithm,
    pub workload: E2eWorkload,
    pub gpus: u32,
    pub completion: Latency,
}

pub struct E2eResults {
    pub samples: Vec<E2eSample>,
}

#[derive(Clone, Copy)]
pub struct E2eComparison {
    pub design1_over_gpudirect: f64,
    pub design2_over_gpudirect: f64,
    pub cpu_bounce_over_design1: f64,
    pub cpu_bounce_over_design2: f64,
    pub design1_over_design2: f64,
    pub design1_completion: Latency,
}

#[derive(Clone, Copy)]
pub struct PairedE2eCompletion {
    pub ring: E2eComparison,
    pub halving_doubling: E2eComparison,
}

impl PairedE2eCompletion {
    pub fn design1_over_gpudirect_range(self) -> (f64, f64) {
        ordered_pair(
            self.ring.design1_over_gpudirect,
            self.halving_doubling.design1_over_gpudirect,
        )
    }

    pub fn cpu_bounce_over_design1_range(self) -> (f64, f64) {
        ordered_pair(
            self.ring.cpu_bounce_over_design1,
            self.halving_doubling.cpu_bounce_over_design1,
        )
    }

    pub fn design2_over_gpudirect_range(self) -> (f64, f64) {
        ordered_pair(
            self.ring.design2_over_gpudirect,
            self.halving_doubling.design2_over_gpudirect,
        )
    }

    pub fn cpu_bounce_over_design2_range(self) -> (f64, f64) {
        ordered_pair(
            self.ring.cpu_bounce_over_design2,
            self.halving_doubling.cpu_bounce_over_design2,
        )
    }

    pub fn design1_over_design2_range(self) -> (f64, f64) {
        ordered_pair(
            self.ring.design1_over_design2,
            self.halving_doubling.design1_over_design2,
        )
    }

    pub fn halving_doubling_speedup(self) -> f64 {
        self.ring.design1_completion.as_micros()
            / self.halving_doubling.design1_completion.as_micros()
    }
}

fn ordered_pair(a: f64, b: f64) -> (f64, f64) {
    if a <= b {
        (a, b)
    } else {
        (b, a)
    }
}

#[derive(Clone, Copy)]
pub struct RatioStatistics {
    pub min: f64,
    pub median: f64,
    pub max: f64,
}

pub struct E2eCompletion {
    pub selected_workloads: usize,
    pub selected_points: usize,
    pub design1_over_gpudirect: RatioStatistics,
    pub design2_over_gpudirect: RatioStatistics,
    pub cpu_bounce_over_design1: RatioStatistics,
    pub cpu_bounce_over_design2: RatioStatistics,
    pub design1_over_design2: RatioStatistics,
    pub pp: PairedE2eCompletion,
    pub fsdp: PairedE2eCompletion,
    pub tp_sp: PairedE2eCompletion,
    pub hybrid: PairedE2eCompletion,
    pub moe_ring: E2eComparison,
}

pub struct CollectiveCompletion {
    pub gpus: u32,
    pub small_size_bytes: u64,
    pub large_size_bytes: u64,
    pub small_d1_over_gdr_min: f64,
    pub small_d1_over_gdr_max: f64,
    pub small_d1_over_cpu_mean: f64,
    pub small_d2_over_gdr_min: f64,
    pub small_d2_over_gdr_max: f64,
    pub small_cpu_over_d2_min: f64,
    pub small_cpu_over_d2_max: f64,
    pub small_d1_over_d2_min: f64,
    pub small_d1_over_d2_max: f64,
    pub large_d1_over_gdr_mean: f64,
    pub large_cpu_over_d1_min: f64,
    pub large_cpu_over_d1_max: f64,
    pub large_d1_over_d2_min: f64,
    pub large_d1_over_d2_max: f64,
    pub cpu_crossover_min_bytes: u64,
    pub cpu_crossover_max_bytes: u64,
    pub scaling_start_gpus: u32,
    pub scaling_end_gpus: u32,
    pub scaling_ring_start_overhead: f64,
    pub scaling_ring_end_overhead: f64,
    pub scaling_ring_end_d2_overhead: f64,
    pub scaling_halving_doubling_max_overhead: f64,
    pub scaling_all_gather_max_overhead: f64,
}

pub struct Evaluation {
    pub datapath: DatapathResults,
    pub collective_completion: CollectiveCompletion,
    pub e2e_completion: E2eCompletion,
}
