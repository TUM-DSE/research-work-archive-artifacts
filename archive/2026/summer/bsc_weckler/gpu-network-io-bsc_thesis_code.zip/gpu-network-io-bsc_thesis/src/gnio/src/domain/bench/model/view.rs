use crate::domain::bench::model::curve::{BwCurve, ComponentCurve, CurvePair, LatCurve};
use crate::domain::bench::model::{gpucopy, perftest};
use crate::domain::shared_kernel::model::{Dataset, Verb};

pub struct CurveGroup<A, M, C> {
    pub axis: A,
    pub series: Vec<(M, C)>,
}

// Read model over the gpu-copy datasets: per-mode component curves.
pub struct GpuCopyView {
    pub bw: Dataset<gpucopy::BwMeasurement>,
    pub lat: Dataset<gpucopy::LatMeasurement>,
}

impl GpuCopyView {
    pub fn new(bw: Dataset<gpucopy::BwMeasurement>, lat: Dataset<gpucopy::LatMeasurement>) -> Self {
        Self { bw, lat }
    }

    pub fn component(&self, mode: gpucopy::Mode) -> ComponentCurve {
        ComponentCurve::from_measurements(
            self.bw.iter().filter(move |m| m.mode == mode),
            self.lat.iter().filter(move |m| m.mode == mode),
        )
    }

    pub fn measured(&self, mode: gpucopy::Mode) -> CurvePair {
        self.component(mode).measured()
    }

    pub fn by_direction(
        &self,
        directions: &[gpucopy::Direction],
    ) -> Vec<CurveGroup<gpucopy::Direction, gpucopy::Mode, ComponentCurve>> {
        directions
            .iter()
            .filter_map(|&direction| {
                let series: Vec<(gpucopy::Mode, ComponentCurve)> = gpucopy::Mode::ALL
                    .iter()
                    .copied()
                    .filter(|m| m.direction() == direction)
                    .map(|mode| (mode, self.component(mode)))
                    .filter(|(_, curve)| !curve.is_empty())
                    .collect();
                (!series.is_empty()).then_some(CurveGroup {
                    axis: direction,
                    series,
                })
            })
            .collect()
    }
}

// Read model over the perftest datasets: per-mode/verb curves.
pub struct PerftestView {
    pub bw: Dataset<perftest::BwMeasurement>,
    pub lat: Dataset<perftest::LatMeasurement>,
}

impl PerftestView {
    pub fn new(
        bw: Dataset<perftest::BwMeasurement>,
        lat: Dataset<perftest::LatMeasurement>,
    ) -> Self {
        Self { bw, lat }
    }

    // Bandwidth is only comparable at the uni-directional, single-QP baseline.
    pub fn bw_curve(
        &self,
        mode: perftest::Mode,
        security: perftest::NetworkSecurity,
        verb: Verb,
    ) -> BwCurve {
        BwCurve::from_measurements(self.bw.iter().filter(move |m| {
            m.mode == mode
                && m.security == security
                && m.verb == verb
                && m.direction == perftest::baseline::DIRECTION
                && m.qps == perftest::baseline::QPS
        }))
    }

    pub fn lat_curve(
        &self,
        mode: perftest::Mode,
        security: perftest::NetworkSecurity,
        verb: Verb,
    ) -> LatCurve {
        LatCurve::from_measurements(
            self.lat
                .iter()
                .filter(move |m| m.mode == mode && m.security == security && m.verb == verb),
        )
    }

    pub fn measured(
        &self,
        mode: perftest::Mode,
        security: perftest::NetworkSecurity,
        bw_verb: Verb,
        lat_verb: Verb,
    ) -> CurvePair {
        CurvePair {
            bw: self.bw_curve(mode, security, bw_verb),
            lat: self.lat_curve(mode, security, lat_verb),
        }
    }

    // Bandwidth curves grouped by verb
    pub fn bandwidth_by_verb(
        &self,
    ) -> Vec<CurveGroup<Verb, (perftest::Mode, perftest::NetworkSecurity), BwCurve>> {
        self.by_verb(|view, mode, security, verb| {
            let curve = view.bw_curve(mode, security, verb);
            (!curve.is_empty()).then_some(curve)
        })
    }

    // Latency curves grouped by verb
    pub fn latency_by_verb(
        &self,
    ) -> Vec<CurveGroup<Verb, (perftest::Mode, perftest::NetworkSecurity), LatCurve>> {
        self.by_verb(|view, mode, security, verb| {
            let curve = view.lat_curve(mode, security, verb);
            (!curve.is_empty()).then_some(curve)
        })
    }

    fn by_verb<C>(
        &self,
        curve: impl Fn(&Self, perftest::Mode, perftest::NetworkSecurity, Verb) -> Option<C>,
    ) -> Vec<CurveGroup<Verb, (perftest::Mode, perftest::NetworkSecurity), C>> {
        [Verb::Read, Verb::Write, Verb::WriteImm]
            .into_iter()
            .filter_map(|verb| {
                let mut series = Vec::new();
                for mode in perftest::Mode::ALL {
                    for security in perftest::NetworkSecurity::ALL {
                        if let Some(curve) = curve(self, mode, security, verb) {
                            series.push(((mode, security), curve));
                        }
                    }
                }
                (!series.is_empty()).then_some(CurveGroup { axis: verb, series })
            })
            .collect()
    }
}
