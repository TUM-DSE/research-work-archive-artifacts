use std::sync::Arc;

use color_eyre::eyre::Result;

use crate::domain::astrasim::model::{E2eRow, MicroRow};
use crate::domain::shared_kernel::infrastructure::CsvRepository;

pub struct AstraResultsApplication {
    store: Arc<CsvRepository>,
}

impl AstraResultsApplication {
    pub fn new(store: Arc<CsvRepository>) -> Self {
        Self { store }
    }

    pub fn microbenchmarks(&self) -> Result<Vec<MicroRow>> {
        Ok(self.store.load::<MicroRow>()?.into_iter().collect())
    }

    pub fn e2e_workloads(&self) -> Result<Vec<E2eRow>> {
        Ok(self.store.load::<E2eRow>()?.into_iter().collect())
    }
}
