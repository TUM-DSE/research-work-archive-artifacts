use color_eyre::eyre::Result;

use crate::domain::bench::model::EvaluationData;
use crate::domain::bench::service::EvaluationService;

pub struct EvaluationApplication {
    service: Box<dyn EvaluationService>,
}

impl EvaluationApplication {
    pub fn new(service: Box<dyn EvaluationService>) -> Self {
        Self { service }
    }

    pub fn evaluate(&self) -> Result<EvaluationData> {
        self.service.evaluate()
    }
}
