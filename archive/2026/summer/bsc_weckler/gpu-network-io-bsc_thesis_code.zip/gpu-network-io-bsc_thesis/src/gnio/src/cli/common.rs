use clap::builder::{PossibleValue, PossibleValuesParser, TypedValueParser};

#[cfg(feature = "gpu")]
use crate::domain::bench::model::gpucopy;
use crate::domain::bench::model::{perftest, CostModel, CurvePair, ValidationReport};
use crate::libs::cli::table::Col;
use crate::libs::cli::{color, fmt, table};

pub fn possible_value_parser<T>(all: &[T]) -> impl TypedValueParser<Value = T>
where
    T: std::str::FromStr + AsRef<str> + Clone + Send + Sync + 'static,
    <T as std::str::FromStr>::Err: Into<Box<dyn std::error::Error + Send + Sync + 'static>>,
{
    let values: Vec<PossibleValue> = all
        .iter()
        .map(|v| PossibleValue::new(v.as_ref().to_owned()))
        .collect();
    PossibleValuesParser::new(values).try_map(|s| s.parse::<T>())
}

const KIB: u64 = 1 << 10;
const MIB: u64 = 1 << 20;

pub const SIZES: &[u64] = &[
    2,
    256,
    512,
    KIB,
    2 * KIB,
    4 * KIB,
    8 * KIB,
    16 * KIB,
    32 * KIB,
    64 * KIB,
    128 * KIB,
    256 * KIB,
    512 * KIB,
    MIB,
    2 * MIB,
    4 * MIB,
    8 * MIB,
    16 * MIB,
    32 * MIB,
    64 * MIB,
    128 * MIB,
];

pub fn metrics_table(report: &ValidationReport, c: bool) -> String {
    let pct = |x: f64| color::graded(&format!("{:.1} %", x * 100.0), x, c);
    let signed = |x: f64| color::graded(&format!("{:+.1} %", x * 100.0), x, c);
    let rows = vec![
        vec![
            "geo-mean error".to_string(),
            pct(report.bw.geomean),
            pct(report.lat.geomean),
        ],
        vec![
            "mean error".to_string(),
            pct(report.bw.mape),
            pct(report.lat.mape),
        ],
        vec![
            "median error".to_string(),
            pct(report.bw.median),
            pct(report.lat.median),
        ],
        vec![
            "max error".to_string(),
            pct(report.bw.max),
            pct(report.lat.max),
        ],
        vec![
            "RMSE".to_string(),
            color::cyan(&fmt::gbps(report.bw.rmse / 1e9), c),
            color::cyan(&fmt::latency_us(report.lat.rmse), c),
        ],
        vec![
            "NRMSE".to_string(),
            pct(report.bw.nrmse),
            pct(report.lat.nrmse),
        ],
        vec![
            "bias".to_string(),
            signed(report.bw.bias),
            signed(report.lat.bias),
        ],
    ];
    table::psql(&["metric", "bw", "lat"], rows, 1)
}

pub fn comparison_table(model: &dyn CostModel, measured: &CurvePair) -> String {
    let rows: Vec<Vec<String>> = SIZES
        .iter()
        .map(|&n| {
            let nf = n as f64;
            vec![
                fmt::size(n),
                format!("{:.2}", model.bandwidth(nf).as_gbps()),
                lookup(measured.bw.points(), n)
                    .map(|b| format!("{:.2}", b.avg.as_gbps()))
                    .unwrap_or_else(|| "-".to_string()),
                fmt::latency_us(model.cost(nf).as_micros()),
                lookup(measured.lat.points(), n)
                    .map(|l| fmt::latency_us(l.avg.as_micros()))
                    .unwrap_or_else(|| "-".to_string()),
            ]
        })
        .collect();
    table::psql(
        &["size", "est GB/s", "meas GB/s", "est lat", "meas lat"],
        rows,
        1,
    )
}

pub(crate) fn lookup<T: Copy>(curve: &[(u64, T)], n: u64) -> Option<T> {
    curve.iter().find(|(s, _)| *s == n).map(|(_, v)| *v)
}

pub fn run_summary(planned: usize, persisted: bool) {
    let c = color::enabled();
    println!();
    if persisted {
        println!(
            "{} {} runs {}",
            color::green_bold("✓", c),
            planned,
            color::dim("· results written", c)
        );
    } else {
        println!("{} {} runs", color::green_bold("✓", c), planned);
    }
}

pub fn bw_cols() -> [Col; 4] {
    [
        Col {
            header: "size",
            width: 6,
            right: false,
            paint: color::plain,
        },
        Col {
            header: "peak MiB/s",
            width: 10,
            right: true,
            paint: color::cyan,
        },
        Col {
            header: "avg MiB/s",
            width: 9,
            right: true,
            paint: color::green_bold,
        },
        Col {
            header: "rate Mpps",
            width: 9,
            right: true,
            paint: color::dim,
        },
    ]
}

#[cfg(feature = "gpu")]
pub fn gpu_lat_cols() -> [Col; 5] {
    [
        Col {
            header: "size",
            width: 6,
            right: false,
            paint: color::plain,
        },
        Col {
            header: "comp",
            width: 7,
            right: false,
            paint: color::dim,
        },
        Col {
            header: "min µs",
            width: 8,
            right: true,
            paint: color::cyan,
        },
        Col {
            header: "avg µs",
            width: 8,
            right: true,
            paint: color::green_bold,
        },
        Col {
            header: "p99 µs",
            width: 8,
            right: true,
            paint: color::magenta,
        },
    ]
}

pub fn perf_lat_cols() -> [Col; 4] {
    [
        Col {
            header: "size",
            width: 6,
            right: false,
            paint: color::plain,
        },
        Col {
            header: "min µs",
            width: 8,
            right: true,
            paint: color::cyan,
        },
        Col {
            header: "avg µs",
            width: 8,
            right: true,
            paint: color::green_bold,
        },
        Col {
            header: "p99 µs",
            width: 8,
            right: true,
            paint: color::magenta,
        },
    ]
}

#[cfg(feature = "gpu")]
pub fn gpu_bw_values(m: &gpucopy::BwMeasurement) -> [String; 4] {
    [
        fmt::size(m.size_bytes),
        format!("{:.1}", m.bw_peak.as_mibps()),
        format!("{:.1}", m.bw_avg.as_mibps()),
        format!("{:.2}", m.msg_rate_mpps),
    ]
}

pub fn perf_bw_values(m: &perftest::BwMeasurement) -> [String; 4] {
    [
        fmt::size(m.size_bytes),
        format!("{:.1}", m.bw_peak.as_mibps()),
        format!("{:.1}", m.bw_avg.as_mibps()),
        format!("{:.2}", m.msg_rate_mpps),
    ]
}

#[cfg(feature = "gpu")]
pub fn gpu_lat_values(m: &gpucopy::LatMeasurement) -> [String; 5] {
    [
        fmt::size(m.size_bytes),
        m.component.to_string(),
        format!("{:.2}", m.lat_min.as_micros()),
        format!("{:.2}", m.lat_avg.as_micros()),
        format!("{:.2}", m.lat_p99.as_micros()),
    ]
}

pub fn perf_lat_values(m: &perftest::LatMeasurement) -> [String; 4] {
    [
        fmt::size(m.size_bytes),
        format!("{:.2}", m.lat_min.as_micros()),
        format!("{:.2}", m.lat_avg.as_micros()),
        format!("{:.2}", m.lat_p99.as_micros()),
    ]
}
