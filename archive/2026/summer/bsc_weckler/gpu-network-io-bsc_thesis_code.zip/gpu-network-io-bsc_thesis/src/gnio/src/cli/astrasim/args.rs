use clap::Args;

use crate::cli::common;
use crate::domain::astrasim::model::{Collective, CollectiveImpl, StageWorkload};

const DEFAULT_SIZES: &[u64] = &[
    1 << 10,
    1 << 12,
    1 << 14,
    1 << 16,
    1 << 18,
    1 << 20,
    4 << 20,
    16 << 20,
    64 << 20,
    256 << 20,
    512 << 20,
];

#[derive(Args, Debug)]
pub struct AstraSimArgs {
    #[arg(short, long, default_value = "8,16,64,256", value_delimiter = ',')]
    pub npus: Vec<u32>,

    /// Logical collective implementations evaluated on the fixed one-hop fabric
    #[arg(short, long, value_delimiter = ',', value_parser = common::possible_value_parser(&CollectiveImpl::ALL))]
    pub algorithm: Vec<CollectiveImpl>,

    #[arg(short = 'C', long, value_delimiter = ',', value_parser = common::possible_value_parser(&Collective::ALL))]
    pub collectives: Vec<Collective>,

    #[arg(short, long, value_delimiter = ',')]
    pub size: Vec<u64>,

    /// Generate and simulate the configured STAGE E2E workloads. With no
    /// values, runs all workloads; pass a comma-separated subset to narrow it.
    #[arg(long, num_args = 0.., value_delimiter = ',', value_parser = common::possible_value_parser(&StageWorkload::ALL))]
    pub e2e: Option<Vec<StageWorkload>>,

    /// Only ensure the selected STAGE E2E traces exist; do not run ASTRA-sim.
    #[arg(long, requires = "e2e")]
    pub generate_only: bool,

    /// Parallel ASTRA-sim runs (default: available cores)
    #[arg(short = 'j', long)]
    pub jobs: Option<usize>,

    /// Persist results to CSV (E2E rows are written after each completed run)
    #[arg(short, long)]
    pub log: bool,

    /// Continue a previous run, skipping specs already present in the result CSVs.
    #[arg(short = 'c', long = "continue")]
    pub continue_run: bool,
}

impl AstraSimArgs {
    pub fn persist(&self) -> bool {
        self.log || self.continue_run
    }

    pub fn jobs(&self) -> usize {
        self.jobs.unwrap_or_else(|| {
            std::thread::available_parallelism()
                .map(|parallelism| parallelism.get())
                .unwrap_or(1)
        })
    }

    pub fn algorithms(&self) -> Vec<CollectiveImpl> {
        if self.algorithm.is_empty() {
            if self.e2e.is_some() {
                CollectiveImpl::DEFAULT_E2E_SWEEP.to_vec()
            } else {
                CollectiveImpl::DEFAULT_MICRO_SWEEP.to_vec()
            }
        } else {
            self.algorithm.clone()
        }
    }

    pub fn e2e_workloads(&self) -> Option<Vec<StageWorkload>> {
        self.e2e.as_ref().map(|selected| {
            if selected.is_empty() {
                StageWorkload::ALL.to_vec()
            } else {
                selected.clone()
            }
        })
    }

    pub fn sizes(&self) -> Vec<u64> {
        if self.size.is_empty() {
            DEFAULT_SIZES.to_vec()
        } else {
            self.size.clone()
        }
    }

    pub fn collectives(&self) -> Vec<Collective> {
        if self.collectives.is_empty() {
            Collective::ALL.to_vec()
        } else {
            self.collectives.clone()
        }
    }
}
