use std::path::PathBuf;

use color_eyre::eyre::Result;

use crate::domain::astrasim::model::{E2eWorkload, RunSpec, StageWorkload};

pub trait AstraSimRunner: Send + Sync {
    fn prepare(&self) -> Result<()>;

    fn generate_traces(&self, specs: &[RunSpec]) -> Result<()>;

    fn run(&self, spec: &RunSpec) -> Result<RunOutcome>;
}

pub trait TraceGenerator: Send + Sync {
    fn generate(&self, spec: &RunSpec, prefix: &str) -> Result<()>;
}

/// Repository for materialized E2E trace artifacts. Implementations must be
/// idempotent: a complete workload is returned as-is, while a missing or
/// incomplete one is generated before it is returned.
pub trait E2eTraceRepository: Send + Sync {
    fn ensure(&self, workload: StageWorkload) -> Result<E2eWorkload>;
}

pub trait ResultParser: Send + Sync {
    fn parse(&self, outcome: &RunOutcome) -> Result<f64>;
}

#[derive(Clone, Debug)]
pub struct RunOutcome {
    pub dir: PathBuf,
    pub stdout: String,
}
