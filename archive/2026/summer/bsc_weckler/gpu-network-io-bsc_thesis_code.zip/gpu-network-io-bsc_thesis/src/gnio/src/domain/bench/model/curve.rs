use std::collections::BTreeMap;

use color_eyre::eyre::Result;

use crate::domain::bench::model::error::ErrorMetrics;
use crate::domain::bench::model::estimator::CostModel;
use crate::domain::bench::model::gpucopy::{self, LatComponent};
use crate::domain::bench::model::point::{BwPoint, LatPoint, Sample};
use crate::domain::shared_kernel::model::{Bandwidth, Latency};

pub const FIXED_LATENCY_SIZE_BYTES: u64 = 32;

#[derive(Clone, Debug, Default)]
pub struct BwCurve(Vec<(u64, BwPoint)>);

#[derive(Clone, Debug, Default)]
pub struct LatCurve(Vec<(u64, LatPoint)>);

impl BwCurve {
    pub fn from_measurements<'a, M>(rows: impl IntoIterator<Item = &'a M>) -> Self
    where
        M: Sample + 'a,
        BwPoint: From<&'a M>,
    {
        let mut points: Vec<(u64, BwPoint)> = rows
            .into_iter()
            .map(|m| (m.size_bytes(), BwPoint::from(m)))
            .collect();
        points.sort_by_key(|(size, _)| *size);
        Self(points)
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    pub fn peak(&self) -> Option<Bandwidth> {
        self.0
            .iter()
            .map(|(_, p)| p.avg)
            .max_by(|a, b| a.as_bytes_per_sec().total_cmp(&b.as_bytes_per_sec()))
    }

    pub fn avg(&self) -> Vec<(u64, Bandwidth)> {
        self.0.iter().map(|(s, p)| (*s, p.avg)).collect()
    }

    pub fn error_vs(&self, model: &dyn CostModel) -> Result<ErrorMetrics> {
        self.error_vs_range(model, 0, u64::MAX)
    }

    pub fn error_vs_range(
        &self,
        model: &dyn CostModel,
        min_size: u64,
        max_size: u64,
    ) -> Result<ErrorMetrics> {
        let pairs: Vec<(f64, f64)> = self
            .0
            .iter()
            .filter(|(size, _)| *size >= min_size && *size <= max_size)
            .map(|(size, point)| {
                (
                    model.bandwidth(*size as f64).as_bytes_per_sec(),
                    point.avg.as_bytes_per_sec(),
                )
            })
            .collect();
        ErrorMetrics::from_pairs(&pairs)
    }

    pub fn iter(&self) -> std::slice::Iter<'_, (u64, BwPoint)> {
        self.0.iter()
    }

    pub fn points(&self) -> &[(u64, BwPoint)] {
        &self.0
    }
}

impl LatCurve {
    pub fn from_measurements<'a, M>(rows: impl IntoIterator<Item = &'a M>) -> Self
    where
        M: Sample + 'a,
        LatPoint: From<&'a M>,
    {
        let mut points: Vec<(u64, LatPoint)> = rows
            .into_iter()
            .map(|m| (m.size_bytes(), LatPoint::from(m)))
            .collect();
        points.sort_by_key(|(size, _)| *size);
        Self(points)
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    pub fn median_at(&self, size_bytes: u64) -> Option<Latency> {
        self.0
            .iter()
            .find(|(size, _)| *size == size_bytes)
            .map(|(_, point)| point.typical)
    }

    pub fn median_at_or_below(&self, size_bytes: u64) -> Option<Latency> {
        self.0
            .iter()
            .rev()
            .find(|(size, _)| *size <= size_bytes)
            .map(|(_, point)| point.typical)
    }

    pub fn avg(&self) -> Vec<(u64, Latency)> {
        self.0.iter().map(|(s, p)| (*s, p.avg)).collect()
    }

    pub fn avg_at(&self, size_bytes: u64) -> Option<Latency> {
        self.0
            .iter()
            .find(|(size, _)| *size == size_bytes)
            .map(|(_, point)| point.avg)
    }

    pub fn error_vs(&self, model: &dyn CostModel) -> Result<ErrorMetrics> {
        self.error_vs_range(model, 0, u64::MAX)
    }

    pub fn error_vs_range(
        &self,
        model: &dyn CostModel,
        min_size: u64,
        max_size: u64,
    ) -> Result<ErrorMetrics> {
        let pairs: Vec<(f64, f64)> = self
            .0
            .iter()
            .filter(|(size, _)| *size >= min_size && *size <= max_size)
            .map(|(size, point)| (model.cost(*size as f64).as_micros(), point.avg.as_micros()))
            .collect();
        ErrorMetrics::from_pairs(&pairs)
    }

    pub fn iter(&self) -> std::slice::Iter<'_, (u64, LatPoint)> {
        self.0.iter()
    }

    pub fn points(&self) -> &[(u64, LatPoint)] {
        &self.0
    }
}

#[derive(Clone, Debug, Default)]
pub struct CurvePair {
    pub bw: BwCurve,
    pub lat: LatCurve,
}

impl CurvePair {
    pub fn is_empty(&self) -> bool {
        self.bw.is_empty() && self.lat.is_empty()
    }
}

#[derive(Clone, Debug, Default)]
pub struct ComponentCurve {
    pub bw: BwCurve,
    pub lat: BTreeMap<LatComponent, LatCurve>,
}

impl ComponentCurve {
    pub fn from_measurements<'a>(
        bw: impl IntoIterator<Item = &'a gpucopy::BwMeasurement>,
        lat: impl IntoIterator<Item = &'a gpucopy::LatMeasurement>,
    ) -> Self {
        let bw = BwCurve::from_measurements(bw);
        let mut grouped: BTreeMap<LatComponent, Vec<&gpucopy::LatMeasurement>> = BTreeMap::new();
        for m in lat {
            grouped.entry(m.component).or_default().push(m);
        }
        let lat = grouped
            .into_iter()
            .map(|(component, rows)| (component, LatCurve::from_measurements(rows)))
            .collect();
        Self { bw, lat }
    }

    pub fn component(&self, component: LatComponent) -> Option<&LatCurve> {
        self.lat.get(&component)
    }

    pub fn total(&self) -> Option<&LatCurve> {
        self.component(LatComponent::Total)
    }

    pub fn is_empty(&self) -> bool {
        self.bw.is_empty() && self.lat.values().all(LatCurve::is_empty)
    }

    pub fn measured(&self) -> CurvePair {
        CurvePair {
            bw: self.bw.clone(),
            lat: self.total().cloned().unwrap_or_default(),
        }
    }
}
