#[cfg(feature = "gpu")]
pub mod gpu;
pub mod perf;

use clap::{Args, Subcommand};
use color_eyre::eyre::Result;

#[derive(Args, Debug)]
pub struct BenchArgs {
    #[command(subcommand)]
    pub target: BenchTarget,
}

#[derive(Subcommand, Debug)]
pub enum BenchTarget {
    Perf(perf::PerfArgs),
    #[cfg(feature = "gpu")]
    Gpu(gpu::GpuArgs),
}

pub fn run(args: BenchArgs) -> Result<()> {
    match args.target {
        BenchTarget::Perf(a) => perf::run(a),
        #[cfg(feature = "gpu")]
        BenchTarget::Gpu(a) => gpu::run(a),
    }
}
