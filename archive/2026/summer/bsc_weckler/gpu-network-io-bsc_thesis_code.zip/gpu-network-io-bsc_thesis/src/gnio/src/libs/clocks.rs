use std::process::{Command, Stdio};

pub fn lock() {
    let Some(max_sm) = query_clock("clocks.max.sm") else {
        return;
    };
    nvidia_smi(&["-pm", "1"]);
    nvidia_smi(&["-lgc", &max_sm.to_string()]);
    match query_clock("clocks.max.memory") {
        Some(max_mem) => {
            nvidia_smi(&["-lmc", &max_mem.to_string()]);
            eprintln!("clocks: GPU locked to max (sm={max_sm}MHz, mem={max_mem}MHz)");
        }
        None => eprintln!("clocks: GPU locked to max (sm={max_sm}MHz)"),
    }
}

fn query_clock(field: &str) -> Option<u32> {
    let output = Command::new("nvidia-smi")
        .arg(format!("--query-gpu={field}"))
        .arg("--format=csv,noheader,nounits")
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let line = String::from_utf8_lossy(&output.stdout);
    let digits: String = line
        .lines()
        .next()?
        .chars()
        .filter(char::is_ascii_digit)
        .collect();
    digits.parse().ok()
}

fn nvidia_smi(args: &[&str]) {
    let _ = Command::new("nvidia-smi")
        .args(args)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status();
}
