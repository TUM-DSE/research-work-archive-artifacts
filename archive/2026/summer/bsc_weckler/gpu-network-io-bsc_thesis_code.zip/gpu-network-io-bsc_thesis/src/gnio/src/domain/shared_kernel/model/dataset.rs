use std::collections::BTreeMap;

use serde::de::DeserializeOwned;
use serde::Serialize;

use crate::libs::schema::{DatasetMeta, Describe};

// A CSV row keyed for de-duplication.
pub trait Record: Serialize + DeserializeOwned + Clone + std::fmt::Debug + Send + Sync {
    type Key: Ord + Clone + std::fmt::Debug + Send + Sync;
    fn key(&self) -> Self::Key;
}

pub type RecordSet<R> = BTreeMap<<R as Record>::Key, R>;

#[derive(Clone, Copy, Debug)]
pub struct DatasetIdentity {
    pub group: &'static str,
    pub dir: &'static str,
    pub stem: &'static str,
    pub name: &'static str,
    pub title: &'static str,
}

impl DatasetIdentity {
    pub const fn new(
        group: &'static str,
        dir: &'static str,
        stem: &'static str,
        title: &'static str,
    ) -> Self {
        Self {
            group,
            dir,
            stem,
            name: stem,
            title,
        }
    }

    pub const fn named(mut self, name: &'static str) -> Self {
        self.name = name;
        self
    }

    pub fn id(&self) -> String {
        format!("{}/{}", self.group, self.name)
    }

    pub fn path(&self) -> String {
        format!("{}/{}.csv", self.dir, self.stem)
    }
}

// One dataset = one record type; identity, location and schema all come from the record.
pub trait DatasetRecord: Record + Describe {
    const IDENTITY: DatasetIdentity;

    fn baseline() -> Option<serde_json::Value> {
        None
    }

    fn dataset_meta() -> (String, DatasetMeta) {
        let identity = Self::IDENTITY;
        let meta = DatasetMeta::of::<Self>(identity.title, identity.path());
        let meta = match Self::baseline() {
            Some(filter) => meta.baseline(filter),
            None => meta,
        };
        (identity.id(), meta)
    }
}

#[derive(Clone, Debug)]
pub struct Dataset<R: DatasetRecord> {
    rows: RecordSet<R>,
}

impl<R: DatasetRecord> Dataset<R> {
    pub fn insert(&mut self, row: R) {
        self.rows.insert(row.key(), row);
    }

    pub fn merge(&mut self, other: Dataset<R>) {
        self.rows.extend(other.rows);
    }

    pub fn retain(&mut self, mut predicate: impl FnMut(&R) -> bool) {
        self.rows.retain(|_, row| predicate(row));
    }

    pub fn iter(&self) -> impl Iterator<Item = &R> {
        self.rows.values()
    }

    pub fn len(&self) -> usize {
        self.rows.len()
    }

    pub fn is_empty(&self) -> bool {
        self.rows.is_empty()
    }
}

impl<R: DatasetRecord> Default for Dataset<R> {
    fn default() -> Self {
        Self {
            rows: RecordSet::<R>::new(),
        }
    }
}

impl<R: DatasetRecord> Extend<R> for Dataset<R> {
    fn extend<I: IntoIterator<Item = R>>(&mut self, rows: I) {
        for row in rows {
            self.insert(row);
        }
    }
}

impl<R: DatasetRecord> FromIterator<R> for Dataset<R> {
    fn from_iter<I: IntoIterator<Item = R>>(rows: I) -> Self {
        let mut dataset = Self::default();
        dataset.extend(rows);
        dataset
    }
}

impl<R: DatasetRecord> IntoIterator for Dataset<R> {
    type Item = R;
    type IntoIter = std::collections::btree_map::IntoValues<R::Key, R>;

    fn into_iter(self) -> Self::IntoIter {
        self.rows.into_values()
    }
}
