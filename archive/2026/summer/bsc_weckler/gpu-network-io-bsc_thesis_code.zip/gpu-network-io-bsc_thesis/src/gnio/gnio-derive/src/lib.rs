use proc_macro::TokenStream;
use proc_macro2::TokenStream as Ts2;
use quote::quote;
use syn::punctuated::Punctuated;
use syn::{parse_macro_input, Data, DeriveInput, Expr, ExprLit, Field, Fields, Lit, Meta, Token};

#[proc_macro_derive(Describe, attributes(col))]
pub fn derive_describe(input: TokenStream) -> TokenStream {
    let input = parse_macro_input!(input as DeriveInput);
    expand(&input)
        .unwrap_or_else(|e| e.to_compile_error())
        .into()
}

fn expand(input: &DeriveInput) -> syn::Result<Ts2> {
    let ident = &input.ident;
    let Data::Struct(data) = &input.data else {
        return Err(syn::Error::new_spanned(
            ident,
            "Describe supports only structs",
        ));
    };
    let Fields::Named(fields) = &data.fields else {
        return Err(syn::Error::new_spanned(
            ident,
            "Describe supports only named fields",
        ));
    };

    let cols = fields
        .named
        .iter()
        .map(column_tokens)
        .collect::<syn::Result<Vec<_>>>()?;

    Ok(quote! {
        impl crate::libs::schema::Describe for #ident {
            fn columns() -> ::std::vec::Vec<crate::libs::schema::ColumnMeta> {
                ::std::vec![#(#cols),*]
            }
        }
    })
}

fn column_tokens(field: &Field) -> syn::Result<Ts2> {
    let ident = field.ident.as_ref().expect("named field");
    let ty = &field.ty;
    let name = serde_name(field)?.unwrap_or_else(|| ident.to_string());

    let mut label: Option<String> = None;
    let mut overrides: Vec<Ts2> = Vec::new();

    for attr in &field.attrs {
        if !attr.path().is_ident("col") {
            continue;
        }
        let Meta::List(list) = &attr.meta else {
            return Err(syn::Error::new_spanned(
                attr,
                "expected #[col(label = \"...\", ...)]",
            ));
        };
        let nested = list.parse_args_with(Punctuated::<Meta, Token![,]>::parse_terminated)?;
        for meta in nested {
            let Meta::NameValue(nv) = &meta else {
                return Err(syn::Error::new_spanned(meta, "expected `key = value`"));
            };
            let key = nv
                .path
                .get_ident()
                .map(ToString::to_string)
                .unwrap_or_default();
            match key.as_str() {
                "label" => label = Some(lit_str(&nv.value)?),
                "unit" => {
                    let unit = lit_str(&nv.value)?;
                    overrides.push(quote! {
                        c.unit = ::std::option::Option::Some(#unit.to_string());
                    });
                }
                "role" => {
                    let variant = keyword(
                        &nv.value,
                        &[
                            ("dimension", quote!(Dimension)),
                            ("measure", quote!(Measure)),
                            ("metadata", quote!(Metadata)),
                        ],
                    )?;
                    overrides.push(quote! { c.role = crate::libs::schema::Role::#variant; });
                }
                "better" => {
                    let variant = keyword(
                        &nv.value,
                        &[("higher", quote!(Higher)), ("lower", quote!(Lower))],
                    )?;
                    overrides.push(quote! {
                        c.better =
                            ::std::option::Option::Some(crate::libs::schema::Better::#variant);
                    });
                }
                "ty" => {
                    let variant = keyword(
                        &nv.value,
                        &[
                            ("string", quote!(String)),
                            ("integer", quote!(Integer)),
                            ("float", quote!(Float)),
                            ("datetime", quote!(DateTime)),
                            ("bool", quote!(Bool)),
                        ],
                    )?;
                    overrides.push(quote! { c.ty = crate::libs::schema::ColumnType::#variant; });
                }
                other => {
                    return Err(syn::Error::new_spanned(
                        &nv.path,
                        format!("unknown #[col] key `{other}` (label/unit/role/better/ty)"),
                    ));
                }
            }
        }
    }

    let Some(label) = label else {
        return Err(syn::Error::new_spanned(
            ident,
            format!("field `{ident}` is missing #[col(label = \"...\")]"),
        ));
    };

    Ok(if overrides.is_empty() {
        quote! { crate::libs::schema::ColumnMeta::of::<#ty>(#name, #label) }
    } else {
        quote! {{
            let mut c = crate::libs::schema::ColumnMeta::of::<#ty>(#name, #label);
            #(#overrides)*
            c
        }}
    })
}

fn serde_name(field: &Field) -> syn::Result<Option<String>> {
    for attr in &field.attrs {
        if !attr.path().is_ident("serde") {
            continue;
        }
        let Meta::List(list) = &attr.meta else {
            continue;
        };
        let nested = list.parse_args_with(Punctuated::<Meta, Token![,]>::parse_terminated)?;
        for meta in nested {
            if let Meta::NameValue(nv) = meta {
                if nv.path.is_ident("rename") {
                    return Ok(Some(lit_str(&nv.value)?));
                }
            }
        }
    }
    Ok(None)
}

fn lit_str(expr: &Expr) -> syn::Result<String> {
    if let Expr::Lit(ExprLit {
        lit: Lit::Str(s), ..
    }) = expr
    {
        return Ok(s.value());
    }
    Err(syn::Error::new_spanned(expr, "expected a string literal"))
}

fn keyword(expr: &Expr, allowed: &[(&str, Ts2)]) -> syn::Result<Ts2> {
    if let Expr::Path(p) = expr {
        if let Some(ident) = p.path.get_ident() {
            let name = ident.to_string();
            if let Some((_, tokens)) = allowed.iter().find(|(k, _)| *k == name) {
                return Ok(tokens.clone());
            }
        }
    }
    let options = allowed
        .iter()
        .map(|(k, _)| *k)
        .collect::<Vec<_>>()
        .join("|");
    Err(syn::Error::new_spanned(
        expr,
        format!("expected one of: {options}"),
    ))
}
