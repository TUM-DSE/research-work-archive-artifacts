use color_eyre::eyre::Result;

use crate::domain::thesis::repository::EvaluationRepository;
use crate::domain::thesis::service::EvaluationService;

pub struct ThesisApplication {
    service: Box<dyn EvaluationService>,
    repository: Box<dyn EvaluationRepository>,
}

impl ThesisApplication {
    pub fn new(
        service: Box<dyn EvaluationService>,
        repository: Box<dyn EvaluationRepository>,
    ) -> Self {
        Self {
            service,
            repository,
        }
    }

    pub fn export(&self) -> Result<()> {
        self.repository.save(&self.service.evaluate()?)
    }
}
