use color_eyre::eyre::{bail, ContextCompat, Result};

use crate::domain::thesis::model::{
    Algorithm, Collective, CollectiveCompletion, CollectiveResults, CollectiveSample, Design,
    E2eComparison, E2eCompletion, E2eResults, E2eSample, E2eWorkload, Evaluation,
    PairedE2eCompletion, RatioStatistics,
};
use crate::domain::thesis::repository::{AstraResultsRepository, DatapathResultsRepository};

const EVALUATION_GPUS: u32 = 64;

pub trait EvaluationService {
    fn evaluate(&self) -> Result<Evaluation>;
}

pub struct EvaluationServiceImpl {
    datapath: Box<dyn DatapathResultsRepository>,
    astra: Box<dyn AstraResultsRepository>,
}

impl EvaluationServiceImpl {
    pub fn new(
        datapath: Box<dyn DatapathResultsRepository>,
        astra: Box<dyn AstraResultsRepository>,
    ) -> Self {
        Self { datapath, astra }
    }
}

impl EvaluationService for EvaluationServiceImpl {
    fn evaluate(&self) -> Result<Evaluation> {
        let datapath = self.datapath.load()?;
        let collectives = self.astra.load_collectives()?;
        let e2e = self.astra.load_e2e()?;
        Ok(Evaluation {
            datapath,
            collective_completion: summarize_collectives(&collectives)?,
            e2e_completion: summarize_e2e(&e2e)?,
        })
    }
}

struct E2ePaths<'a> {
    sample: &'a E2eSample,
    gpudirect: f64,
    cpu_bounce: f64,
    design1: f64,
    design2: f64,
}

fn summarize_e2e(data: &E2eResults) -> Result<E2eCompletion> {
    let rows = e2e_paths(data)?;
    let pp = paired_e2e(&rows, E2eWorkload::Gpt3_5bPp)?;
    let fsdp = paired_e2e(&rows, E2eWorkload::Gpt3_5bFsdp)?;
    let tp_sp = paired_e2e(&rows, E2eWorkload::Gpt3_175bTpSp)?;
    let hybrid = paired_e2e(&rows, E2eWorkload::Gpt3_175bHybrid)?;
    // STAGE's Mixtral trace contains All-to-All, for which ASTRA-sim does not
    // support Halving-Doubling. Keep only the Ring point used by the paper.
    let moe_ring = e2e_comparison(&rows, E2eWorkload::Mixtral8x7bEpPp, Algorithm::Ring)?;

    let selected = [
        pp.ring,
        pp.halving_doubling,
        fsdp.ring,
        fsdp.halving_doubling,
        tp_sp.ring,
        tp_sp.halving_doubling,
        hybrid.ring,
        hybrid.halving_doubling,
        moe_ring,
    ];

    Ok(E2eCompletion {
        selected_workloads: 5,
        selected_points: selected.len(),
        design1_over_gpudirect: ratio_statistics(
            selected.iter().map(|point| point.design1_over_gpudirect),
        )?,
        design2_over_gpudirect: ratio_statistics(
            selected.iter().map(|point| point.design2_over_gpudirect),
        )?,
        cpu_bounce_over_design1: ratio_statistics(
            selected.iter().map(|point| point.cpu_bounce_over_design1),
        )?,
        cpu_bounce_over_design2: ratio_statistics(
            selected.iter().map(|point| point.cpu_bounce_over_design2),
        )?,
        design1_over_design2: ratio_statistics(
            selected.iter().map(|point| point.design1_over_design2),
        )?,
        pp,
        fsdp,
        tp_sp,
        hybrid,
        moe_ring,
    })
}

fn paired_e2e(rows: &[E2ePaths<'_>], workload: E2eWorkload) -> Result<PairedE2eCompletion> {
    Ok(PairedE2eCompletion {
        ring: e2e_comparison(rows, workload, Algorithm::Ring)?,
        halving_doubling: e2e_comparison(rows, workload, Algorithm::HalvingDoubling)?,
    })
}

fn e2e_comparison(
    rows: &[E2ePaths<'_>],
    workload: E2eWorkload,
    algorithm: Algorithm,
) -> Result<E2eComparison> {
    let row = rows
        .iter()
        .find(|row| row.sample.workload == workload && row.sample.algorithm == algorithm)
        .with_context(|| format!("missing E2E result for {workload:?} with {algorithm:?}"))?;
    Ok(E2eComparison {
        design1_over_gpudirect: row.design1 / row.gpudirect,
        design2_over_gpudirect: row.design2 / row.gpudirect,
        cpu_bounce_over_design1: row.cpu_bounce / row.design1,
        cpu_bounce_over_design2: row.cpu_bounce / row.design2,
        design1_over_design2: row.design1 / row.design2,
        design1_completion: crate::domain::shared_kernel::model::Latency::from_micros(row.design1),
    })
}

fn e2e_paths(data: &E2eResults) -> Result<Vec<E2ePaths<'_>>> {
    data.samples
        .iter()
        .filter(|sample| sample.design == Design::Gpudirect)
        .map(|gpudirect| {
            let completion = |design| {
                data.samples
                    .iter()
                    .find(|sample| {
                        sample.design == design
                            && sample.fabric == gpudirect.fabric
                            && sample.algorithm == gpudirect.algorithm
                            && sample.workload == gpudirect.workload
                            && sample.gpus == gpudirect.gpus
                    })
                    .map(|sample| sample.completion.as_micros())
            };
            Ok(E2ePaths {
                sample: gpudirect,
                gpudirect: gpudirect.completion.as_micros(),
                cpu_bounce: completion(Design::CpuBounce)
                    .context("missing CPU-bounce E2E result")?,
                design1: completion(Design::Design1E2e).context("missing Design 1 E2E result")?,
                design2: completion(Design::Design2E2e).context("missing Design 2 E2E result")?,
            })
        })
        .collect()
}

fn ratio_statistics(values: impl Iterator<Item = f64>) -> Result<RatioStatistics> {
    let mut values: Vec<_> = values.collect();
    values.sort_by(f64::total_cmp);
    let min = *values.first().context("empty E2E result set")?;
    let max = *values.last().context("empty E2E result set")?;
    let middle = values.len() / 2;
    let median = if values.len() % 2 == 0 {
        (values[middle - 1] + values[middle]) / 2.0
    } else {
        values[middle]
    };
    Ok(RatioStatistics { min, median, max })
}

struct CollectivePaths<'a> {
    sample: &'a CollectiveSample,
    gpudirect: f64,
    cpu_bounce: f64,
    design1: f64,
    design2: f64,
}

fn summarize_collectives(data: &CollectiveResults) -> Result<CollectiveCompletion> {
    let rows = collective_paths(data)?;
    let at_evaluation_gpus: Vec<_> = rows
        .iter()
        .filter(|entry| entry.sample.gpus == EVALUATION_GPUS)
        .collect();
    if at_evaluation_gpus.is_empty() {
        bail!("collective evaluation has no {EVALUATION_GPUS}-GPU rows");
    }

    let small_size_bytes = at_evaluation_gpus
        .iter()
        .map(|entry| entry.sample.size_bytes)
        .min()
        .context("collective evaluation has no message sizes")?;
    let large_size_bytes = at_evaluation_gpus
        .iter()
        .map(|entry| entry.sample.size_bytes)
        .max()
        .context("collective evaluation has no message sizes")?;

    let d1_over_gdr = |entries: Vec<&CollectivePaths>| -> Result<(f64, f64)> {
        range(
            entries
                .into_iter()
                .map(|entry| entry.design1 / entry.gpudirect),
        )
    };
    let cpu_over_d1 = |entries: Vec<&CollectivePaths>| -> Result<(f64, f64)> {
        range(
            entries
                .into_iter()
                .map(|entry| entry.cpu_bounce / entry.design1),
        )
    };

    let small_entries: Vec<_> = at_evaluation_gpus
        .iter()
        .copied()
        .filter(|entry| entry.sample.size_bytes == small_size_bytes)
        .collect();
    let large_entries: Vec<_> = at_evaluation_gpus
        .iter()
        .copied()
        .filter(|entry| entry.sample.size_bytes == large_size_bytes)
        .collect();
    let (small_d1_over_gdr_min, small_d1_over_gdr_max) = d1_over_gdr(small_entries.clone())?;
    let small_d1_over_cpu_mean = mean(
        small_entries
            .iter()
            .map(|entry| entry.design1 / entry.cpu_bounce),
    )?;
    let (small_d2_over_gdr_min, small_d2_over_gdr_max) = range(
        small_entries
            .iter()
            .map(|entry| entry.design2 / entry.gpudirect),
    )?;
    let (small_cpu_over_d2_min, small_cpu_over_d2_max) = range(
        small_entries
            .iter()
            .map(|entry| entry.cpu_bounce / entry.design2),
    )?;
    let (small_d1_over_d2_min, small_d1_over_d2_max) = range(
        small_entries
            .iter()
            .map(|entry| entry.design1 / entry.design2),
    )?;
    let large_d1_over_gdr_mean = mean(
        large_entries
            .iter()
            .map(|entry| entry.design1 / entry.gpudirect),
    )?;
    let (large_cpu_over_d1_min, large_cpu_over_d1_max) = cpu_over_d1(large_entries.clone())?;
    let (large_d1_over_d2_min, large_d1_over_d2_max) = range(
        large_entries
            .iter()
            .map(|entry| entry.design1 / entry.design2),
    )?;

    let mut crossovers = Vec::new();
    for algorithm in [Algorithm::Ring, Algorithm::HalvingDoubling] {
        for collective in [
            Collective::AllReduce,
            Collective::AllGather,
            Collective::ReduceScatter,
            Collective::AllToAll,
        ] {
            if let Some(first) = at_evaluation_gpus
                .iter()
                .filter(|entry| {
                    entry.sample.algorithm == algorithm && entry.sample.collective == collective
                })
                .filter(|entry| entry.design1 < entry.cpu_bounce)
                .map(|entry| entry.sample.size_bytes)
                .min()
            {
                crossovers.push(first);
            }
        }
    }
    let (cpu_crossover_min_bytes, cpu_crossover_max_bytes) = range_u64(crossovers)?;

    let mut gpu_counts: Vec<_> = rows.iter().map(|entry| entry.sample.gpus).collect();
    gpu_counts.sort_unstable();
    gpu_counts.dedup();
    let scaling_start_gpus = *gpu_counts
        .first()
        .context("collective evaluation has no GPU counts")?;
    let scaling_end_gpus = *gpu_counts
        .last()
        .context("collective evaluation has no GPU counts")?;
    let scaling_group = |gpus, algorithms: &[Algorithm], collectives: &[Collective]| {
        rows.iter()
            .filter(|entry| {
                entry.sample.gpus == gpus && entry.sample.size_bytes == large_size_bytes
            })
            .filter(|entry| algorithms.contains(&entry.sample.algorithm))
            .filter(|entry| collectives.contains(&entry.sample.collective))
            .collect()
    };
    let (_, scaling_ring_start_overhead) = d1_over_gdr(scaling_group(
        scaling_start_gpus,
        &[Algorithm::Ring],
        &[
            Collective::AllReduce,
            Collective::ReduceScatter,
            Collective::AllToAll,
        ],
    ))?;
    let scaling_ring_end = scaling_group(
        scaling_end_gpus,
        &[Algorithm::Ring],
        &[
            Collective::AllReduce,
            Collective::ReduceScatter,
            Collective::AllToAll,
        ],
    );
    let (_, scaling_ring_end_overhead) = d1_over_gdr(scaling_ring_end.clone())?;
    let (_, scaling_ring_end_d2_overhead) = range(
        scaling_ring_end
            .into_iter()
            .map(|entry| entry.design2 / entry.gpudirect),
    )?;
    let (_, scaling_halving_doubling_max_overhead) = d1_over_gdr(
        rows.iter()
            .filter(|entry| entry.sample.size_bytes == large_size_bytes)
            .filter(|entry| entry.sample.algorithm == Algorithm::HalvingDoubling)
            .filter(|entry| {
                matches!(
                    entry.sample.collective,
                    Collective::AllReduce | Collective::ReduceScatter
                )
            })
            .collect(),
    )?;
    let (_, scaling_all_gather_max_overhead) = d1_over_gdr(
        rows.iter()
            .filter(|entry| entry.sample.size_bytes == large_size_bytes)
            .filter(|entry| entry.sample.collective == Collective::AllGather)
            .collect(),
    )?;

    Ok(CollectiveCompletion {
        gpus: EVALUATION_GPUS,
        small_size_bytes,
        large_size_bytes,
        small_d1_over_gdr_min,
        small_d1_over_gdr_max,
        small_d1_over_cpu_mean,
        small_d2_over_gdr_min,
        small_d2_over_gdr_max,
        small_cpu_over_d2_min,
        small_cpu_over_d2_max,
        small_d1_over_d2_min,
        small_d1_over_d2_max,
        large_d1_over_gdr_mean,
        large_cpu_over_d1_min,
        large_cpu_over_d1_max,
        large_d1_over_d2_min,
        large_d1_over_d2_max,
        cpu_crossover_min_bytes,
        cpu_crossover_max_bytes,
        scaling_start_gpus,
        scaling_end_gpus,
        scaling_ring_start_overhead,
        scaling_ring_end_overhead,
        scaling_ring_end_d2_overhead,
        scaling_halving_doubling_max_overhead,
        scaling_all_gather_max_overhead,
    })
}

fn collective_paths(data: &CollectiveResults) -> Result<Vec<CollectivePaths<'_>>> {
    data.samples
        .iter()
        .filter(|sample| sample.design == Design::Gpudirect)
        .map(|gpudirect| {
            let completion = |design| {
                data.samples
                    .iter()
                    .find(|sample| {
                        sample.design == design
                            && sample.fabric == gpudirect.fabric
                            && sample.algorithm == gpudirect.algorithm
                            && sample.collective == gpudirect.collective
                            && sample.gpus == gpudirect.gpus
                            && sample.size_bytes == gpudirect.size_bytes
                    })
                    .map(|sample| sample.completion.as_micros())
            };
            Ok(CollectivePaths {
                sample: gpudirect,
                gpudirect: gpudirect.completion.as_micros(),
                cpu_bounce: completion(Design::CpuBounce)
                    .context("missing CPU-bounce collective result")?,
                design1: completion(Design::Design1E2e)
                    .context("missing Design 1 collective result")?,
                design2: completion(Design::Design2E2e)
                    .context("missing Design 2 collective result")?,
            })
        })
        .collect()
}

fn mean(values: impl Iterator<Item = f64>) -> Result<f64> {
    let values: Vec<_> = values.collect();
    if values.is_empty() {
        bail!("empty collective result set");
    }
    Ok(values.iter().sum::<f64>() / values.len() as f64)
}

fn range(values: impl Iterator<Item = f64>) -> Result<(f64, f64)> {
    let mut values: Vec<_> = values.collect();
    values.sort_by(f64::total_cmp);
    Ok((
        *values.first().context("empty collective result set")?,
        *values.last().context("empty collective result set")?,
    ))
}

fn range_u64(mut values: Vec<u64>) -> Result<(u64, u64)> {
    values.sort_unstable();
    Ok((
        *values.first().context("empty collective result set")?,
        *values.last().context("empty collective result set")?,
    ))
}
