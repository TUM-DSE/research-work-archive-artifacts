use crate::domain::shared_kernel::model::units::{Bandwidth, Latency};

// The shared cost-line surface: `T(n) = alpha + n / beta`, defined once.
pub trait CostLine {
    fn alpha(&self) -> Latency;
    fn beta(&self) -> Bandwidth;
    fn cost(&self, n: f64) -> Latency {
        Latency::from_secs(self.alpha().as_secs() + n / self.beta().as_bytes_per_sec())
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AlphaBeta {
    pub alpha: Latency,
    pub beta: Bandwidth,
}

impl AlphaBeta {
    pub fn new(alpha: Latency, beta: Bandwidth) -> Self {
        Self { alpha, beta }
    }
}

impl CostLine for AlphaBeta {
    fn alpha(&self) -> Latency {
        self.alpha
    }
    fn beta(&self) -> Bandwidth {
        self.beta
    }
}
