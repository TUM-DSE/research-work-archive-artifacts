mod args;
mod render;

pub use args::PerfArgs;

use color_eyre::eyre::Result;

use crate::cli::di;
use render::ConsoleObserver;

pub fn run(args: PerfArgs) -> Result<()> {
    let role = args.role()?;
    let app = di::perftest_benchmark();
    let plan = args.plan(role.clone());
    let mut observer = ConsoleObserver::new(role);
    let report = app.run_bench(&plan, args.persist(), &mut observer)?;
    crate::cli::common::run_summary(report.planned, report.persisted);
    Ok(())
}
