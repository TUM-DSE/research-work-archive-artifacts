use crate::domain::{
    bench::model::{BwPoint, LatPoint},
    shared_kernel::model::{
        serde_bandwidth_mibps, serde_latency_us, Bandwidth, Direction, Latency, QpCount, Record,
        Verb,
    },
};
use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::domain::shared_kernel::model::{DatasetIdentity, DatasetRecord};
use crate::libs::schema::Describe;

use super::config::RunConfig;
use super::primitives::{baseline, Mode, NetworkSecurity, Profile};

pub const RESULTS_DIR: &str = "benchmarks/bw_and_lat/results";

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct BwMeasurement {
    #[col(label = "Mode")]
    pub mode: Mode,
    #[serde(default)]
    #[col(label = "Network security")]
    pub security: NetworkSecurity,
    #[col(label = "Verb")]
    pub verb: Verb,
    #[col(label = "Direction")]
    pub direction: Direction,
    #[col(label = "QP count")]
    pub qps: QpCount,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[col(label = "Iterations", role = metadata)]
    pub iters: u64,
    #[serde(rename = "bw_peak_mibps", with = "serde_bandwidth_mibps")]
    #[col(label = "Bandwidth (peak)")]
    pub bw_peak: Bandwidth,
    #[serde(rename = "bw_avg_mibps", with = "serde_bandwidth_mibps")]
    #[col(label = "Bandwidth (avg)")]
    pub bw_avg: Bandwidth,
    #[col(label = "Message rate", unit = "Mpps", better = higher)]
    pub msg_rate_mpps: f64,
    #[col(label = "Recorded (UTC)", role = metadata, ty = datetime)]
    pub utc_time: String,
}

impl BwMeasurement {
    pub fn from_run(config: &RunConfig, metrics: &BwPoint) -> Self {
        Self {
            mode: config.transport.mode,
            security: config.security,
            verb: config.transport.verb,
            direction: match config.profile {
                Profile::Bw { direction, .. } => direction,
                Profile::Lat => Direction::Uni,
            },
            qps: match config.profile {
                Profile::Bw { qps, .. } => qps,
                Profile::Lat => QpCount(1),
            },
            size_bytes: config.size_bytes,
            iters: config.iters,
            bw_peak: metrics.peak,
            bw_avg: metrics.avg,
            msg_rate_mpps: metrics.msg_rate_mpps,
            utc_time: now_utc(),
        }
    }
}

impl DatasetRecord for BwMeasurement {
    const IDENTITY: DatasetIdentity =
        DatasetIdentity::new("perftest", RESULTS_DIR, "bw", "RDMA Bandwidth");

    fn baseline() -> Option<serde_json::Value> {
        Some(json!({ "direction": baseline::DIRECTION, "qps": baseline::QPS }))
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct LatMeasurement {
    #[col(label = "Mode")]
    pub mode: Mode,
    #[serde(default)]
    #[col(label = "Network security")]
    pub security: NetworkSecurity,
    #[col(label = "Verb")]
    pub verb: Verb,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[col(label = "Iterations", role = metadata)]
    pub iters: u64,
    #[serde(rename = "lat_min_us", with = "serde_latency_us")]
    #[col(label = "Latency (min)")]
    pub lat_min: Latency,
    #[serde(rename = "lat_max_us", with = "serde_latency_us")]
    #[col(label = "Latency (max)")]
    pub lat_max: Latency,
    #[serde(rename = "lat_typical_us", with = "serde_latency_us")]
    #[col(label = "Latency (typical)")]
    pub lat_typical: Latency,
    #[serde(rename = "lat_avg_us", with = "serde_latency_us")]
    #[col(label = "Latency (avg)")]
    pub lat_avg: Latency,
    #[serde(rename = "lat_stdev_us", with = "serde_latency_us")]
    #[col(label = "Latency (stdev)")]
    pub lat_stdev: Latency,
    #[serde(rename = "lat_p99_us", with = "serde_latency_us")]
    #[col(label = "Latency (p99)")]
    pub lat_p99: Latency,
    #[serde(rename = "lat_p999_us", with = "serde_latency_us")]
    #[col(label = "Latency (p99.9)")]
    pub lat_p999: Latency,
    #[col(label = "Recorded (UTC)", role = metadata, ty = datetime)]
    pub utc_time: String,
}

impl DatasetRecord for LatMeasurement {
    const IDENTITY: DatasetIdentity =
        DatasetIdentity::new("perftest", RESULTS_DIR, "lat", "RDMA Latency");
}

impl LatMeasurement {
    pub fn from_run(config: &RunConfig, metrics: &LatPoint) -> Self {
        Self {
            mode: config.transport.mode,
            security: config.security,
            verb: config.transport.verb,
            size_bytes: config.size_bytes,
            iters: config.iters,
            lat_min: metrics.min,
            lat_max: metrics.max,
            lat_typical: metrics.typical,
            lat_avg: metrics.avg,
            lat_stdev: metrics.stdev,
            lat_p99: metrics.p99,
            lat_p999: metrics.p999,
            utc_time: now_utc(),
        }
    }
}

#[derive(Clone, Debug)]
pub enum PerftestMeasurement {
    Bw(BwMeasurement),
    Lat(LatMeasurement),
}

impl PerftestMeasurement {
    pub fn bw(bw: BwMeasurement) -> Self {
        Self::Bw(bw)
    }

    pub fn lat(lat: LatMeasurement) -> Self {
        Self::Lat(lat)
    }
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct BwKey {
    pub mode: Mode,
    pub security: NetworkSecurity,
    pub verb: Verb,
    pub direction: Direction,
    pub qps: QpCount,
    pub size_bytes: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct LatKey {
    pub mode: Mode,
    pub security: NetworkSecurity,
    pub verb: Verb,
    pub size_bytes: u64,
}

impl Record for BwMeasurement {
    type Key = BwKey;
    fn key(&self) -> BwKey {
        BwKey {
            mode: self.mode,
            security: self.security,
            verb: self.verb,
            direction: self.direction,
            qps: self.qps,
            size_bytes: self.size_bytes,
        }
    }
}

impl Record for LatMeasurement {
    type Key = LatKey;
    fn key(&self) -> LatKey {
        LatKey {
            mode: self.mode,
            security: self.security,
            verb: self.verb,
            size_bytes: self.size_bytes,
        }
    }
}

fn now_utc() -> String {
    Utc::now().format("%Y-%m-%dT%H:%M:%SZ").to_string()
}
