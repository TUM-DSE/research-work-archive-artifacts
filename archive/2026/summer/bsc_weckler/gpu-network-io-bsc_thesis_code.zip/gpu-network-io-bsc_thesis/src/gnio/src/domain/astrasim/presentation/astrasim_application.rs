use std::collections::{BTreeMap, BTreeSet};
use std::sync::mpsc::{self, Receiver};
use std::sync::{Arc, Mutex};

use color_eyre::eyre::Result;
use rayon::prelude::*;

use crate::domain::astrasim::model::{
    AstraSimPlan, AstraSimResult, E2eRow, E2eWorkload, MicroRow, RunSpec, StageWorkload, Workload,
};
use crate::domain::astrasim::service::AstraSimService;
use crate::domain::shared_kernel::infrastructure::CsvRepository;
use crate::domain::shared_kernel::model::{Dataset, Record};

fn format_run_error(error: &color_eyre::Report) -> String {
    format!("{error:#}")
}

// Results arrive in sweep order with a row's designs consecutive (see AstraSimPlan::specs).
pub trait ComparisonSink: Send {
    fn on_result(&mut self, result: &AstraSimResult);
    fn on_failure(&mut self) {}
    fn finish(&mut self);
}

pub struct AstraSimApplication {
    service: AstraSimService,
    store: Arc<CsvRepository>,
}

pub struct SweepOutcome {
    pub results: Vec<AstraSimResult>,
    pub prepared: usize,
    pub skipped: usize,
    pub completed: usize,
    pub failures: Vec<RunFailure>,
    pub persisted: bool,
}

pub struct ContinuationStatus {
    pub completed: Vec<RunSpec>,
    pub pending: Vec<RunSpec>,
}

pub struct RunFailure {
    pub spec: String,
    pub error: String,
}

impl AstraSimApplication {
    pub fn new(service: AstraSimService, store: Arc<CsvRepository>) -> Self {
        Self { service, store }
    }

    /// Ensures the selected STAGE artifacts exist before an E2E simulation.
    pub fn ensure_e2e_traces(&self, workloads: &[StageWorkload]) -> Result<Vec<E2eWorkload>> {
        self.service.ensure_e2e_traces(workloads)
    }

    pub fn continuation_status(&self, plan: &AstraSimPlan) -> Result<ContinuationStatus> {
        self.partition_specs(plan.specs())
    }

    pub fn run(
        &self,
        plan: &AstraSimPlan,
        jobs: usize,
        persist: bool,
        continue_run: bool,
        sink: Box<dyn ComparisonSink>,
    ) -> Result<SweepOutcome> {
        let all_specs = plan.specs();
        let total_specs = all_specs.len();
        let specs = self.pending_specs(all_specs, continue_run)?;
        let skipped = total_specs - specs.len();
        self.service.prepare(&specs)?;

        let prepared = specs.len();
        let persist_e2e = persist
            && specs
                .iter()
                .any(|spec| matches!(spec.workload, Workload::E2e(_)));
        let execution = self.execute(specs, jobs, sink, persist_e2e)?;
        let results = execution.results;

        let persisted = persist && execution.completed > 0;
        if persist && !results.is_empty() {
            self.save_results(&results)?;
        }

        Ok(SweepOutcome {
            results,
            prepared,
            skipped,
            completed: execution.completed,
            failures: execution.failures,
            persisted,
        })
    }

    fn pending_specs(&self, specs: Vec<RunSpec>, continue_run: bool) -> Result<Vec<RunSpec>> {
        if !continue_run {
            return Ok(specs);
        }

        Ok(self.partition_specs(specs)?.pending)
    }

    fn partition_specs(&self, specs: Vec<RunSpec>) -> Result<ContinuationStatus> {
        let completed_micro: BTreeSet<_> = self
            .store
            .load::<MicroRow>()?
            .iter()
            .map(|row| row.key())
            .collect();
        let completed_e2e: BTreeSet<_> = self
            .store
            .load::<E2eRow>()?
            .iter()
            .map(|row| row.key())
            .collect();

        let mut completed = Vec::new();
        let mut pending = Vec::new();
        for spec in specs {
            let is_complete = match &spec.workload {
                Workload::Micro(workload) => completed_micro.contains(&(
                    spec.link.design,
                    spec.fabric.to_id(),
                    spec.algorithm,
                    workload.collective,
                    spec.npus(),
                    workload.size_bytes,
                )),
                Workload::E2e(workload) => completed_e2e.contains(&(
                    spec.link.design,
                    spec.fabric.to_id(),
                    spec.algorithm,
                    workload.display_name.clone(),
                    spec.npus(),
                )),
            };
            if is_complete {
                completed.push(spec);
            } else {
                pending.push(spec);
            }
        }
        Ok(ContinuationStatus { completed, pending })
    }

    fn save_results(&self, results: &[AstraSimResult]) -> Result<()> {
        let mut micro: Dataset<MicroRow> = Dataset::default();
        let mut e2e: Dataset<E2eRow> = Dataset::default();
        for result in results {
            match result {
                AstraSimResult::Micro(row) => micro.insert(row.clone()),
                AstraSimResult::E2e(row) => e2e.insert(row.clone()),
            }
        }
        if !micro.is_empty() {
            self.store.save(&micro)?;
        }
        if !e2e.is_empty() {
            self.store.save(&e2e)?;
        }
        Ok(())
    }

    fn execute(
        &self,
        specs: Vec<RunSpec>,
        jobs: usize,
        sink: Box<dyn ComparisonSink>,
        persist_e2e: bool,
    ) -> Result<ExecutionOutcome> {
        let (tx, rx) = mpsc::channel::<RunMessage>();
        let store = Arc::clone(&self.store);
        let collector =
            std::thread::spawn(move || Self::collect_ordered(sink, rx, store, persist_e2e));

        let tx = Mutex::new(tx);
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(jobs.max(1))
            .build()?;
        pool.install(|| {
            specs.par_iter().enumerate().for_each(|(i, spec)| {
                let message = RunMessage {
                    index: i,
                    spec: spec.slug(),
                    // Alternate Display includes the complete eyre context
                    // chain; plain `to_string()` only showed the outer `spec`
                    // context and hid the actual process/parse failure.
                    result: self
                        .service
                        .run(spec)
                        .map_err(|error| format_run_error(&error)),
                };
                let _ = tx.lock().unwrap().send(message);
            })
        });
        drop(tx);
        let collected = collector.join().expect("collector thread panicked")?;
        Ok(collected)
    }

    fn collect_ordered(
        mut sink: Box<dyn ComparisonSink>,
        rx: Receiver<RunMessage>,
        store: Arc<CsvRepository>,
        persist_e2e: bool,
    ) -> Result<ExecutionOutcome> {
        let mut pending: BTreeMap<usize, RunMessage> = BTreeMap::new();
        let mut failures = Vec::new();
        let mut next = 0usize;
        let mut results = Vec::new();
        let mut completed = 0usize;
        for message in rx {
            let i = message.index;
            if let Err(error) = &message.result {
                eprintln!("ASTRA-sim failed for {}: {}", message.spec, error);
            }
            // Persist before putting the result into the ordering buffer. A
            // later result can finish while an earlier simulation is still
            // running, and should already be durable in that case.
            if persist_e2e {
                if let Ok(AstraSimResult::E2e(row)) = &message.result {
                    let mut dataset = Dataset::default();
                    dataset.insert(row.clone());
                    store.save(&dataset)?;
                }
            }
            pending.insert(i, message);
            while let Some(message) = pending.remove(&next) {
                match message.result {
                    Ok(result) => {
                        sink.on_result(&result);
                        if !(persist_e2e && matches!(&result, AstraSimResult::E2e(_))) {
                            results.push(result);
                        }
                        completed += 1;
                    }
                    Err(error) => {
                        sink.on_failure();
                        failures.push(RunFailure {
                            spec: message.spec,
                            error,
                        });
                    }
                }
                next += 1;
            }
        }
        sink.finish();
        Ok(ExecutionOutcome {
            results,
            completed,
            failures,
        })
    }
}

struct ExecutionOutcome {
    results: Vec<AstraSimResult>,
    completed: usize,
    failures: Vec<RunFailure>,
}

struct RunMessage {
    index: usize,
    spec: String,
    result: std::result::Result<AstraSimResult, String>,
}
