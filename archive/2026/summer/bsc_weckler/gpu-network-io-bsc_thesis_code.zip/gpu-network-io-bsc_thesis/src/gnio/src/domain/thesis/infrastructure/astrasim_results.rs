use color_eyre::eyre::Result;

use crate::domain::astrasim::model::{
    Collective as AstraCollective, CollectiveImpl, Design as AstraDesign, StageWorkload,
};
use crate::domain::astrasim::presentation::AstraResultsApplication;
use crate::domain::shared_kernel::model::Latency;
use crate::domain::thesis::model::{
    Algorithm, Collective, CollectiveResults, CollectiveSample, Design, E2eResults, E2eSample,
    E2eWorkload,
};
use crate::domain::thesis::repository::AstraResultsRepository;

pub struct AstraSimResultsRepository {
    application: Box<AstraResultsApplication>,
}

impl AstraSimResultsRepository {
    pub fn new(application: Box<AstraResultsApplication>) -> Self {
        Self { application }
    }
}

impl AstraResultsRepository for AstraSimResultsRepository {
    fn load_collectives(&self) -> Result<CollectiveResults> {
        let samples = self
            .application
            .microbenchmarks()?
            .into_iter()
            .filter_map(|row| {
                Some(CollectiveSample {
                    design: map_design(row.design),
                    fabric: row.fabric.to_id(),
                    algorithm: match row.algorithm {
                        CollectiveImpl::Ring => Algorithm::Ring,
                        CollectiveImpl::HalvingDoubling => Algorithm::HalvingDoubling,
                        _ => return None,
                    },
                    collective: match row.collective {
                        AstraCollective::AllReduce => Collective::AllReduce,
                        AstraCollective::AllGather => Collective::AllGather,
                        AstraCollective::ReduceScatter => Collective::ReduceScatter,
                        AstraCollective::AllToAll => Collective::AllToAll,
                    },
                    gpus: row.npus,
                    size_bytes: row.size_bytes,
                    completion: Latency::from_micros(row.completion_us),
                })
            })
            .collect();
        Ok(CollectiveResults { samples })
    }

    fn load_e2e(&self) -> Result<E2eResults> {
        let samples = self
            .application
            .e2e_workloads()?
            .into_iter()
            .filter_map(|row| {
                Some(E2eSample {
                    design: map_design(row.design),
                    fabric: row.fabric.to_id(),
                    algorithm: map_algorithm(row.algorithm)?,
                    workload: map_workload(&row.trace)?,
                    gpus: row.npus,
                    completion: Latency::from_micros(row.completion_us),
                })
            })
            .collect();
        Ok(E2eResults { samples })
    }
}

fn map_design(design: AstraDesign) -> Design {
    match design {
        AstraDesign::GpuDirect => Design::Gpudirect,
        AstraDesign::CpuBounce => Design::CpuBounce,
        AstraDesign::D1Single => Design::Design1Single,
        AstraDesign::D1E2e => Design::Design1E2e,
        AstraDesign::D2E2e => Design::Design2E2e,
    }
}

fn map_algorithm(algorithm: CollectiveImpl) -> Option<Algorithm> {
    match algorithm {
        CollectiveImpl::Ring => Some(Algorithm::Ring),
        CollectiveImpl::HalvingDoubling => Some(Algorithm::HalvingDoubling),
        _ => None,
    }
}

fn map_workload(trace: &str) -> Option<E2eWorkload> {
    let workload = StageWorkload::ALL
        .into_iter()
        .find(|workload| workload.to_string() == trace)?;
    match workload {
        StageWorkload::Gpt3_5bPp8 => Some(E2eWorkload::Gpt3_5bPp),
        StageWorkload::Gpt3_5bFsdp8 => Some(E2eWorkload::Gpt3_5bFsdp),
        StageWorkload::Gpt3_175bTp32 => Some(E2eWorkload::Gpt3_175bTpSp),
        StageWorkload::Gpt3_175bHybrid64 => Some(E2eWorkload::Gpt3_175bHybrid),
        StageWorkload::Mixtral8x7bEp8Pp4 => Some(E2eWorkload::Mixtral8x7bEpPp),
    }
}
