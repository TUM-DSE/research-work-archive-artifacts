use serde::{Deserialize, Serialize};

use crate::domain::astrasim::model::{Collective, CollectiveImpl, Design, Fabric};
use crate::domain::shared_kernel::model::{DatasetIdentity, DatasetRecord, Record};
use crate::libs::schema::Describe;

pub const RESULTS_DIR: &str = "benchmarks/astra-sim/results";

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct MicroRow {
    #[col(label = "Design")]
    pub design: Design,
    #[col(label = "Fabric")]
    pub fabric: Fabric,
    #[col(label = "Logical algorithm")]
    pub algorithm: CollectiveImpl,
    #[col(label = "Collective")]
    pub collective: Collective,
    #[col(label = "NPUs")]
    pub npus: u32,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[col(label = "Completion time", unit = "µs", better = lower)]
    pub completion_us: f64,
    #[col(label = "Algorithmic bandwidth", unit = "GB/s", better = higher)]
    pub algo_bw_gbps: f64,
}

impl MicroRow {
    pub fn new(
        design: Design,
        fabric: Fabric,
        algorithm: CollectiveImpl,
        collective: Collective,
        npus: u32,
        size_bytes: u64,
        completion_us: f64,
    ) -> Self {
        // effective (algorithmic) bandwidth: bytes moved by the op over wall-clock time
        let algo_bw_gbps = if completion_us > 0.0 {
            (size_bytes as f64) / (completion_us * 1e3)
        } else {
            0.0
        };
        Self {
            design,
            fabric,
            algorithm,
            collective,
            npus,
            size_bytes,
            completion_us,
            algo_bw_gbps,
        }
    }
}

impl DatasetRecord for MicroRow {
    const IDENTITY: DatasetIdentity = DatasetIdentity::new(
        "astrasim",
        RESULTS_DIR,
        "astra_micro",
        "ASTRA-sim Collective Microbenchmarks",
    )
    .named("micro");
}

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct E2eRow {
    #[col(label = "Design")]
    pub design: Design,
    #[col(label = "Fabric")]
    pub fabric: Fabric,
    #[col(label = "Logical algorithm")]
    pub algorithm: CollectiveImpl,
    #[col(label = "Trace")]
    pub trace: String,
    #[col(label = "NPUs")]
    pub npus: u32,
    #[col(label = "Completion time", unit = "µs", better = lower)]
    pub completion_us: f64,
}

impl DatasetRecord for E2eRow {
    const IDENTITY: DatasetIdentity = DatasetIdentity::new(
        "astrasim",
        RESULTS_DIR,
        "astra_e2e",
        "ASTRA-sim End-to-End Workloads",
    )
    .named("e2e");
}

#[derive(Clone, Debug)]
pub enum AstraSimResult {
    Micro(MicroRow),
    E2e(E2eRow),
}

impl Record for MicroRow {
    type Key = (Design, String, CollectiveImpl, Collective, u32, u64);
    fn key(&self) -> Self::Key {
        (
            self.design,
            self.fabric.to_id(),
            self.algorithm,
            self.collective,
            self.npus,
            self.size_bytes,
        )
    }
}

impl Record for E2eRow {
    type Key = (Design, String, CollectiveImpl, String, u32);
    fn key(&self) -> Self::Key {
        (
            self.design,
            self.fabric.to_id(),
            self.algorithm,
            self.trace.clone(),
            self.npus,
        )
    }
}
