use std::process::Command;
use std::time::Duration;

use color_eyre::eyre::{bail, Result, WrapErr};
use serde::Deserialize;

const BINARY: &str = env!("UVMGPU_BENCH");

#[derive(Clone, Copy)]
pub enum Mode {
    Seal,
    Unseal,
    DeviceToDevice,
    DeviceToHost,
    HostToDevice,
}

impl Mode {
    fn name(self) -> &'static str {
        match self {
            Self::Seal => "seal",
            Self::Unseal => "unseal",
            Self::DeviceToDevice => "dtod",
            Self::DeviceToHost => "dtoh",
            Self::HostToDevice => "htod",
        }
    }
}

#[derive(Deserialize)]
struct LatJson {
    total_ns: Vec<u64>,
    preprocess_ns: Vec<u64>,
    gpu_ns: Vec<u64>,
}

#[derive(Deserialize)]
struct BwJson {
    copies: u64,
    gpu_ns: u64,
}

pub struct LatPoint {
    pub total: Vec<Duration>,
    pub preprocess: Vec<Duration>,
    pub gpu: Vec<Duration>,
}

pub struct BwPoint {
    pub copies: u64,
    pub gpu: Duration,
}

pub fn latency(mode: Mode, size: usize, iterations: u32, warmup: u32) -> Result<LatPoint> {
    let output = execute(mode, "lat", size, iterations, warmup)?;
    let point: LatJson = serde_json::from_slice(&output).wrap_err("parse uvmgpu latency JSON")?;
    Ok(LatPoint {
        total: durations(point.total_ns),
        preprocess: durations(point.preprocess_ns),
        gpu: durations(point.gpu_ns),
    })
}

pub fn bandwidth(mode: Mode, size: usize, copies: u32, warmup: u32) -> Result<BwPoint> {
    let output = execute(mode, "bw", size, copies, warmup)?;
    let point: BwJson = serde_json::from_slice(&output).wrap_err("parse uvmgpu bandwidth JSON")?;
    Ok(BwPoint {
        copies: point.copies,
        gpu: Duration::from_nanos(point.gpu_ns),
    })
}

fn execute(mode: Mode, metric: &str, size: usize, iterations: u32, warmup: u32) -> Result<Vec<u8>> {
    let output = Command::new(BINARY)
        .args([
            mode.name(),
            metric,
            &size.to_string(),
            &iterations.to_string(),
            &warmup.to_string(),
        ])
        .output()
        .wrap_err("run uvmgpu_bench")?;

    if !output.status.success() {
        bail!(
            "uvmgpu_bench failed: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        );
    }
    Ok(output.stdout)
}

fn durations(values: Vec<u64>) -> Vec<Duration> {
    values.into_iter().map(Duration::from_nanos).collect()
}
