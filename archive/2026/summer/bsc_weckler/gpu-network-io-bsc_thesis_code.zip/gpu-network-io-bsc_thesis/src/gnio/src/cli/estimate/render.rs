use termtree::Tree;

use crate::cli::common::{comparison_table, metrics_table, SIZES};
use crate::domain::bench::model::gpucopy::ComponentCost;
use crate::domain::bench::model::{CostModel, ValidationReport};
use crate::domain::bench::presentation::EstimationReport;
use crate::domain::shared_kernel::model::AlphaBeta;
use crate::libs::cli::{color, fmt, table};

pub fn summary(report: &EstimationReport, validation: Option<&ValidationReport>) {
    let c = color::enabled();
    let model = &*report.model;

    println!();
    println!(
        "  {}",
        color::bold(&format!("estimate · {}", report.mode), c)
    );
    println!();
    let mut cells = Vec::new();
    let labels = walk(model, "result", &mut cells, c);
    let aligned = table::beside(&labels.to_string(), &cells.join("\n"), 4);
    println!("{}", table::indent(&aligned, 4));
    println!();

    match validation {
        Some(v) => {
            let measured_label = v
                .against
                .ground_truth()
                .map(|truth| truth.label())
                .unwrap_or_else(|| "explicit comparison".to_string());
            println!(
                "    {}",
                color::dim(&format!("measured · {measured_label}"), c)
            );
            let block = table::beside(
                &comparison_table(model, &v.measured),
                &metrics_table(v, c),
                4,
            );
            println!("{}", table::indent(&block, 4));
        }
        None => println!("{}", table::indent(&predicted_table(model), 4)),
    }
}

// Agnostic: every node prints its own `ab()` summary and recurses into `children()`,
// each child labelling itself. Adding a new cost model never touches this.
fn walk(model: &dyn CostModel, label: &str, cells: &mut Vec<String>, c: bool) -> Tree<String> {
    cells.push(ab_cells(model.ab(), model.gpu_copy_cost(), c));
    let mut t = Tree::new(label.to_string());
    for child in model.children() {
        t.push(walk(child, child.label(), cells, c));
    }
    t
}

fn predicted_table(model: &dyn CostModel) -> String {
    let rows: Vec<Vec<String>> = SIZES
        .iter()
        .map(|&n| {
            let nf = n as f64;
            vec![
                fmt::size(n),
                fmt::gbps(model.bandwidth(nf).as_gbps()),
                fmt::latency_us(model.cost(nf).as_micros()),
            ]
        })
        .collect();
    table::psql(&["size", "bandwidth", "latency"], rows, 1)
}

fn ab_cells(ab: AlphaBeta, gpu: Option<ComponentCost>, c: bool) -> String {
    let mut s = format!(
        "{} {}    {} {}",
        color::dim("α", c),
        color::green_bold(&format!("{:>10}", fmt::latency_us(ab.alpha.as_micros())), c),
        color::dim("β", c),
        color::cyan(&format!("{:>12}", fmt::gbps(ab.beta.as_gbps())), c),
    );
    if let Some(gc) = gpu {
        s.push_str(&format!(
            "    {} {}    {} {}",
            color::dim("cmd", c),
            color::magenta(
                &format!("{:>10}", fmt::latency_us(gc.command.as_micros())),
                c
            ),
            color::dim("cpy", c),
            color::magenta(&format!("{:>10}", fmt::latency_us(gc.copy.as_micros())), c),
        ));
    }
    s
}
