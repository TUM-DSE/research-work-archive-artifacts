use std::{collections::BTreeSet, sync::Arc};

use color_eyre::eyre::{eyre, Result};

use crate::domain::bench::model::gpucopy::{self, GpuCopyPlan};
use crate::domain::bench::model::perftest::{PerftestMeasurement, PerftestPlan, RunConfig};
use crate::domain::bench::repository::PerftestRunner;
use crate::domain::bench::service::GpuBenchService;
use crate::domain::shared_kernel::infrastructure::CsvRepository;
use crate::domain::shared_kernel::model::Dataset;
use crate::libs::{clocks, memlock};

pub trait PerftestObserver {
    fn on_start(&mut self, config: &RunConfig);
    fn on_measured(&mut self, row: &PerftestMeasurement);
}

pub struct PerftestReport {
    pub planned: usize,
    pub measured: Vec<PerftestMeasurement>,
    pub persisted: bool,
}

pub struct PerftestApplication {
    runner: Option<Box<dyn PerftestRunner>>,
    store: Arc<CsvRepository>,
}

impl PerftestApplication {
    pub fn new(runner: Box<dyn PerftestRunner>, store: Arc<CsvRepository>) -> Self {
        Self {
            runner: Some(runner),
            store,
        }
    }

    pub fn run_bench(
        &self,
        plan: &PerftestPlan,
        persist: bool,
        observer: &mut dyn PerftestObserver,
    ) -> Result<PerftestReport> {
        let runner = self
            .runner
            .as_ref()
            .ok_or_else(|| eyre!("perftest runner not available in this build"))?;

        // a valid measurement runs under a locked-clock, mem-locked environment
        clocks::lock();
        memlock::raise();

        let configs = plan.expand();
        let mut measured: Vec<PerftestMeasurement> = Vec::new();
        for config in &configs {
            observer.on_start(config);
            for row in runner.run(config)? {
                observer.on_measured(&row);
                measured.push(row);
            }
        }

        let persisted = persist && !measured.is_empty();
        if persisted {
            let mut bw = Dataset::default();
            let mut lat = Dataset::default();
            for row in &measured {
                match row {
                    PerftestMeasurement::Bw(r) => bw.insert(r.clone()),
                    PerftestMeasurement::Lat(r) => lat.insert(r.clone()),
                }
            }
            self.store.save(&bw)?;
            self.store.save(&lat)?;
        }

        Ok(PerftestReport {
            planned: configs.len(),
            measured,
            persisted,
        })
    }
}

pub trait GpuCopyObserver {
    fn on_start(&mut self, config: &gpucopy::RunConfig);
    fn on_measured(&mut self, measurement: &gpucopy::GpuCopyMeasurement);
}

pub struct GpuCopyReport {
    pub planned: usize,
    pub measured: Vec<gpucopy::GpuCopyMeasurement>,
    pub persisted: bool,
}

pub struct GpuApplication {
    gpu: Option<Box<dyn GpuBenchService>>,
    store: Arc<CsvRepository>,
}

impl GpuApplication {
    pub fn new(gpu: Box<dyn GpuBenchService>, store: Arc<CsvRepository>) -> Self {
        Self {
            gpu: Some(gpu),
            store,
        }
    }

    pub fn run_bench(
        &mut self,
        plan: &GpuCopyPlan,
        persist: bool,
        observer: &mut dyn GpuCopyObserver,
    ) -> Result<GpuCopyReport> {
        let gpu = self
            .gpu
            .as_mut()
            .ok_or_else(|| eyre!("gpu backend not available (built without the `gpu` feature)"))?;

        // a valid measurement runs under a locked-clock, mem-locked environment
        clocks::lock();
        memlock::raise();

        let configs = plan.expand();
        let mut measured = Vec::new();
        for config in &configs {
            observer.on_start(config);
            for measurement in gpu.run(config)? {
                observer.on_measured(&measurement);
                measured.push(measurement);
            }
        }

        let persisted = persist && !measured.is_empty();
        if persisted {
            let mut bw = Dataset::default();
            let mut lat = Dataset::default();
            for measurement in &measured {
                match measurement {
                    gpucopy::GpuCopyMeasurement::Bw(r) => bw.insert(r.clone()),
                    gpucopy::GpuCopyMeasurement::Lat(r) => lat.insert(r.clone()),
                }
            }
            self.store.save(&bw)?;

            // GPU latency replaces every component for (mode, size)
            let refreshed: BTreeSet<_> = lat.iter().map(|row| (row.mode, row.size_bytes)).collect();
            self.store
                .save_replacing(&lat, |row| refreshed.contains(&(row.mode, row.size_bytes)))?;
        }

        Ok(GpuCopyReport {
            planned: configs.len(),
            measured,
            persisted,
        })
    }
}
