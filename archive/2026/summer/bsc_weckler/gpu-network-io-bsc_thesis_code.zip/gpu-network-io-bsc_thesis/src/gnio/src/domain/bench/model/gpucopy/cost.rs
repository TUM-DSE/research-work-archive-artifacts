use color_eyre::eyre::{bail, Result};

use crate::domain::bench::model::curve::{ComponentCurve, FIXED_LATENCY_SIZE_BYTES};
use crate::domain::bench::model::gpucopy::LatComponent;
use crate::domain::shared_kernel::model::{AlphaBeta, Bandwidth, CostLine, Latency};

// A cost line plus the latency floors it decomposes into (command submission vs. copy).
#[derive(Clone, Copy, Debug)]
pub struct ComponentCost {
    pub line: AlphaBeta,
    pub command: Latency,
    pub copy: Latency,
}

impl CostLine for ComponentCost {
    fn alpha(&self) -> Latency {
        self.line.alpha
    }
    fn beta(&self) -> Bandwidth {
        self.line.beta
    }
}

impl ComponentCost {
    // Alpha is the median at the canonical small-message size; beta is peak bandwidth.
    // Modes without a command/copy decomposition default those components to total alpha.
    pub fn from_curve(curve: ComponentCurve) -> Result<Self> {
        let ComponentCurve { bw, lat } = curve;
        let median_at_reference = |component: LatComponent| {
            lat.get(&component)
                .and_then(|curve| curve.median_at_or_below(FIXED_LATENCY_SIZE_BYTES))
        };

        let Some(alpha) = median_at_reference(LatComponent::Total) else {
            bail!(
                "no median latency measurement at or below {} bytes to estimate alpha from",
                FIXED_LATENCY_SIZE_BYTES
            );
        };
        let Some(beta) = bw.peak() else {
            bail!("no bandwidth measurements to estimate beta from");
        };

        Ok(Self {
            line: AlphaBeta::new(alpha, beta),
            command: median_at_reference(LatComponent::Command).unwrap_or(alpha),
            copy: median_at_reference(LatComponent::Copy).unwrap_or(alpha),
        })
    }
}
