use color_eyre::eyre::{Result, WrapErr};

use crate::domain::astrasim::model::{
    AstraSimResult, E2eRow, E2eWorkload, MicroRow, RunSpec, StageWorkload, Workload,
};
use crate::domain::astrasim::repository::{AstraSimRunner, E2eTraceRepository, ResultParser};

pub struct AstraSimService {
    runner: Box<dyn AstraSimRunner>,
    e2e_traces: Box<dyn E2eTraceRepository>,
    parser: Box<dyn ResultParser>,
}

impl AstraSimService {
    pub fn new(
        runner: Box<dyn AstraSimRunner>,
        e2e_traces: Box<dyn E2eTraceRepository>,
        parser: Box<dyn ResultParser>,
    ) -> Self {
        Self {
            runner,
            e2e_traces,
            parser,
        }
    }

    /// Ensures the selected STAGE artifacts exist before an E2E simulation.
    pub fn ensure_e2e_traces(&self, workloads: &[StageWorkload]) -> Result<Vec<E2eWorkload>> {
        workloads
            .iter()
            .map(|&workload| self.e2e_traces.ensure(workload))
            .collect()
    }

    pub fn prepare(&self, specs: &[RunSpec]) -> Result<()> {
        self.runner.prepare()?;
        self.runner.generate_traces(specs)
    }

    /// Executes and parses one simulation. Parallel scheduling is deliberately
    /// owned by the application layer.
    pub fn run(&self, spec: &RunSpec) -> Result<AstraSimResult> {
        let outcome = self
            .runner
            .run(spec)
            .wrap_err_with(|| format!("spec {}", spec.slug()))?;
        let completion_us = self
            .parser
            .parse(&outcome)
            .wrap_err_with(|| format!("parse result for spec {}", spec.slug()))?;
        let npus = spec.npus();

        Ok(match &spec.workload {
            Workload::Micro(workload) => AstraSimResult::Micro(MicroRow::new(
                spec.link.design,
                spec.fabric.clone(),
                spec.algorithm,
                workload.collective,
                npus,
                workload.size_bytes,
                completion_us,
            )),
            Workload::E2e(workload) => AstraSimResult::E2e(E2eRow {
                design: spec.link.design,
                fabric: spec.fabric.clone(),
                algorithm: spec.algorithm,
                trace: workload.display_name.clone(),
                npus,
                completion_us,
            }),
        })
    }
}
