use std::sync::Arc;

use color_eyre::eyre::Result;

use crate::domain::bench::model::{CostModel, CurvePair, EstimatedCurve, EstimationMode};
use crate::domain::bench::service::TransportEstimatorService;
use crate::domain::shared_kernel::infrastructure::CsvRepository;
use crate::domain::shared_kernel::model::Dataset;

pub struct EstimationReport {
    pub mode: EstimationMode,
    pub model: Box<dyn CostModel>,
}

pub struct EstimationApplication {
    estimator: Box<dyn TransportEstimatorService>,
    log: Arc<CsvRepository>,
}

impl EstimationApplication {
    pub fn new(estimator: Box<dyn TransportEstimatorService>, log: Arc<CsvRepository>) -> Self {
        Self { estimator, log }
    }

    pub fn estimate(&self, mode: EstimationMode) -> Result<EstimationReport> {
        let model = self.estimator.estimate(mode)?;
        Ok(EstimationReport { mode, model })
    }

    pub fn log_curves(&self, entries: &[(EstimationReport, Option<CurvePair>)]) -> Result<()> {
        let mut curve = EstimatedCurve {
            bw: Vec::new(),
            lat: Vec::new(),
        };
        for (report, measured) in entries {
            let estimated = EstimatedCurve::predict(report.mode, &*report.model);
            curve.bw.extend(estimated.bw);
            curve.lat.extend(estimated.lat);
            if let Some(measured) = measured {
                let measured = EstimatedCurve::from_measured(report.mode, measured);
                curve.bw.extend(measured.bw);
                curve.lat.extend(measured.lat);
            }
        }
        self.log.save(&Dataset::from_iter(curve.bw))?;
        self.log.save(&Dataset::from_iter(curve.lat))
    }
}
