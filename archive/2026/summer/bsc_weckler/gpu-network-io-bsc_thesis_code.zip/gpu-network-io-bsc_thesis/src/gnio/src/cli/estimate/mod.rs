mod args;
mod render;

pub use args::EstimateArgs;

use color_eyre::eyre::Result;

use crate::cli::di;

pub fn run(args: EstimateArgs) -> Result<()> {
    let app = di::estimation();
    let validator = di::validation();

    let mut entries = Vec::new();
    for mode in args.modes() {
        match app.estimate(mode) {
            Ok(report) => {
                let validation = validator.validate(mode, None).ok();
                render::summary(&report, validation.as_ref());
                let measured = validation.map(|v| v.measured);
                entries.push((report, measured));
            }
            Err(e) => eprintln!("estimate {mode:?}: {e:#}"),
        }
    }

    if args.log && !entries.is_empty() {
        app.log_curves(&entries)?;
        eprintln!(
            "\nwrote estimated + measured bw.csv + lat.csv ({} mode(s)) to {}",
            entries.len(),
            di::results_dir(crate::domain::bench::model::estimated::RESULTS_DIR).display()
        );
    }
    Ok(())
}
