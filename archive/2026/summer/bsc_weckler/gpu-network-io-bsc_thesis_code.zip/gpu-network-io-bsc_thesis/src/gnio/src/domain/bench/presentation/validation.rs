use color_eyre::eyre::Result;

use crate::domain::bench::model::{EstimationMode, ValidationReport};
use crate::domain::bench::service::ValidationService;

pub struct ValidationApplication {
    service: Box<dyn ValidationService>,
}

impl ValidationApplication {
    pub fn new(service: Box<dyn ValidationService>) -> Self {
        Self { service }
    }

    pub fn validate(
        &self,
        mode: EstimationMode,
        against: Option<EstimationMode>,
    ) -> Result<ValidationReport> {
        self.service.validate(mode, against)
    }
}
