use std::fmt::{self};
use std::path::PathBuf;

use strum::{AsRefStr, EnumString};

use crate::libs::id::serde_id;
use crate::libs::schema::{values_of, ColumnSchema, ColumnType, ValueMeta};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum Collective {
    AllReduce,
    AllGather,
    ReduceScatter,
    AllToAll,
}

impl Collective {
    pub const ALL: [Collective; 4] = [
        Collective::AllReduce,
        Collective::AllGather,
        Collective::ReduceScatter,
        Collective::AllToAll,
    ];
}

impl fmt::Display for Collective {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Collective::AllReduce => "All-Reduce",
            Collective::AllGather => "All-Gather",
            Collective::ReduceScatter => "Reduce-Scatter",
            Collective::AllToAll => "All-to-All",
        })
    }
}

serde_id!(Collective);

impl ColumnSchema for Collective {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(values_of(&Collective::ALL))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum StageWorkload {
    Gpt3_5bPp8,
    Gpt3_5bFsdp8,
    Gpt3_175bTp32,
    Gpt3_175bHybrid64,
    Mixtral8x7bEp8Pp4,
}

impl StageWorkload {
    pub const ALL: [Self; 5] = [
        Self::Gpt3_5bPp8,
        Self::Gpt3_5bFsdp8,
        Self::Gpt3_175bTp32,
        Self::Gpt3_175bHybrid64,
        Self::Mixtral8x7bEp8Pp4,
    ];

    pub fn config(self) -> StageConfig {
        match self {
            Self::Gpt3_5bPp8 => StageConfig::gpt(
                24, 4_096, 16_384, 32, 32, 1, 1, 1, 1, 8, 128, 1, false, false,
            ),
            Self::Gpt3_5bFsdp8 => StageConfig::gpt(
                24, 4_096, 16_384, 32, 32, 8, 1, 1, 1, 1, 128, 8, true, false,
            ),
            Self::Gpt3_175bTp32 => StageConfig::gpt(
                96, 12_288, 49_152, 96, 96, 1, 32, 1, 1, 1, 128, 1, false, true,
            ),
            Self::Gpt3_175bHybrid64 => StageConfig::gpt(
                96, 12_288, 49_152, 96, 96, 2, 4, 1, 1, 8, 128, 1, false, true,
            ),
            Self::Mixtral8x7bEp8Pp4 => {
                StageConfig::moe(32, 4_096, 14_336, 32, 8, 1, 1, 1, 8, 4, 128, 1, 8, 2)
            }
        }
    }

    pub fn npu_count(self) -> u32 {
        self.config().npu_count()
    }
}

impl fmt::Display for StageWorkload {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::Gpt3_5bPp8 => "GPT-3 5B (PP=8)",
            Self::Gpt3_5bFsdp8 => "GPT-3 5B (FSDP=8)",
            Self::Gpt3_175bTp32 => "GPT-3 175B (TP=32 + SP)",
            Self::Gpt3_175bHybrid64 => "GPT-3 175B (DP=2, TP=4, PP=8 + SP)",
            Self::Mixtral8x7bEp8Pp4 => "Mixtral 8x7B (EP=8, PP=4)",
        })
    }
}

#[derive(Clone, Copy, Debug)]
pub struct StageConfig {
    pub model_type: &'static str,
    pub num_stacks: u32,
    pub dmodel: u32,
    pub dff: u32,
    pub head: u32,
    pub kvhead: u32,
    pub dp: u32,
    pub tp: u32,
    pub sp: u32,
    pub ep: u32,
    pub pp: u32,
    pub batch: u32,
    pub micro_batch: u32,
    pub sequence_length: u32,
    pub vocabulary_size: u32,
    pub experts: u32,
    pub kexperts: u32,
    pub weight_sharded: bool,
    pub tpsp: bool,
    pub mixed_precision: bool,
}

impl StageConfig {
    #[allow(clippy::too_many_arguments)]
    fn gpt(
        num_stacks: u32,
        dmodel: u32,
        dff: u32,
        head: u32,
        kvhead: u32,
        dp: u32,
        tp: u32,
        sp: u32,
        ep: u32,
        pp: u32,
        batch: u32,
        micro_batch: u32,
        weight_sharded: bool,
        tpsp: bool,
    ) -> Self {
        Self {
            model_type: "gpt",
            num_stacks,
            dmodel,
            dff,
            head,
            kvhead,
            dp,
            tp,
            sp,
            ep,
            pp,
            batch,
            micro_batch,
            sequence_length: 1_024,
            vocabulary_size: 50_257,
            experts: 1,
            kexperts: 1,
            weight_sharded,
            tpsp,
            mixed_precision: false,
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn moe(
        num_stacks: u32,
        dmodel: u32,
        dff: u32,
        head: u32,
        kvhead: u32,
        dp: u32,
        tp: u32,
        sp: u32,
        ep: u32,
        pp: u32,
        batch: u32,
        micro_batch: u32,
        experts: u32,
        kexperts: u32,
    ) -> Self {
        Self {
            model_type: "moe",
            num_stacks,
            dmodel,
            dff,
            head,
            kvhead,
            dp,
            tp,
            sp,
            ep,
            pp,
            batch,
            micro_batch,
            sequence_length: 1_024,
            vocabulary_size: 32_000,
            experts,
            kexperts,
            weight_sharded: false,
            tpsp: true,
            mixed_precision: false,
        }
    }

    pub fn npu_count(self) -> u32 {
        self.dp * self.tp * self.sp * self.ep * self.pp
    }
}

#[derive(Clone, Debug)]
pub struct E2eWorkload {
    pub name: String,
    pub display_name: String,
    pub trace_prefix: PathBuf,
    pub comm_group_path: PathBuf,
    pub npu_count: u32,
}

#[derive(Clone, Debug)]
pub struct MicroWorkload {
    pub collective: Collective,
    pub size_bytes: u64,
}

impl MicroWorkload {
    pub fn new(collective: Collective, size_bytes: u64) -> Self {
        Self {
            collective,
            size_bytes,
        }
    }

    pub fn to_id(&self) -> String {
        format!("{}-{}", self.collective.as_ref(), self.size_bytes)
    }
}

#[derive(Clone, Debug)]
pub enum Workload {
    Micro(MicroWorkload),
    E2e(E2eWorkload),
}

impl Workload {
    pub fn micro(collective: Collective, size_bytes: u64) -> Self {
        Self::Micro(MicroWorkload::new(collective, size_bytes))
    }

    pub fn to_id(&self) -> String {
        match self {
            Self::Micro(workload) => workload.to_id(),
            Self::E2e(workload) => format!("e2e_{}", workload.name),
        }
    }
}
