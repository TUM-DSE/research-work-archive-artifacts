pub mod astrasim;
pub mod bench;
pub(crate) mod common;
pub(crate) mod di;
pub mod estimate;
pub mod export;
pub mod schema;

use clap::{Parser, Subcommand};
use color_eyre::eyre::Result;

#[derive(Parser, Debug)]
#[command(name = "gnio", about = "GPU network IO benchmarks and analysis")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,
}

#[derive(Subcommand, Debug)]
pub enum Commands {
    #[command(name = "astra-sim")]
    AstraSim(astrasim::AstraSimArgs),
    Bench(bench::BenchArgs),
    Estimate(estimate::EstimateArgs),
    Export(export::ExportArgs),
    Schema(schema::SchemaArgs),
}

pub fn run() -> Result<()> {
    color_eyre::config::HookBuilder::default()
        .display_location_section(false)
        .display_env_section(false)
        .install()?;
    match Cli::parse().command {
        Commands::AstraSim(args) => astrasim::run(args),
        Commands::Bench(args) => bench::run(args),
        Commands::Estimate(args) => estimate::run(args),
        Commands::Export(args) => export::run(args),
        Commands::Schema(args) => schema::run(args),
    }
}
