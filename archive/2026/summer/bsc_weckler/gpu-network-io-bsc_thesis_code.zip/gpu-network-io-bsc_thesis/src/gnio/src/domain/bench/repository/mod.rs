use color_eyre::eyre::Result;

use crate::domain::bench::model::perftest::{PerftestMeasurement, RunConfig};
use crate::domain::shared_kernel::model::Bandwidth;

pub trait PerftestRunner: Send + Sync {
    fn run(&self, config: &RunConfig) -> Result<Vec<PerftestMeasurement>>;
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NvbandwidthKind {
    DeviceLocal,
    DeviceToHost,
    HostToDevice,
}

pub trait NvbandwidthRunner: Send + Sync {
    fn run(&self, kind: NvbandwidthKind, size_bytes: u64, samples: u32) -> Result<Bandwidth>;
}
