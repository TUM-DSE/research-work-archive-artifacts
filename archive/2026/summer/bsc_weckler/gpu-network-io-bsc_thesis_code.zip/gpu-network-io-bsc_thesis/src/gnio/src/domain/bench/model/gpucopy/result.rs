use std::time::Duration;

use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::domain::shared_kernel::model::{
    serde_bandwidth_mibps, serde_latency_us, Bandwidth, DatasetIdentity, DatasetRecord, Latency,
    Record,
};
use crate::libs::schema::Describe;

use super::{LatComponent, Mode, RunConfig};

pub const RESULTS_DIR: &str = "benchmarks/gpu_copy/results";

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct BwMeasurement {
    #[col(label = "Mode")]
    pub mode: Mode,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[col(label = "Iterations", role = metadata)]
    pub iters: u64,
    #[serde(rename = "bw_peak_mibps", with = "serde_bandwidth_mibps")]
    #[col(label = "Bandwidth (peak)")]
    pub bw_peak: Bandwidth,
    #[serde(rename = "bw_avg_mibps", with = "serde_bandwidth_mibps")]
    #[col(label = "Bandwidth (avg)")]
    pub bw_avg: Bandwidth,
    #[col(label = "Message rate", unit = "Mpps", better = higher)]
    pub msg_rate_mpps: f64,
    #[col(label = "Recorded (UTC)", role = metadata, ty = datetime)]
    pub utc_time: String,
}

impl DatasetRecord for BwMeasurement {
    const IDENTITY: DatasetIdentity =
        DatasetIdentity::new("gpucopy", RESULTS_DIR, "bw", "GPU Copy Bandwidth");
}

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct LatMeasurement {
    #[col(label = "Mode")]
    pub mode: Mode,
    #[serde(default)]
    #[col(label = "Component")]
    pub component: LatComponent,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[col(label = "Iterations", role = metadata)]
    pub iters: u64,
    #[serde(rename = "lat_min_us", with = "serde_latency_us")]
    #[col(label = "Latency (min)")]
    pub lat_min: Latency,
    #[serde(rename = "lat_max_us", with = "serde_latency_us")]
    #[col(label = "Latency (max)")]
    pub lat_max: Latency,
    #[serde(rename = "lat_typical_us", with = "serde_latency_us")]
    #[col(label = "Latency (typical)")]
    pub lat_typical: Latency,
    #[serde(rename = "lat_avg_us", with = "serde_latency_us")]
    #[col(label = "Latency (avg)")]
    pub lat_avg: Latency,
    #[serde(rename = "lat_stdev_us", with = "serde_latency_us")]
    #[col(label = "Latency (stdev)")]
    pub lat_stdev: Latency,
    #[serde(rename = "lat_p99_us", with = "serde_latency_us")]
    #[col(label = "Latency (p99)")]
    pub lat_p99: Latency,
    #[serde(rename = "lat_p999_us", with = "serde_latency_us")]
    #[col(label = "Latency (p99.9)")]
    pub lat_p999: Latency,
    #[col(label = "Recorded (UTC)", role = metadata, ty = datetime)]
    pub utc_time: String,
}

impl DatasetRecord for LatMeasurement {
    const IDENTITY: DatasetIdentity =
        DatasetIdentity::new("gpucopy", RESULTS_DIR, "lat", "GPU Copy Latency");

    fn baseline() -> Option<serde_json::Value> {
        Some(json!({ "component": LatComponent::Total }))
    }
}

#[derive(Clone, Debug)]
pub enum GpuCopyMeasurement {
    Bw(BwMeasurement),
    Lat(LatMeasurement),
}

impl GpuCopyMeasurement {
    pub fn bw(bw: BwMeasurement) -> Self {
        Self::Bw(bw)
    }

    pub fn lat(lat: LatMeasurement) -> Self {
        Self::Lat(lat)
    }
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct BwKey {
    pub mode: Mode,
    pub size_bytes: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct LatKey {
    pub mode: Mode,
    pub component: LatComponent,
    pub size_bytes: u64,
}

impl Record for BwMeasurement {
    type Key = BwKey;

    fn key(&self) -> Self::Key {
        BwKey {
            mode: self.mode,
            size_bytes: self.size_bytes,
        }
    }
}

impl Record for LatMeasurement {
    type Key = LatKey;

    fn key(&self) -> Self::Key {
        LatKey {
            mode: self.mode,
            component: self.component,
            size_bytes: self.size_bytes,
        }
    }
}

impl BwMeasurement {
    pub fn from_bandwidth(config: &RunConfig, bw: Bandwidth) -> Self {
        let size = config.size_bytes as f64;
        let msg_rate_mpps = if size > 0.0 {
            bw.as_bytes_per_sec() / size / 1e6
        } else {
            0.0
        };
        Self {
            mode: config.mode,
            size_bytes: config.size_bytes,
            iters: config.iters,
            bw_peak: bw,
            bw_avg: bw,
            msg_rate_mpps,
            utc_time: now_utc(),
        }
    }

    pub fn from_rounds(config: &RunConfig, iters: u64, rounds: &[Duration]) -> Self {
        let bytes_per_round = config.size_bytes as f64 * iters as f64;
        let secs: Vec<f64> = rounds.iter().map(Duration::as_secs_f64).collect();
        let fastest = secs.iter().copied().fold(f64::INFINITY, f64::min);
        let total: f64 = secs.iter().sum();
        let n = rounds.len() as f64;
        let peak = if fastest.is_finite() && fastest > 0.0 {
            bytes_per_round / fastest
        } else {
            0.0
        };
        let avg = if total > 0.0 {
            bytes_per_round * n / total
        } else {
            0.0
        };
        Self {
            mode: config.mode,
            size_bytes: config.size_bytes,
            iters,
            bw_peak: Bandwidth::from_bps(peak),
            bw_avg: Bandwidth::from_bps(avg),
            msg_rate_mpps: if total > 0.0 {
                (iters as f64 * n / total) / 1e6
            } else {
                0.0
            },
            utc_time: now_utc(),
        }
    }
}

impl LatMeasurement {
    pub fn from_samples(config: &RunConfig, samples: &[Duration]) -> Self {
        Self::from_component_samples(config, LatComponent::Total, samples)
    }

    pub fn from_component_samples(
        config: &RunConfig,
        component: LatComponent,
        samples: &[Duration],
    ) -> Self {
        let mut secs: Vec<f64> = samples.iter().map(Duration::as_secs_f64).collect();
        secs.sort_by(f64::total_cmp);
        let n = secs.len();
        let avg = if n > 0 {
            secs.iter().sum::<f64>() / n as f64
        } else {
            0.0
        };
        let variance = if n > 0 {
            secs.iter().map(|x| (x - avg).powi(2)).sum::<f64>() / n as f64
        } else {
            0.0
        };
        Self {
            mode: config.mode,
            component,
            size_bytes: config.size_bytes,
            iters: n as u64,
            lat_min: Latency::from_secs(secs.first().copied().unwrap_or(0.0)),
            lat_max: Latency::from_secs(secs.last().copied().unwrap_or(0.0)),
            lat_typical: Latency::from_secs(percentile(&secs, 0.5)),
            lat_avg: Latency::from_secs(avg),
            lat_stdev: Latency::from_secs(variance.sqrt()),
            lat_p99: Latency::from_secs(percentile(&secs, 0.99)),
            lat_p999: Latency::from_secs(percentile(&secs, 0.999)),
            utc_time: now_utc(),
        }
    }
}

fn percentile(sorted: &[f64], q: f64) -> f64 {
    if sorted.is_empty() {
        return 0.0;
    }
    let idx = (q * (sorted.len() - 1) as f64).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn now_utc() -> String {
    Utc::now().format("%Y-%m-%dT%H:%M:%SZ").to_string()
}
