use std::collections::BTreeMap;
use std::fmt;
use std::path::Path;

use color_eyre::eyre::{bail, Result};
use serde::Serialize;

use crate::libs::fs;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum ColumnType {
    String,
    Integer,
    Float,
    DateTime,
    Bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Role {
    Dimension,
    Measure,
    Metadata,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Better {
    Higher,
    Lower,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum StyleToken {
    PathGpuDirect,
    PathCpuBounce,
    PathDesign1,
    PathDesign2,
    PathSealedBounce,
    PathVmGpuBounce,
    PathHostRam,
    VariantSingle,
    VariantE2e,
    VariantVm,
    VariantCvm,
    SourceMeasured,
    SourceModeled,
    SourceProxy,
    AlgorithmRing,
    AlgorithmDirect,
    AlgorithmHalvingDoubling,
    AlgorithmDoubleBinaryTree,
    CopyCuda,
    CopyCe,
    CopyNvbandwidth,
    CopyCprNonCpr,
    CopyEnvVm,
    CopyEnvCvm,
    ComponentTotal,
    ComponentCrypto,
    ComponentCommand,
    ComponentCopy,
}

#[derive(Clone, Debug, Serialize)]
pub struct ValueMeta {
    pub value: String,
    pub label: String,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub style: Vec<StyleToken>,
}

impl ValueMeta {
    pub fn new(value: impl Into<String>, label: impl Into<String>) -> Self {
        Self {
            value: value.into(),
            label: label.into(),
            style: Vec::new(),
        }
    }

    pub fn styles(mut self, styles: &'static [StyleToken]) -> Self {
        self.style = styles.to_vec();
        self
    }
}

#[derive(Clone, Debug, Serialize)]
pub struct ColumnMeta {
    pub name: String,
    #[serde(rename = "type")]
    pub ty: ColumnType,
    pub role: Role,
    pub label: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub unit: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub better: Option<Better>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub values: Option<Vec<ValueMeta>>,
}

impl ColumnMeta {
    pub fn of<T: ColumnSchema>(name: &str, label: &str) -> Self {
        Self {
            name: name.into(),
            ty: T::column_type(),
            role: T::default_role(),
            label: label.into(),
            unit: T::unit().map(Into::into),
            better: T::better(),
            values: T::values(),
        }
    }
}

// Schema metadata carried by a column's Rust type; field-level `#[col(...)]` overrides win.
pub trait ColumnSchema {
    fn column_type() -> ColumnType;
    fn unit() -> Option<&'static str> {
        None
    }
    fn default_role() -> Role {
        Role::Dimension
    }
    fn better() -> Option<Better> {
        None
    }
    fn values() -> Option<Vec<ValueMeta>> {
        None
    }
}

impl ColumnSchema for String {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
}

impl ColumnSchema for bool {
    fn column_type() -> ColumnType {
        ColumnType::Bool
    }
}

impl ColumnSchema for f64 {
    fn column_type() -> ColumnType {
        ColumnType::Float
    }
    fn default_role() -> Role {
        Role::Measure
    }
}

macro_rules! impl_integer_schema {
    ($($t:ty),+ $(,)?) => {
        $(
            impl ColumnSchema for $t {
                fn column_type() -> ColumnType {
                    ColumnType::Integer
                }
            }
        )+
    };
}

impl_integer_schema!(u16, u32, u64, usize, i32, i64);

pub use gnio_derive::Describe;

pub trait Describe {
    fn columns() -> Vec<ColumnMeta>;
}

pub fn values_of<T>(all: &[T]) -> Vec<ValueMeta>
where
    T: Copy + AsRef<str> + fmt::Display,
{
    all.iter()
        .map(|&v| ValueMeta::new(v.as_ref(), v.to_string()))
        .collect()
}

pub fn styled_values_of<T>(all: &[T], styles: impl Fn(T) -> &'static [StyleToken]) -> Vec<ValueMeta>
where
    T: Copy + AsRef<str> + fmt::Display,
{
    all.iter()
        .map(|&v| ValueMeta::new(v.as_ref(), v.to_string()).styles(styles(v)))
        .collect()
}

#[derive(Clone, Debug, Serialize)]
pub struct DatasetMeta {
    pub title: String,
    pub path: String,
    pub key: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub baseline_filter: Option<serde_json::Value>,
    pub columns: Vec<ColumnMeta>,
}

impl DatasetMeta {
    // The dedup key of tidy benchmark data is exactly its dimension columns.
    pub fn of<R: Describe>(title: &str, path: String) -> Self {
        let columns = R::columns();
        let key = columns
            .iter()
            .filter(|c| c.role == Role::Dimension)
            .map(|c| c.name.clone())
            .collect();
        Self {
            title: title.into(),
            path,
            key,
            baseline_filter: None,
            columns,
        }
    }

    pub fn baseline(mut self, filter: serde_json::Value) -> Self {
        self.baseline_filter = Some(filter);
        self
    }

    pub fn values(mut self, sets: Vec<(&str, Vec<ValueMeta>)>) -> Self {
        for (column, values) in sets {
            self.columns
                .iter_mut()
                .find(|c| c.name == column)
                .unwrap_or_else(|| panic!("values: no column '{column}'"))
                .values = Some(values);
        }
        self
    }

    fn validate(&self, id: &str) -> Result<()> {
        let names: Vec<&str> = self.columns.iter().map(|c| c.name.as_str()).collect();
        for (i, name) in names.iter().enumerate() {
            if names[..i].contains(name) {
                bail!("dataset '{id}': duplicate column '{name}'");
            }
        }
        for key in &self.key {
            if !names.contains(&key.as_str()) {
                bail!("dataset '{id}': key column '{key}' not in columns");
            }
        }
        Ok(())
    }
}

#[derive(Debug, Serialize)]
pub struct SchemaDoc {
    pub version: u32,
    pub generated_by: String,
    pub datasets: BTreeMap<String, DatasetMeta>,
}

impl SchemaDoc {
    pub fn new(
        generated_by: String,
        datasets: impl IntoIterator<Item = (String, DatasetMeta)>,
    ) -> Result<Self> {
        let mut map = BTreeMap::new();
        for (id, dataset) in datasets {
            dataset.validate(&id)?;
            if map.insert(id.clone(), dataset).is_some() {
                bail!("duplicate dataset id '{id}'");
            }
        }
        Ok(Self {
            version: 2,
            generated_by,
            datasets: map,
        })
    }

    pub fn render(&self) -> Result<Vec<u8>> {
        let mut bytes = serde_json::to_vec_pretty(self)?;
        bytes.push(b'\n');
        Ok(bytes)
    }

    pub fn write(&self, path: &Path) -> Result<()> {
        fs::atomic_write(path, &self.render()?)
    }
}
