mod args;

pub use args::{ExportArgs, ExportCommand};

use color_eyre::eyre::Result;

use crate::cli::di;
pub fn run(args: ExportArgs) -> Result<()> {
    match args.command {
        ExportCommand::Thesis(args) => {
            let output = if args.output.is_absolute() {
                args.output
            } else {
                di::results_dir("").join(args.output)
            };
            di::thesis_export(output.clone()).export()?;
            eprintln!("wrote {}", output.display());
            Ok(())
        }
    }
}
