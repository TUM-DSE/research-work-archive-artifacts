mod application;

pub use application::ThesisApplication;
