use std::path::PathBuf;

use clap::Args;
use color_eyre::eyre::{bail, ContextCompat, Result, WrapErr};

use crate::domain::astrasim::model::{E2eRow, MicroRow};
use crate::domain::bench::model::{gpucopy, perftest, EstimatedBwRow, EstimatedLatRow};
use crate::domain::shared_kernel::model::DatasetRecord;
use crate::libs::{fs, schema::SchemaDoc};

#[derive(Args, Debug)]
pub struct SchemaArgs {
    /// Output path (default: <repo>/plots/schema.json)
    #[arg(long)]
    pub out: Option<PathBuf>,

    /// Verify the file on disk matches the code instead of writing
    #[arg(long)]
    pub check: bool,
}

pub fn run(args: SchemaArgs) -> Result<()> {
    let doc = document()?;
    let path = match args.out {
        Some(path) => path,
        None => default_path()?,
    };
    if args.check {
        return check(&doc, &path);
    }
    doc.write(&path)?;
    println!("wrote {} ({} datasets)", path.display(), doc.datasets.len());
    Ok(())
}

pub fn document() -> Result<SchemaDoc> {
    SchemaDoc::new(
        format!("gnio {}", env!("CARGO_PKG_VERSION")),
        [
            perftest::BwMeasurement::dataset_meta(),
            perftest::LatMeasurement::dataset_meta(),
            gpucopy::BwMeasurement::dataset_meta(),
            gpucopy::LatMeasurement::dataset_meta(),
            EstimatedBwRow::dataset_meta(),
            EstimatedLatRow::dataset_meta(),
            MicroRow::dataset_meta(),
            E2eRow::dataset_meta(),
        ],
    )
}

fn check(doc: &SchemaDoc, path: &std::path::Path) -> Result<()> {
    let on_disk = std::fs::read(path).wrap_err_with(|| format!("read {}", path.display()))?;
    if on_disk != doc.render()? {
        bail!("{} is stale — run `gnio schema`", path.display());
    }
    println!("{} is up to date", path.display());
    Ok(())
}

fn default_path() -> Result<PathBuf> {
    let root = fs::repo_root().context("repo root not found (no flake.nix upwards); pass --out")?;
    Ok(root.join("plots/schema.json"))
}
