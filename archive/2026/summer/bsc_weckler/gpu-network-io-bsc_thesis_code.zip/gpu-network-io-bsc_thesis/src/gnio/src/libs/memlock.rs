use std::process::Command;

pub fn raise() {
    unsafe {
        let mut lim = libc::rlimit {
            rlim_cur: 0,
            rlim_max: 0,
        };
        if libc::getrlimit(libc::RLIMIT_MEMLOCK, &mut lim) != 0 {
            return;
        }
        if lim.rlim_max != libc::RLIM_INFINITY {
            let pid = std::process::id();
            let _ = Command::new("sudo")
                .args([
                    "prlimit",
                    &format!("--pid={pid}"),
                    "--memlock=unlimited:unlimited",
                ])
                .status();
            if libc::getrlimit(libc::RLIMIT_MEMLOCK, &mut lim) != 0 {
                return;
            }
        }
        lim.rlim_cur = lim.rlim_max;
        let _ = libc::setrlimit(libc::RLIMIT_MEMLOCK, &lim);
    }
}
