use std::collections::HashSet;

use color_eyre::eyre::{bail, Result};

use crate::domain::astrasim::repository::{ResultParser, RunOutcome};

pub struct ResultParserImpl;

fn max_finish_cycles(stdout: &str) -> Option<f64> {
    let mut best: Option<f64> = None;
    for line in stdout.lines() {
        let lower = line.to_ascii_lowercase();
        if !lower.contains("finished") {
            continue;
        }
        let tail = &lower[lower.find("finished").unwrap()..];
        let num: String = tail
            .chars()
            .skip_while(|c| !c.is_ascii_digit())
            .take_while(|c| c.is_ascii_digit() || *c == '.')
            .collect();
        if let Ok(v) = num.parse::<f64>() {
            best = Some(best.map_or(v, |b| b.max(v)));
        }
    }
    best
}

pub(super) fn finished_ranks(stdout: &str) -> HashSet<u32> {
    stdout
        .lines()
        .filter_map(|line| {
            let rank = line.split_once("sys[")?.1;
            let (rank, suffix) = rank.split_once(']')?;
            suffix
                .trim_start()
                .starts_with("finished,")
                .then(|| rank.parse().ok())?
        })
        .collect()
}

pub(super) fn all_ranks_finished(stdout: &str, npus: u32) -> bool {
    let ranks = finished_ranks(stdout);
    ranks.len() == npus as usize && (0..npus).all(|rank| ranks.contains(&rank))
}

pub(super) fn has_simulator_error(stdout: &str) -> bool {
    stdout.lines().any(|line| {
        let lower = line.to_ascii_lowercase();
        lower.contains("[critical]") || lower.contains("[error]")
    })
}

impl ResultParser for ResultParserImpl {
    fn parse(&self, outcome: &RunOutcome) -> Result<f64> {
        match max_finish_cycles(&outcome.stdout) {
            Some(cycles) => Ok(cycles / 1e3),
            None => bail!(
                "no `sys[<rank>] finished, <n> cycles` lines found in ASTRA-sim output for {}",
                outcome.dir.display()
            ),
        }
    }
}
