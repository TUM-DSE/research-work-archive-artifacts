use std::net::IpAddr;

use clap::{Args, ValueEnum};
use color_eyre::eyre::{bail, Result, WrapErr};

use crate::cli::common;
use crate::domain::bench::model::{
    perftest::{Mode, NetworkSecurity, Operation, PerftestPlan, Role},
    FIXED_LATENCY_SIZE_BYTES,
};
use crate::domain::shared_kernel::model::{Direction, MetricKind, QpCount, Verb};

const KIB: u64 = 1 << 10;
const MIB: u64 = 1 << 20;

const DEFAULT_SIZES: &[u64] = &[
    FIXED_LATENCY_SIZE_BYTES,
    256,
    512,
    KIB,
    2 * KIB,
    4 * KIB,
    8 * KIB,
    16 * KIB,
    32 * KIB,
    64 * KIB,
    128 * KIB,
    256 * KIB,
    512 * KIB,
    MIB,
    2 * MIB,
];

#[derive(Args, Debug)]
pub struct PerfArgs {
    #[arg(value_enum)]
    pub role: RoleArg,

    #[arg(short, long, value_delimiter = ',', required = true, value_parser = common::possible_value_parser(&Mode::ALL))]
    pub mode: Vec<Mode>,

    #[arg(short, long, value_delimiter = ',')]
    pub operation: Vec<OperationArg>,

    #[arg(short, long, value_delimiter = ',')]
    pub size: Vec<u64>,

    #[arg(short = 'n', long, default_value_t = 5000)]
    pub iters: u64,

    #[arg(short, long, value_delimiter = ',')]
    pub qps: Vec<u32>,

    #[arg(short, long)]
    pub bidirectional: bool,

    #[arg(short = 'd', long)]
    pub data_validation: bool,

    #[arg(short = 'H', long, default_value = "ian")]
    pub host: String,

    #[arg(short, long)]
    pub log: bool,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum RoleArg {
    Server,
    Client,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum OperationArg {
    #[value(name = "bw-read")]
    BwRead,
    #[value(name = "bw-write")]
    BwWrite,
    #[value(name = "bw-write-imm")]
    BwWriteImm,
    #[value(name = "lat-read")]
    LatRead,
    #[value(name = "lat-write")]
    LatWrite,
    #[value(name = "lat-write-imm")]
    LatWriteImm,
}

impl OperationArg {
    fn parts(self) -> (MetricKind, Verb) {
        match self {
            OperationArg::BwRead => (MetricKind::Bw, Verb::Read),
            OperationArg::BwWrite => (MetricKind::Bw, Verb::Write),
            OperationArg::BwWriteImm => (MetricKind::Bw, Verb::WriteImm),
            OperationArg::LatRead => (MetricKind::Lat, Verb::Read),
            OperationArg::LatWrite => (MetricKind::Lat, Verb::Write),
            OperationArg::LatWriteImm => (MetricKind::Lat, Verb::WriteImm),
        }
    }
}

impl PerfArgs {
    pub fn role(&self) -> Result<Role> {
        Ok(match self.role {
            RoleArg::Server => Role::Server,
            RoleArg::Client => Role::Client {
                server_ip: resolve_host(&self.host)?,
            },
        })
    }

    pub fn persist(&self) -> bool {
        self.log
    }

    pub fn plan(&self, role: Role) -> PerftestPlan {
        PerftestPlan {
            operations: self.operations(),
            modes: self.modes(),
            security: NetworkSecurity::None,
            sizes: self.sizes(),
            iters: self.iters,
            role,
        }
    }

    fn operations(&self) -> Vec<Operation> {
        let qps = self.qps_list();
        let directions = self.directions();
        self.op_parts()
            .into_iter()
            .map(|(kind, verb)| match kind {
                MetricKind::Bw => Operation::Bw {
                    verb,
                    qps: qps.clone(),
                    directions: directions.clone(),
                    data_validation: self.data_validation,
                },
                MetricKind::Lat => Operation::Lat { verb },
            })
            .collect()
    }

    fn op_parts(&self) -> Vec<(MetricKind, Verb)> {
        if self.operation.is_empty() {
            vec![
                (MetricKind::Bw, Verb::Read),
                (MetricKind::Bw, Verb::Write),
                (MetricKind::Bw, Verb::WriteImm),
                (MetricKind::Lat, Verb::Read),
                (MetricKind::Lat, Verb::Write),
                (MetricKind::Lat, Verb::WriteImm),
            ]
        } else {
            self.operation.iter().map(|o| o.parts()).collect()
        }
    }

    fn qps_list(&self) -> Vec<QpCount> {
        if self.qps.is_empty() {
            vec![QpCount(1)]
        } else {
            self.qps.iter().map(|&q| QpCount(q)).collect()
        }
    }

    fn directions(&self) -> Vec<Direction> {
        if self.bidirectional {
            vec![Direction::Bidir]
        } else {
            vec![Direction::Uni]
        }
    }

    fn modes(&self) -> Vec<Mode> {
        self.mode.clone()
    }

    fn sizes(&self) -> Vec<u64> {
        if self.size.is_empty() {
            DEFAULT_SIZES.to_vec()
        } else {
            self.size.clone()
        }
    }
}

fn resolve_host(name: &str) -> Result<IpAddr> {
    let sub = unsafe { libc::getuid() } % 1000;
    let ip = match name {
        "cvm" | "vm" => format!("10.254.{sub}.10"),
        "jamie" => "10.254.221.31".to_string(),
        "ian" => "10.254.200.175".to_string(),
        other => bail!("unknown host '{other}'"),
    };
    ip.parse::<IpAddr>()
        .wrap_err_with(|| format!("parse host ip '{ip}'"))
}
