use std::fmt;

use serde::{Deserialize, Serialize};
use strum::{AsRefStr, EnumString};

use crate::domain::bench::model::estimator::{CostModel, EstimationMode};
use crate::domain::bench::model::CurvePair;
use crate::domain::shared_kernel::model::{
    serde_bandwidth_mibps, serde_latency_us, Bandwidth, DatasetIdentity, DatasetRecord, Latency,
    Record,
};
use crate::libs::id::serde_id;
use crate::libs::schema::{
    styled_values_of, ColumnSchema, ColumnType, Describe, StyleToken, ValueMeta,
};

pub const RESULTS_DIR: &str = "benchmarks/estimate/results";

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum Source {
    Measured,
    Estimated,
}

impl Source {
    pub const ALL: [Source; 2] = [Source::Measured, Source::Estimated];

    const fn style(self) -> &'static [StyleToken] {
        match self {
            Source::Measured => &[StyleToken::SourceMeasured],
            Source::Estimated => &[StyleToken::SourceModeled],
        }
    }
}

impl fmt::Display for Source {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Source::Measured => "Measured",
            Source::Estimated => "Estimated",
        })
    }
}

serde_id!(Source);

impl ColumnSchema for Source {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(styled_values_of(&Source::ALL, Source::style))
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct EstimatedBwRow {
    #[col(label = "Estimation mode")]
    pub mode: EstimationMode,
    #[col(label = "Source")]
    pub source: Source,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[serde(rename = "bw_avg_mibps", with = "serde_bandwidth_mibps")]
    #[col(label = "Bandwidth (avg)")]
    pub bw_avg: Bandwidth,
}

impl DatasetRecord for EstimatedBwRow {
    const IDENTITY: DatasetIdentity = DatasetIdentity::new(
        "estimate",
        RESULTS_DIR,
        "bw",
        "Estimated vs Measured Bandwidth",
    );
}

#[derive(Clone, Debug, Serialize, Deserialize, Describe)]
pub struct EstimatedLatRow {
    #[col(label = "Estimation mode")]
    pub mode: EstimationMode,
    #[col(label = "Source")]
    pub source: Source,
    #[col(label = "Message size", unit = "bytes")]
    pub size_bytes: u64,
    #[serde(rename = "lat_avg_us", with = "serde_latency_us")]
    #[col(label = "Latency (avg)")]
    pub lat_avg: Latency,
}

impl DatasetRecord for EstimatedLatRow {
    const IDENTITY: DatasetIdentity = DatasetIdentity::new(
        "estimate",
        RESULTS_DIR,
        "lat",
        "Estimated vs Measured Latency",
    );
}

impl Record for EstimatedBwRow {
    type Key = (EstimationMode, Source, u64);
    fn key(&self) -> Self::Key {
        (self.mode, self.source, self.size_bytes)
    }
}

impl Record for EstimatedLatRow {
    type Key = (EstimationMode, Source, u64);
    fn key(&self) -> Self::Key {
        (self.mode, self.source, self.size_bytes)
    }
}

pub struct EstimatedCurve {
    pub bw: Vec<EstimatedBwRow>,
    pub lat: Vec<EstimatedLatRow>,
}

impl EstimatedCurve {
    // the estimated cost/bandwidth curve, sampled across message sizes
    pub fn predict(mode: EstimationMode, model: &dyn CostModel) -> Self {
        let mut bw = Vec::new();
        let mut lat = Vec::new();
        for n in (0u32..=29).map(|p| 1u64 << p) {
            let nf = n as f64;
            bw.push(EstimatedBwRow {
                mode,
                source: Source::Estimated,
                size_bytes: n,
                bw_avg: model.bandwidth(nf),
            });
            lat.push(EstimatedLatRow {
                mode,
                source: Source::Estimated,
                size_bytes: n,
                lat_avg: model.cost(nf),
            });
        }
        Self { bw, lat }
    }

    // the measured ground-truth curve this mode is validated against, logged under
    // the same mode so plots read estimated vs measured from one file
    pub fn from_measured(mode: EstimationMode, measured: &CurvePair) -> Self {
        let bw = measured
            .bw
            .avg()
            .into_iter()
            .map(|(size_bytes, bw_avg)| EstimatedBwRow {
                mode,
                source: Source::Measured,
                size_bytes,
                bw_avg,
            })
            .collect();
        let lat = measured
            .lat
            .avg()
            .into_iter()
            .map(|(size_bytes, lat_avg)| EstimatedLatRow {
                mode,
                source: Source::Measured,
                size_bytes,
                lat_avg,
            })
            .collect();
        Self { bw, lat }
    }
}
