use std::ffi::CStr;
use std::os::raw::{c_char, c_int, c_uint, c_void};
use std::ptr::{null, null_mut};

use color_eyre::eyre::{bail, Result};

use super::{GpuBuffer, GpuCopy, GpuDeviceCopy};

type CUresult = c_int;
type CUdevice = c_int;
type CUcontext = *mut c_void;
type CUstream = *mut c_void;
type CUdeviceptr = u64;

extern "C" {
    fn cuInit(flags: c_uint) -> CUresult;
    fn cuDeviceGet(device: *mut CUdevice, ordinal: c_int) -> CUresult;
    fn cuCtxCreate_v2(pctx: *mut CUcontext, flags: c_uint, dev: CUdevice) -> CUresult;
    fn cuCtxDestroy_v2(ctx: CUcontext) -> CUresult;
    fn cuMemAlloc_v2(dptr: *mut CUdeviceptr, bytesize: usize) -> CUresult;
    fn cuMemAllocHost_v2(pp: *mut *mut c_void, bytesize: usize) -> CUresult;
    fn cuMemFree_v2(dptr: CUdeviceptr) -> CUresult;
    fn cuMemFreeHost(p: *mut c_void) -> CUresult;
    fn cuStreamCreate(ph_stream: *mut CUstream, flags: c_uint) -> CUresult;
    fn cuStreamDestroy_v2(h_stream: CUstream) -> CUresult;
    fn cuStreamSynchronize(h_stream: CUstream) -> CUresult;
    fn cuMemcpyHtoD_v2(dst: CUdeviceptr, src: *const c_void, byte_count: usize) -> CUresult;
    fn cuMemcpyDtoH_v2(dst: *mut c_void, src: CUdeviceptr, byte_count: usize) -> CUresult;
    fn cuMemcpyDtoDAsync_v2(
        dst: CUdeviceptr,
        src: CUdeviceptr,
        byte_count: usize,
        h_stream: CUstream,
    ) -> CUresult;
    fn cuGetErrorString(error: CUresult, p_str: *mut *const c_char) -> CUresult;
}

fn check(res: CUresult, what: &str) -> Result<()> {
    if res == 0 {
        return Ok(());
    }
    let mut s: *const c_char = null();
    unsafe { cuGetErrorString(res, &mut s) };
    let detail = if s.is_null() {
        String::new()
    } else {
        unsafe { CStr::from_ptr(s) }.to_string_lossy().into_owned()
    };
    bail!("{what} failed: CUresult {res} ({detail})")
}

enum Mem {
    Device(CUdeviceptr),
    Host(*mut c_void),
}

pub struct CudaDevice {
    ctx: CUcontext,
    stream: CUstream,
}

pub struct Buffer {
    mem: Mem,
    len: usize,
}

impl GpuCopy for CudaDevice {
    type Buffer = Buffer;

    fn open(index: u32) -> Result<Self> {
        check(unsafe { cuInit(0) }, "cuInit")?;
        let mut dev: CUdevice = 0;
        check(
            unsafe { cuDeviceGet(&mut dev, index as c_int) },
            "cuDeviceGet",
        )?;
        let mut ctx: CUcontext = null_mut();
        check(unsafe { cuCtxCreate_v2(&mut ctx, 0, dev) }, "cuCtxCreate")?;
        let mut stream: CUstream = null_mut();
        check(unsafe { cuStreamCreate(&mut stream, 0) }, "cuStreamCreate")?;
        Ok(CudaDevice { ctx, stream })
    }

    fn alloc_device(&self, size: usize) -> Result<Buffer> {
        let mut dptr: CUdeviceptr = 0;
        check(unsafe { cuMemAlloc_v2(&mut dptr, size) }, "cuMemAlloc")?;
        Ok(Buffer {
            mem: Mem::Device(dptr),
            len: size,
        })
    }

    fn alloc_host(&self, size: usize) -> Result<Buffer> {
        let mut ptr: *mut c_void = null_mut();
        check(
            unsafe { cuMemAllocHost_v2(&mut ptr, size) },
            "cuMemAllocHost",
        )?;
        Ok(Buffer {
            mem: Mem::Host(ptr),
            len: size,
        })
    }

    fn copy_h_to_d(&self, dst: &Buffer, src: &Buffer, size: usize) -> Result<()> {
        let (Mem::Device(d), Mem::Host(s)) = (&dst.mem, &src.mem) else {
            bail!("copy_h_to_d expects a device dst and a host src");
        };
        check(
            unsafe { cuMemcpyHtoD_v2(*d, *s as *const c_void, size) },
            "cuMemcpyHtoD",
        )
    }

    fn copy_d_to_h(&self, dst: &Buffer, src: &Buffer, size: usize) -> Result<()> {
        let (Mem::Host(d), Mem::Device(s)) = (&dst.mem, &src.mem) else {
            bail!("copy_d_to_h expects a host dst and a device src");
        };
        check(unsafe { cuMemcpyDtoH_v2(*d, *s, size) }, "cuMemcpyDtoH")
    }
}

impl GpuDeviceCopy for CudaDevice {
    fn copy_d_to_d(&self, dst: &Buffer, src: &Buffer, size: usize) -> Result<()> {
        let (Mem::Device(d), Mem::Device(s)) = (&dst.mem, &src.mem) else {
            bail!("copy_d_to_d expects a device dst and a device src");
        };
        check(
            unsafe { cuMemcpyDtoDAsync_v2(*d, *s, size, self.stream) },
            "cuMemcpyDtoDAsync",
        )?;
        check(
            unsafe { cuStreamSynchronize(self.stream) },
            "cuStreamSynchronize",
        )
    }
}

impl GpuBuffer for Buffer {
    fn host_ptr(&self) -> Option<*mut u8> {
        match self.mem {
            Mem::Host(p) => Some(p as *mut u8),
            Mem::Device(_) => None,
        }
    }

    fn len(&self) -> usize {
        self.len
    }
}

impl Drop for CudaDevice {
    fn drop(&mut self) {
        unsafe {
            cuStreamDestroy_v2(self.stream);
            cuCtxDestroy_v2(self.ctx);
        };
    }
}

impl Drop for Buffer {
    fn drop(&mut self) {
        unsafe {
            match self.mem {
                Mem::Device(d) => cuMemFree_v2(d),
                Mem::Host(p) => cuMemFreeHost(p),
            }
        };
    }
}
