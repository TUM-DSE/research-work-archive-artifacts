use color_eyre::eyre::Result;

#[cfg(feature = "gpu")]
pub mod cuda;
#[cfg(feature = "gpu")]
pub mod uvmgpu;

pub fn detect_cc() -> bool {
    std::process::Command::new("nvidia-smi")
        .args(["conf-compute", "-f"])
        .output()
        .map(|o| o.status.success() && String::from_utf8_lossy(&o.stdout).contains("status: ON"))
        .unwrap_or(false)
}

pub trait GpuBuffer {
    fn host_ptr(&self) -> Option<*mut u8>;
    fn len(&self) -> usize;
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

pub trait GpuCopy: Sized {
    type Buffer: GpuBuffer;

    fn open(index: u32) -> Result<Self>;
    fn alloc_device(&self, size: usize) -> Result<Self::Buffer>;
    fn alloc_host(&self, size: usize) -> Result<Self::Buffer>;
    fn copy_h_to_d(&self, dst: &Self::Buffer, src: &Self::Buffer, size: usize) -> Result<()>;
    fn copy_d_to_h(&self, dst: &Self::Buffer, src: &Self::Buffer, size: usize) -> Result<()>;
}

pub trait GpuDeviceCopy: GpuCopy {
    fn copy_d_to_d(&self, dst: &Self::Buffer, src: &Self::Buffer, size: usize) -> Result<()>;
}

pub trait GpuSealedCopy: GpuCopy {
    fn copy_h_to_d_sealed(
        &self,
        dst: &Self::Buffer,
        src: &Self::Buffer,
        tag: &Self::Buffer,
        size: usize,
    ) -> Result<()>;
    fn copy_d_to_h_sealed(
        &self,
        dst: &Self::Buffer,
        tag: &Self::Buffer,
        src: &Self::Buffer,
        size: usize,
    ) -> Result<()>;
}
