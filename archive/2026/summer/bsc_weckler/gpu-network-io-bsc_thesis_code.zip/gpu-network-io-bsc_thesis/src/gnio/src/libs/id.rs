// Id enums (strum AsRefStr/EnumString) serialize as their id; `Display` stays the human label.
macro_rules! serde_id {
    ($ty:ty) => {
        impl serde::Serialize for $ty {
            fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
                serializer.serialize_str(self.as_ref())
            }
        }

        impl<'de> serde::Deserialize<'de> for $ty {
            fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
                String::deserialize(deserializer)?
                    .parse()
                    .map_err(|_| serde::de::Error::custom(concat!("unknown ", stringify!($ty))))
            }
        }
    };
}

pub(crate) use serde_id;
