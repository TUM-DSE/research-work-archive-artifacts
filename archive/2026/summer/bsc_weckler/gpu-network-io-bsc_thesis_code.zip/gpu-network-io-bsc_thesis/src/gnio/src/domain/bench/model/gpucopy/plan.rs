use super::{Mode, RunConfig};
use crate::domain::shared_kernel::model::MetricKind;

const ITER_TARGET_BYTES: u64 = 2 << 30;
const MIN_ITERS: u64 = 16;
const MAX_ITERS: u64 = 100;
const NVBW_LOCAL_SAMPLES: u64 = 3;
const NVBW_TRANSFER_SAMPLES: u64 = 1;

#[derive(Clone, Debug)]
pub struct GpuCopyPlan {
    pub kinds: Vec<MetricKind>,
    pub modes: Vec<Mode>,
    pub sizes: Vec<u64>,
    pub iters: Option<u64>,
}

impl GpuCopyPlan {
    pub fn expand(&self) -> Vec<RunConfig> {
        let mut out = Vec::new();
        for &kind in &self.kinds {
            for &mode in &self.modes {
                if !mode.supports_kind(kind) {
                    continue;
                }
                for &size in &self.sizes {
                    if !mode.supports_size(size) {
                        continue;
                    }

                    let iters = self.iters.unwrap_or_else(|| iters_for(mode, size));
                    out.push(RunConfig {
                        kind,
                        mode,
                        size_bytes: size,
                        iters,
                    });
                }
            }
        }
        out
    }
}

fn iters_for(mode: Mode, size: u64) -> u64 {
    if mode.is_nvbw() {
        nvbw_samples(mode)
    } else {
        iters_for_size(size)
    }
}

fn iters_for_size(size: u64) -> u64 {
    (ITER_TARGET_BYTES / size.max(1)).clamp(MIN_ITERS, MAX_ITERS)
}

fn nvbw_samples(mode: Mode) -> u64 {
    match mode {
        Mode::CvmNvbwCopyDtoD | Mode::VmNvbwCopyDtoD => NVBW_LOCAL_SAMPLES,
        _ => NVBW_TRANSFER_SAMPLES,
    }
}
