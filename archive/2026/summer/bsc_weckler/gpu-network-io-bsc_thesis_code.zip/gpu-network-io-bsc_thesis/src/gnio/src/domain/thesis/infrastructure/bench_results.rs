use color_eyre::eyre::Result;

use crate::domain::bench::model::CostModel;
use crate::domain::bench::presentation::EvaluationApplication;
use crate::domain::thesis::model::{
    CopyBandwidths, CpuBounceBandwidths, CpuBounceLatencies, DatapathResults, Design1Measurements,
    Design2Parameters, ErrorMetrics, FlowCompletion, PathModel,
};
use crate::domain::thesis::repository::DatapathResultsRepository;

pub struct BenchResultsRepository {
    application: Box<EvaluationApplication>,
}

impl BenchResultsRepository {
    pub fn new(application: Box<EvaluationApplication>) -> Self {
        Self { application }
    }
}

impl DatapathResultsRepository for BenchResultsRepository {
    fn load(&self) -> Result<DatapathResults> {
        let data = self.application.evaluate()?;
        let gdr = data.gdr.ab();
        let cpu_bounce_single = data.cpu_bounce.one_sided.ab();
        let cpu_bounce = data.cpu_bounce.end_to_end.ab();
        let design1_single = data.design1.one_sided.ab();
        let design1_e2e = data.design1.end_to_end.ab();
        let design2_e2e = data.design2.ab();

        let metrics = |metrics: crate::domain::bench::model::ErrorMetrics| ErrorMetrics {
            mape: metrics.mape,
            geomean: metrics.geomean,
            median: metrics.median,
            max: metrics.max,
            bias: metrics.bias,
        };

        Ok(DatapathResults {
            gpudirect: PathModel {
                latency: gdr.alpha,
                bandwidth: gdr.beta,
            },
            cpu_bounce_single: PathModel {
                latency: cpu_bounce_single.alpha,
                bandwidth: cpu_bounce_single.beta,
            },
            cpu_bounce: PathModel {
                latency: cpu_bounce.alpha,
                bandwidth: cpu_bounce.beta,
            },
            design1_single: PathModel {
                latency: design1_single.alpha,
                bandwidth: design1_single.beta,
            },
            design1_e2e: PathModel {
                latency: design1_e2e.alpha,
                bandwidth: design1_e2e.beta,
            },
            design2_e2e: PathModel {
                latency: design2_e2e.alpha,
                bandwidth: design2_e2e.beta,
            },
            design1_measurements: Design1Measurements {
                d2d_latency: data.design1_measurements.d2d_latency,
                driver_command_latency: data.design1_measurements.driver_command_latency,
                driver_copy_latency: data.design1_measurements.driver_copy_latency,
                sealed_bandwidth_lower_bound: data
                    .design1_measurements
                    .sealed_bandwidth_lower_bound,
            },
            design2_parameters: Design2Parameters {
                ide_operations: data.design2.ide_operations,
                ide_operation_latency: data.design2.ide_operation_latency,
                ide_latency: data.design2.ide_latency,
                esp_latency: data.design2.esp_latency,
                ide_bandwidth: data.design2.ide_bandwidth,
                esp_bandwidth: data.design2.esp_bandwidth,
            },
            copy_bandwidths: CopyBandwidths {
                confidential_cuda_dtoh: data.copy_bandwidths.confidential_cuda_dtoh,
                plain_cuda_dtoh: data.copy_bandwidths.plain_cuda_dtoh,
            },
            cpu_bounce_bandwidths: CpuBounceBandwidths {
                sender: data.cpu_bounce_bandwidths.sender,
                system_memory_rdma: data.cpu_bounce_bandwidths.system_memory_rdma,
                receiver: data.cpu_bounce_bandwidths.receiver,
            },
            cpu_bounce_latencies: CpuBounceLatencies {
                sender: data.cpu_bounce_latencies.sender,
                system_memory_rdma: data.cpu_bounce_latencies.system_memory_rdma,
                receiver: data.cpu_bounce_latencies.receiver,
            },
            gpudirect_validation: metrics(data.gdr_validation),
            cpu_bounce_validation: metrics(data.cpu_bounce_validation),
            cpu_bounce_bandwidth_validation: metrics(data.cpu_bounce_bw_validation),
            design1_validation: metrics(data.design1_validation),
            flow_completion: FlowCompletion {
                size_bytes: data.flow_completion.size_bytes,
                design1: data.flow_completion.design1,
                design2: data.flow_completion.design2,
                cpu_bounce: data.flow_completion.cpu_bounce,
                gpudirect: data.flow_completion.gdr,
            },
        })
    }
}
