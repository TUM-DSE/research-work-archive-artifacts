use std::fmt;

use crate::domain::shared_kernel::model::{Direction, MetricKind, QpCount, Verb};
use crate::libs::id::serde_id;
use crate::libs::schema::{
    styled_values_of, values_of, ColumnSchema, ColumnType, StyleToken, ValueMeta,
};
use color_eyre::eyre::bail;
use color_eyre::Result;
use std::net::IpAddr;
use strum::{AsRefStr, EnumString};

// Bandwidth curves are only comparable at this baseline
pub mod baseline {
    use crate::domain::shared_kernel::model::{Direction, QpCount};

    pub const DIRECTION: Direction = Direction::Uni;
    pub const QPS: QpCount = QpCount(1);
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum Mode {
    VmRam,
    VmGpuBB,
    VmGpuDirect,
    #[strum(serialize = "vm_gpu_direct_dmabuf")]
    VmGpuDirectDmaBuf,
    CvmRamBypass,
    CvmGpuBBBypass,
    CvmGpuBBUvmgpu,
}

impl Mode {
    pub const ALL: [Mode; 7] = [
        Mode::VmRam,
        Mode::VmGpuBB,
        Mode::VmGpuDirect,
        Mode::VmGpuDirectDmaBuf,
        Mode::CvmRamBypass,
        Mode::CvmGpuBBBypass,
        Mode::CvmGpuBBUvmgpu,
    ];

    const fn style(self) -> &'static [StyleToken] {
        match self {
            Mode::VmRam => &[StyleToken::PathHostRam, StyleToken::VariantVm],
            Mode::VmGpuBB => &[StyleToken::PathVmGpuBounce],
            Mode::VmGpuDirect | Mode::VmGpuDirectDmaBuf => &[StyleToken::PathGpuDirect],
            Mode::CvmRamBypass => &[StyleToken::PathHostRam, StyleToken::VariantCvm],
            Mode::CvmGpuBBBypass => &[StyleToken::PathCpuBounce],
            Mode::CvmGpuBBUvmgpu => &[StyleToken::PathSealedBounce],
        }
    }
}

impl fmt::Display for Mode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Mode::VmRam => "Host RAM (VM)",
            Mode::VmGpuBB => "GPU bounce buffer (VM)",
            Mode::VmGpuDirect => "GPUDirect RDMA (host)",
            Mode::VmGpuDirectDmaBuf => "GPUDirect RDMA (host)",
            Mode::CvmRamBypass => "Host RAM (CVM)",
            Mode::CvmGpuBBBypass => "GPU bounce buffer (CVM)",
            Mode::CvmGpuBBUvmgpu => "Sealed GPU bounce buffer (CVM)",
        })
    }
}

serde_id!(Mode);

impl ColumnSchema for Mode {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(styled_values_of(&Mode::ALL, Mode::style))
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum NetworkSecurity {
    #[default]
    None,
    IpsecFullOffload,
}

impl NetworkSecurity {
    // Keep the legacy variant deserializable for old records, but do not expose it as
    // a supported measurement configuration.
    pub const ALL: [NetworkSecurity; 1] = [NetworkSecurity::None];
}

impl fmt::Display for NetworkSecurity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            NetworkSecurity::None => "None",
            NetworkSecurity::IpsecFullOffload => "IPsec full offload",
        })
    }
}

serde_id!(NetworkSecurity);

impl ColumnSchema for NetworkSecurity {
    fn column_type() -> ColumnType {
        ColumnType::String
    }

    fn values() -> Option<Vec<ValueMeta>> {
        Some(values_of(&NetworkSecurity::ALL))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Transport {
    pub verb: Verb,
    pub mode: Mode,
}

impl Transport {
    pub fn resolve(verb: Verb, mode: Mode, kind: MetricKind) -> Result<Self> {
        if matches!((mode, verb), (Mode::CvmGpuBBBypass, Verb::Read)) {
            bail!("{mode} currently models the outgoing write bounce path only");
        }
        if matches!(
            (mode, verb, kind),
            (
                Mode::VmGpuDirect | Mode::VmGpuDirectDmaBuf,
                Verb::Write,
                MetricKind::Lat,
            )
        ) {
            bail!(
                "{mode} write-latency requires write-imm: GPUDirect can't sentinel-poll GPU memory"
            );
        }
        Ok(Self { verb, mode })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Profile {
    Bw {
        qps: QpCount,
        direction: Direction,
        data_validation: bool,
    },
    Lat,
}

impl Profile {
    pub fn metric_kind(&self) -> MetricKind {
        match self {
            Profile::Bw { .. } => MetricKind::Bw,
            Profile::Lat => MetricKind::Lat,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Role {
    Server,
    Client { server_ip: IpAddr },
}
