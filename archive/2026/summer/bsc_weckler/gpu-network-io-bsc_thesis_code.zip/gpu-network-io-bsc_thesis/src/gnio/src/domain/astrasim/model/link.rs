use std::fmt;

use strum::{AsRefStr, EnumString};

use crate::domain::shared_kernel::model::AlphaBeta;
use crate::libs::id::serde_id;
use crate::libs::schema::{styled_values_of, ColumnSchema, ColumnType, StyleToken, ValueMeta};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, AsRefStr, EnumString)]
#[strum(serialize_all = "snake_case")]
pub enum Design {
    #[strum(serialize = "gpudirect")]
    GpuDirect,
    CpuBounce,
    D1Single,
    #[strum(serialize = "d1_e2e")]
    D1E2e,
    #[strum(serialize = "d2_e2e")]
    D2E2e,
}

impl Design {
    pub const ALL: [Design; 5] = [
        Design::GpuDirect,
        Design::CpuBounce,
        Design::D1Single,
        Design::D1E2e,
        Design::D2E2e,
    ];

    const fn style(self) -> &'static [StyleToken] {
        match self {
            Design::GpuDirect => &[StyleToken::PathGpuDirect],
            Design::CpuBounce => &[StyleToken::PathCpuBounce],
            Design::D1Single => &[StyleToken::PathDesign1, StyleToken::VariantSingle],
            Design::D1E2e => &[StyleToken::PathDesign1, StyleToken::VariantE2e],
            Design::D2E2e => &[StyleToken::PathDesign2, StyleToken::VariantE2e],
        }
    }
}

impl fmt::Display for Design {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Design::GpuDirect => "GPUDirect",
            Design::CpuBounce => "CPU bounce",
            Design::D1Single => "Design 1 (single-sided)",
            Design::D1E2e => "Design 1 (end-to-end)",
            Design::D2E2e => "Design 2 (end-to-end)",
        })
    }
}

serde_id!(Design);

impl ColumnSchema for Design {
    fn column_type() -> ColumnType {
        ColumnType::String
    }
    fn values() -> Option<Vec<ValueMeta>> {
        Some(styled_values_of(&Design::ALL, Design::style))
    }
}

#[derive(Clone, Debug)]
pub struct Link {
    pub design: Design,
    pub ab: AlphaBeta,
}

impl Link {
    pub fn new(design: Design, ab: AlphaBeta) -> Self {
        Self { design, ab }
    }

    pub fn latency_ns(&self) -> f64 {
        self.ab.alpha.as_nanos()
    }

    pub fn bandwidth_gbps(&self) -> f64 {
        self.ab.beta.as_gbps()
    }
}
