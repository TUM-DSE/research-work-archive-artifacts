use super::config::RunConfig;
use super::primitives::{Mode, NetworkSecurity, Profile, Role, Transport};
use crate::domain::shared_kernel::model::{Direction, MetricKind, QpCount as Qps, Verb};

#[derive(Clone, Debug)]
pub enum Operation {
    Bw {
        verb: Verb,
        qps: Vec<Qps>,
        directions: Vec<Direction>,
        data_validation: bool,
    },
    Lat {
        verb: Verb,
    },
}

impl Operation {
    pub fn verb(&self) -> Verb {
        match self {
            Operation::Bw { verb, .. } => *verb,
            Operation::Lat { verb } => *verb,
        }
    }

    pub fn kind(&self) -> MetricKind {
        match self {
            Operation::Bw { .. } => MetricKind::Bw,
            Operation::Lat { .. } => MetricKind::Lat,
        }
    }
}

#[derive(Clone, Debug)]
pub struct PerftestPlan {
    pub operations: Vec<Operation>,
    pub modes: Vec<Mode>,
    pub security: NetworkSecurity,
    pub sizes: Vec<u64>,
    pub iters: u64,
    pub role: Role,
}

impl PerftestPlan {
    pub fn expand(&self) -> Vec<RunConfig> {
        let mut out = Vec::new();
        for op in &self.operations {
            for &mode in &self.modes {
                let transport = match Transport::resolve(op.verb(), mode, op.kind()) {
                    Ok(t) => t,
                    Err(_) => continue,
                };
                for &size in &self.sizes {
                    match op {
                        Operation::Lat { .. } => {
                            out.push(self.config(transport, Profile::Lat, size));
                        }
                        Operation::Bw {
                            qps,
                            directions,
                            data_validation,
                            ..
                        } => {
                            for &q in qps {
                                for &d in directions {
                                    let profile = Profile::Bw {
                                        qps: q,
                                        direction: d,
                                        data_validation: *data_validation,
                                    };
                                    out.push(self.config(transport, profile, size));
                                }
                            }
                        }
                    }
                }
            }
        }
        out
    }

    fn config(&self, transport: Transport, profile: Profile, size: u64) -> RunConfig {
        RunConfig {
            transport,
            security: self.security,
            profile,
            role: self.role.clone(),
            size_bytes: size,
            iters: self.iters,
        }
    }
}
