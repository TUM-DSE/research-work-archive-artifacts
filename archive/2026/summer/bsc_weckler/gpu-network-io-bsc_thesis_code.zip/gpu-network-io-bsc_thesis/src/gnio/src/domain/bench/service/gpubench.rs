use crate::{
    domain::bench::{
        model::gpucopy::{
            BwMeasurement, Direction, GpuCopyMeasurement, LatComponent, LatMeasurement, Mode,
            RunConfig,
        },
        repository::{NvbandwidthKind, NvbandwidthRunner},
        service::GpuBenchService,
    },
    domain::shared_kernel::model::MetricKind,
    libs::gpu::{
        cuda::CudaDevice,
        uvmgpu::{self, Mode as UvmgpuMode},
        GpuBuffer, GpuCopy, GpuDeviceCopy,
    },
};
use color_eyre::{
    eyre::{bail, eyre},
    Result,
};
use openssl::symm::{Cipher, Crypter, Mode as CipherMode};
use std::time::{Duration, Instant};

const WARMUP: u64 = 200;
const BW_ROUNDS: u64 = 5;
const UVMGPU_LAT_WARMUP: u32 = 200;
const UVMGPU_BW_WARMUP: u32 = 20;

pub struct GpuBenchServiceImpl {
    index: u32,
    cuda: Option<CudaDevice>,
    nvbw: Box<dyn NvbandwidthRunner>,
}

impl GpuBenchServiceImpl {
    pub fn new(index: u32, nvbw: Box<dyn NvbandwidthRunner>) -> Self {
        #[cfg(target_os = "linux")]
        unsafe {
            let mut cpus = std::mem::zeroed();
            libc::CPU_SET(0, &mut cpus);
            libc::sched_setaffinity(0, std::mem::size_of_val(&cpus), &cpus);
        }

        Self {
            index,
            cuda: None,
            nvbw,
        }
    }

    fn ensure_cuda(&mut self) -> Result<&CudaDevice> {
        if self.cuda.is_none() {
            self.cuda = Some(CudaDevice::open(self.index)?);
        }
        Ok(self.cuda.as_ref().unwrap())
    }

    fn bench<O: CopyOp>(mut op: O, config: &RunConfig) -> Result<GpuCopyMeasurement> {
        Self::warmup(&mut op)?;
        let iters = config.iters;
        Ok(match config.kind {
            MetricKind::Bw => {
                let mut rounds = Vec::with_capacity(BW_ROUNDS as usize);
                for _ in 0..BW_ROUNDS {
                    rounds.push(Self::time_batch(&mut op, iters)?);
                }
                GpuCopyMeasurement::Bw(BwMeasurement::from_rounds(config, iters, &rounds))
            }
            MetricKind::Lat => {
                let mut samples = Vec::with_capacity(iters as usize);
                for _ in 0..iters {
                    samples.push(Self::sample(&mut op)?);
                }
                GpuCopyMeasurement::Lat(LatMeasurement::from_samples(config, &samples))
            }
        })
    }

    fn warmup<O: CopyOp>(op: &mut O) -> Result<()> {
        for _ in 0..WARMUP {
            op.run()?;
        }
        Ok(())
    }

    fn time_batch<O: CopyOp>(op: &mut O, iters: u64) -> Result<Duration> {
        let start = Instant::now();
        for _ in 0..iters {
            op.run()?;
        }
        Ok(start.elapsed())
    }

    fn sample<O: CopyOp>(op: &mut O) -> Result<Duration> {
        let start = Instant::now();
        op.run()?;
        Ok(start.elapsed())
    }

    fn uvmgpu_bench(&self, config: &RunConfig) -> Result<Vec<GpuCopyMeasurement>> {
        let mode = uvmgpu_mode(config.mode);
        let size = usize::try_from(config.size_bytes)?;
        let iterations = u32::try_from(config.iters)?;

        Ok(match config.kind {
            MetricKind::Lat => {
                let point = uvmgpu::latency(mode, size, iterations, UVMGPU_LAT_WARMUP)?;
                let mut total = if config.mode == Mode::CvmUvmgpuCopyHtoDSealed {
                    point
                        .total
                        .iter()
                        .zip(&point.preprocess)
                        .map(|(&total, &preprocess)| {
                            total.checked_sub(preprocess).ok_or_else(|| {
                                eyre!(
                                    "uvmgpu H2D preprocessing exceeds total latency: {preprocess:?} > {total:?}"
                                )
                            })
                        })
                        .collect::<Result<Vec<_>>>()?
                } else {
                    point.total
                };
                let mut copy = point.gpu;

                if total.len() != copy.len() {
                    bail!(
                        "uvmgpu total/copy sample count mismatch: {} != {}",
                        total.len(),
                        copy.len()
                    );
                }
                total.sort_unstable();
                copy.sort_unstable();
                let sample_count = total.len();
                let paired: Vec<_> = total
                    .into_iter()
                    .zip(copy)
                    .filter(|(total, copy)| total >= copy)
                    .collect();
                if paired.len().saturating_mul(100) < sample_count.saturating_mul(99) {
                    bail!(
                        "more than 1% of uvmgpu copy quantiles exceed their total quantiles: {} of {}",
                        sample_count - paired.len(),
                        sample_count
                    );
                }

                let (total, copy): (Vec<_>, Vec<_>) = paired.into_iter().unzip();
                let command = total
                    .iter()
                    .zip(&copy)
                    .map(|(&total, &copy)| total - copy)
                    .collect();
                let components = vec![
                    (LatComponent::Total, total),
                    (LatComponent::Command, command),
                    (LatComponent::Copy, copy),
                ];

                components
                    .into_iter()
                    .map(|(component, samples)| {
                        GpuCopyMeasurement::Lat(LatMeasurement::from_component_samples(
                            config, component, &samples,
                        ))
                    })
                    .collect()
            }
            MetricKind::Bw => {
                let point = uvmgpu::bandwidth(mode, size, iterations, UVMGPU_BW_WARMUP)?;
                vec![GpuCopyMeasurement::Bw(BwMeasurement::from_rounds(
                    config,
                    point.copies,
                    &[point.gpu],
                ))]
            }
        })
    }

    fn nvbw_bench(&self, config: &RunConfig) -> Result<Vec<GpuCopyMeasurement>> {
        if config.kind != MetricKind::Bw {
            return Ok(vec![]);
        }
        let bw = self.nvbw.run(
            nvbw_kind(config.mode)?,
            config.size_bytes,
            config.iters as u32,
        )?;
        Ok(vec![GpuCopyMeasurement::Bw(BwMeasurement::from_bandwidth(
            config, bw,
        ))])
    }
}

impl GpuBenchService for GpuBenchServiceImpl {
    fn run(&mut self, config: &RunConfig) -> Result<Vec<GpuCopyMeasurement>> {
        let size = usize::try_from(config.size_bytes)?;

        match config.mode {
            Mode::VmCudaCopyDtoD | Mode::CvmCudaCopyDtoD => {
                let cuda = self.ensure_cuda()?;
                Ok(vec![Self::bench(DtoD::new(cuda, size)?, config)?])
            }
            Mode::VmCudaCopyDtoH | Mode::CvmCudaCopyDtoH => {
                let cuda = self.ensure_cuda()?;
                Ok(vec![Self::bench(DtoH::new(cuda, size)?, config)?])
            }
            Mode::VmCudaCopyHtoD | Mode::CvmCudaCopyHtoD => {
                let cuda = self.ensure_cuda()?;
                Ok(vec![Self::bench(HtoD::new(cuda, size)?, config)?])
            }
            Mode::CvmCudaCopyDtoHEncrypt => {
                let cuda = self.ensure_cuda()?;
                Ok(vec![Self::bench(DtoHEncrypt::new(cuda, size)?, config)?])
            }
            Mode::CvmCudaCopyDecryptHtoD => {
                let cuda = self.ensure_cuda()?;
                Ok(vec![Self::bench(DecryptHtoD::new(cuda, size)?, config)?])
            }
            Mode::CvmUvmgpuCopyDtoHSealed
            | Mode::CvmUvmgpuCopyHtoDSealed
            | Mode::CvmUvmgpuCopyDtoD
            | Mode::VmUvmgpuCopyDtoH
            | Mode::VmUvmgpuCopyHtoD
            | Mode::VmUvmgpuCopyDtoD => self.uvmgpu_bench(config),
            Mode::CvmNvbwCopyDtoD
            | Mode::CvmNvbwCopyHtoD
            | Mode::CvmNvbwCopyDtoH
            | Mode::VmNvbwCopyDtoD
            | Mode::VmNvbwCopyHtoD
            | Mode::VmNvbwCopyDtoH => self.nvbw_bench(config),
        }
    }
}

fn uvmgpu_mode(mode: Mode) -> UvmgpuMode {
    if mode == Mode::CvmUvmgpuCopyDtoHSealed {
        return UvmgpuMode::Seal;
    }
    if mode == Mode::CvmUvmgpuCopyHtoDSealed {
        return UvmgpuMode::Unseal;
    }

    match mode.direction() {
        Direction::DtoD => UvmgpuMode::DeviceToDevice,
        Direction::DtoH => UvmgpuMode::DeviceToHost,
        Direction::HtoD => UvmgpuMode::HostToDevice,
    }
}

fn nvbw_kind(mode: Mode) -> Result<NvbandwidthKind> {
    Ok(match mode {
        Mode::CvmNvbwCopyDtoD | Mode::VmNvbwCopyDtoD => NvbandwidthKind::DeviceLocal,
        Mode::CvmNvbwCopyDtoH | Mode::VmNvbwCopyDtoH => NvbandwidthKind::DeviceToHost,
        Mode::CvmNvbwCopyHtoD | Mode::VmNvbwCopyHtoD => NvbandwidthKind::HostToDevice,
        other => return Err(eyre!("not an nvbw mode: {other}")),
    })
}

trait CopyOp {
    fn size_bytes(&self) -> u64;
    fn run(&mut self) -> Result<()>;
}

struct HtoD<'g, G: GpuCopy> {
    device: &'g G,
    dst: G::Buffer,
    src: G::Buffer,
}

impl<'g, G: GpuCopy> HtoD<'g, G> {
    pub fn new(device: &'g G, size_bytes: usize) -> Result<Self> {
        let src = device.alloc_host(size_bytes)?;
        let dst = device.alloc_device(size_bytes)?;
        Ok(Self { device, dst, src })
    }
}

impl<G: GpuCopy> CopyOp for HtoD<'_, G> {
    fn size_bytes(&self) -> u64 {
        self.src.len() as u64
    }

    fn run(&mut self) -> Result<()> {
        self.device
            .copy_h_to_d(&self.dst, &self.src, self.size_bytes() as usize)
    }
}

struct DtoH<'g, G: GpuCopy> {
    device: &'g G,
    dst: G::Buffer,
    src: G::Buffer,
}

impl<'g, G: GpuCopy> DtoH<'g, G> {
    pub fn new(device: &'g G, size_bytes: usize) -> Result<Self> {
        let src = device.alloc_device(size_bytes)?;
        let dst = device.alloc_host(size_bytes)?;
        Ok(Self { device, dst, src })
    }
}

impl<G: GpuCopy> CopyOp for DtoH<'_, G> {
    fn size_bytes(&self) -> u64 {
        self.src.len() as u64
    }

    fn run(&mut self) -> Result<()> {
        self.device
            .copy_d_to_h(&self.dst, &self.src, self.size_bytes() as usize)
    }
}

const AES_KEY: [u8; 32] = [0x42; 32];
const AES_IV: [u8; 12] = [0x24; 12];
const AES_TAG_BYTES: usize = 16;

fn aes_encrypt(input: &[u8], output: &mut [u8], tag: &mut [u8; AES_TAG_BYTES]) -> Result<()> {
    let mut crypter = Crypter::new(
        Cipher::aes_256_gcm(),
        CipherMode::Encrypt,
        &AES_KEY,
        Some(&AES_IV),
    )?;
    crypter.pad(false);
    let mut written = crypter.update(input, output)?;
    written += crypter.finalize(&mut output[written..])?;
    if written != input.len() {
        bail!(
            "AES-GCM encrypted {written} bytes for {} bytes of input",
            input.len()
        );
    }
    crypter.get_tag(tag)?;
    Ok(())
}

fn aes_decrypt(input: &[u8], output: &mut [u8], tag: &[u8; AES_TAG_BYTES]) -> Result<()> {
    let mut crypter = Crypter::new(
        Cipher::aes_256_gcm(),
        CipherMode::Decrypt,
        &AES_KEY,
        Some(&AES_IV),
    )?;
    crypter.pad(false);
    crypter.set_tag(tag)?;
    let mut written = crypter.update(input, output)?;
    written += crypter.finalize(&mut output[written..])?;
    if written != input.len() {
        bail!(
            "AES-GCM decrypted {written} bytes for {} bytes of input",
            input.len()
        );
    }
    Ok(())
}

struct DtoHEncrypt<'g, G: GpuCopy> {
    device: &'g G,
    device_buffer: G::Buffer,
    plaintext: G::Buffer,
    ciphertext: Vec<u8>,
    tag: [u8; AES_TAG_BYTES],
    bytes: usize,
}

impl<'g, G: GpuCopy> DtoHEncrypt<'g, G> {
    fn new(device: &'g G, bytes: usize) -> Result<Self> {
        let extra = Cipher::aes_256_gcm().block_size();
        Ok(Self {
            device,
            device_buffer: device.alloc_device(bytes)?,
            plaintext: device.alloc_host(bytes + extra)?,
            ciphertext: vec![0; bytes + extra],
            tag: [0; AES_TAG_BYTES],
            bytes,
        })
    }
}

impl<G: GpuCopy> CopyOp for DtoHEncrypt<'_, G> {
    fn size_bytes(&self) -> u64 {
        self.bytes as u64
    }

    fn run(&mut self) -> Result<()> {
        self.device
            .copy_d_to_h(&self.plaintext, &self.device_buffer, self.bytes)?;
        let plaintext = unsafe {
            std::slice::from_raw_parts(
                self.plaintext
                    .host_ptr()
                    .ok_or_else(|| eyre!("CUDA plaintext buffer is not host memory"))?,
                self.bytes,
            )
        };
        aes_encrypt(plaintext, &mut self.ciphertext, &mut self.tag)
    }
}

struct DecryptHtoD<'g, G: GpuCopy> {
    device: &'g G,
    ciphertext: Vec<u8>,
    plaintext: G::Buffer,
    device_buffer: G::Buffer,
    tag: [u8; AES_TAG_BYTES],
    bytes: usize,
}

impl<'g, G: GpuCopy> DecryptHtoD<'g, G> {
    fn new(device: &'g G, bytes: usize) -> Result<Self> {
        let extra = Cipher::aes_256_gcm().block_size();
        let mut ciphertext = vec![0; bytes + extra];
        let mut tag = [0; AES_TAG_BYTES];
        aes_encrypt(&vec![0; bytes], &mut ciphertext, &mut tag)?;
        Ok(Self {
            device,
            ciphertext,
            plaintext: device.alloc_host(bytes + extra)?,
            device_buffer: device.alloc_device(bytes)?,
            tag,
            bytes,
        })
    }
}

impl<G: GpuCopy> CopyOp for DecryptHtoD<'_, G> {
    fn size_bytes(&self) -> u64 {
        self.bytes as u64
    }

    fn run(&mut self) -> Result<()> {
        let plaintext = unsafe {
            std::slice::from_raw_parts_mut(
                self.plaintext
                    .host_ptr()
                    .ok_or_else(|| eyre!("CUDA plaintext buffer is not host memory"))?,
                self.plaintext.len(),
            )
        };
        aes_decrypt(&self.ciphertext[..self.bytes], plaintext, &self.tag)?;
        self.device
            .copy_h_to_d(&self.device_buffer, &self.plaintext, self.bytes)
    }
}

struct DtoD<'g, G: GpuDeviceCopy> {
    device: &'g G,
    dst: G::Buffer,
    src: G::Buffer,
}

impl<'g, G: GpuDeviceCopy> DtoD<'g, G> {
    pub fn new(device: &'g G, size_bytes: usize) -> Result<Self> {
        let src = device.alloc_device(size_bytes)?;
        let dst = device.alloc_device(size_bytes)?;
        Ok(Self { device, dst, src })
    }
}

impl<G: GpuDeviceCopy> CopyOp for DtoD<'_, G> {
    fn size_bytes(&self) -> u64 {
        self.src.len() as u64
    }

    fn run(&mut self) -> Result<()> {
        self.device
            .copy_d_to_d(&self.dst, &self.src, self.size_bytes() as usize)
    }
}
