use crate::cli::common;
use crate::domain::bench::model::gpucopy::{GpuCopyMeasurement, Mode, RunConfig};
use crate::domain::bench::presentation::GpuCopyObserver;
use crate::domain::shared_kernel::model::MetricKind;
use crate::libs::cli::{color, table};

pub struct ConsoleObserver {
    color: bool,
    group: Option<(MetricKind, Mode)>,
}

impl ConsoleObserver {
    pub fn new() -> Self {
        Self {
            color: color::enabled(),
            group: None,
        }
    }
}

impl Default for ConsoleObserver {
    fn default() -> Self {
        Self::new()
    }
}

impl GpuCopyObserver for ConsoleObserver {
    fn on_start(&mut self, config: &RunConfig) {
        let key = (config.kind, config.mode);
        if self.group != Some(key) {
            self.group = Some(key);
            println!();
            print_group_header(config, self.color);
            println!();
            let header = match config.kind {
                MetricKind::Bw => table::header(&common::bw_cols(), self.color),
                MetricKind::Lat => table::header(&common::gpu_lat_cols(), self.color),
            };
            println!("{}", table::indent(&header, 2));
        }
    }

    fn on_measured(&mut self, measurement: &GpuCopyMeasurement) {
        let c = self.color;
        let line = match measurement {
            GpuCopyMeasurement::Bw(r) => {
                table::row(&common::bw_cols(), &common::gpu_bw_values(r), c)
            }
            GpuCopyMeasurement::Lat(r) => {
                table::row(&common::gpu_lat_cols(), &common::gpu_lat_values(r), c)
            }
        };
        println!("{}", table::indent(&line, 2));
    }
}

fn print_group_header(config: &RunConfig, c: bool) {
    let mode = config.mode.to_string();
    let kind = config.kind.to_string();
    println!(
        "  {}{}",
        color::bold(&format!("{kind}-{mode}"), c),
        color::dim(&format!("  n={}", config.iters), c)
    );
}
