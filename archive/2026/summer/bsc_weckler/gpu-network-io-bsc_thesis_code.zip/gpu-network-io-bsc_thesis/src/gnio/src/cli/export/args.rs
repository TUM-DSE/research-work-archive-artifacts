use std::path::PathBuf;

use clap::{Args, Subcommand};

#[derive(Args, Debug)]
pub struct ExportArgs {
    #[command(subcommand)]
    pub command: ExportCommand,
}

#[derive(Subcommand, Debug)]
pub enum ExportCommand {
    /// Export the model curves and Typst values used by the thesis.
    Thesis(ThesisArgs),
}

#[derive(Args, Debug)]
pub struct ThesisArgs {
    #[arg(long, default_value = "paper/thesis/data.typ")]
    pub output: PathBuf,
}
