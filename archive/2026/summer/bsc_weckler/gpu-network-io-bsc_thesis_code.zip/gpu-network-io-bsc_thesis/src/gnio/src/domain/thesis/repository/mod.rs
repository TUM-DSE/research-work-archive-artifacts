use color_eyre::eyre::Result;

use crate::domain::thesis::model::{CollectiveResults, DatapathResults, E2eResults, Evaluation};

pub trait DatapathResultsRepository {
    fn load(&self) -> Result<DatapathResults>;
}

pub trait AstraResultsRepository {
    fn load_collectives(&self) -> Result<CollectiveResults>;
    fn load_e2e(&self) -> Result<E2eResults>;
}

pub trait EvaluationRepository {
    fn save(&self, evaluation: &Evaluation) -> Result<()>;
}
