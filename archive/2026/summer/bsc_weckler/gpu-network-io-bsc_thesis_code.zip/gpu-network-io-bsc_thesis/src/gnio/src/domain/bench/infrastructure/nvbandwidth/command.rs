use std::io::Read;
use std::process::{Command, Stdio};

use color_eyre::eyre::{bail, Result, WrapErr};

use crate::domain::bench::repository::NvbandwidthKind;

const BINARY: &str = "nvbandwidth";
const MIB: u64 = 1 << 20;

pub fn test_name(kind: NvbandwidthKind) -> &'static str {
    match kind {
        NvbandwidthKind::DeviceLocal => "device_local_copy",
        NvbandwidthKind::DeviceToHost => "device_to_host_memcpy_ce",
        NvbandwidthKind::HostToDevice => "host_to_device_memcpy_ce",
    }
}

#[derive(Clone, Debug)]
pub struct CommandSpec {
    pub args: Vec<String>,
}

impl CommandSpec {
    pub fn new(kind: NvbandwidthKind, size_bytes: u64, samples: u32) -> Self {
        let mib = (size_bytes / MIB).max(1);
        Self {
            args: vec![
                "-j".into(),
                "-b".into(),
                mib.to_string(),
                "-i".into(),
                samples.to_string(),
                "-t".into(),
                test_name(kind).to_string(),
            ],
        }
    }
}

pub fn execute(spec: &CommandSpec) -> Result<String> {
    let mut cmd = Command::new(BINARY);
    cmd.args(&spec.args);
    cmd.stdout(Stdio::piped()).stderr(Stdio::inherit());
    let mut child = cmd.spawn().wrap_err_with(|| format!("spawn {BINARY}"))?;
    let mut text = String::new();
    if let Some(mut stdout) = child.stdout.take() {
        stdout.read_to_string(&mut text).wrap_err("read stdout")?;
    }
    let status = child.wait().wrap_err("wait for child")?;
    if !status.success() {
        bail!("{BINARY} exited with {status}");
    }
    Ok(text)
}
