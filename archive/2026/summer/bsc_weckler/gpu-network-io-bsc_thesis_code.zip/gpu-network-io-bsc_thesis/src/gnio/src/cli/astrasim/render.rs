use crate::domain::astrasim::model::{AstraSimResult, Collective, CollectiveImpl, Design};
use crate::domain::astrasim::presentation::ComparisonSink;
use crate::libs::cli::table::{self, DynCol};
use crate::libs::cli::{color, fmt};

pub struct ConsoleSink {
    color: bool,
    designs: Vec<Design>,
    block: Option<(String, CollectiveImpl, Collective)>,
    size: u64,
    cells: Vec<(f64, f64)>,
}

impl ConsoleSink {
    pub fn new(designs: Vec<Design>) -> Self {
        Self {
            color: color::enabled(),
            designs,
            block: None,
            size: 0,
            cells: Vec::new(),
        }
    }

    fn cols(&self) -> Vec<DynCol> {
        let col = |header: String, floor: usize, right: bool, paint: fn(&str, bool) -> String| {
            let width = header.chars().count().max(floor);
            DynCol {
                header,
                width,
                right,
                paint,
            }
        };
        let mut cols = vec![col("size".to_string(), 7, false, color::plain)];
        for d in &self.designs {
            cols.push(col(format!("{d} µs"), 10, true, color::green_bold));
            cols.push(col(format!("{d} GB/s"), 9, true, color::cyan));
        }
        for d in self.designs.iter().skip(1) {
            cols.push(col(format!("Δ {d}"), 8, true, color::magenta));
        }
        cols
    }

    fn print_header(
        &self,
        fabric: &str,
        algorithm: CollectiveImpl,
        collective: Collective,
        npus: u32,
    ) {
        let c = self.color;
        println!();
        println!(
            "  {}{}",
            color::bold(&format!("{collective} · {algorithm} · {fabric}"), c),
            color::dim(&format!("  {npus} NPUs"), c),
        );
        println!();
        println!("{}", table::indent(&table::dyn_header(&self.cols(), c), 2));
    }

    fn print_row(&self) {
        let mut v = vec![fmt::size(self.size)];
        for (compl, bw) in &self.cells {
            v.push(fmt::latency_us(*compl));
            v.push(format!("{bw:.2}"));
        }
        let base = self.cells.first().map(|(c, _)| *c).unwrap_or(0.0);
        for (compl, _) in self.cells.iter().skip(1) {
            let pct = if base > 0.0 {
                (compl - base) / base * 100.0
            } else {
                0.0
            };
            v.push(format!("{pct:+.0}%"));
        }
        println!(
            "{}",
            table::indent(&table::dyn_row(&self.cols(), &v, self.color), 2)
        );
    }
}

impl ComparisonSink for ConsoleSink {
    fn on_result(&mut self, result: &AstraSimResult) {
        let AstraSimResult::Micro(row) = result else {
            return;
        };
        let block = (row.fabric.to_id(), row.algorithm, row.collective);
        if self.block.as_ref() != Some(&block) {
            self.print_header(
                &row.fabric.to_string(),
                row.algorithm,
                row.collective,
                row.npus,
            );
            self.block = Some(block);
        }
        self.size = row.size_bytes;
        self.cells.push((row.completion_us, row.algo_bw_gbps));
        if self.cells.len() == self.designs.len() {
            self.print_row();
            self.cells.clear();
        }
    }

    fn on_failure(&mut self) {
        self.cells.clear();
    }

    fn finish(&mut self) {}
}

pub struct E2eConsoleSink {
    color: bool,
    designs: Vec<Design>,
    block: Option<(String, CollectiveImpl)>,
    workload: String,
    cells: Vec<f64>,
}

impl E2eConsoleSink {
    pub fn new(designs: Vec<Design>) -> Self {
        Self {
            color: color::enabled(),
            designs,
            block: None,
            workload: String::new(),
            cells: Vec::new(),
        }
    }

    fn cols(&self) -> Vec<DynCol> {
        let col =
            |header: String, floor: usize, right: bool, paint: fn(&str, bool) -> String| DynCol {
                width: header.chars().count().max(floor),
                header,
                right,
                paint,
            };
        let mut cols = vec![col("workload".to_string(), 28, false, color::plain)];
        for design in &self.designs {
            cols.push(col(format!("{design} µs"), 14, true, color::green_bold));
        }
        for design in self.designs.iter().skip(1) {
            cols.push(col(format!("Δ {design}"), 8, true, color::magenta));
        }
        cols
    }

    fn print_header(&self, fabric: &str, algorithm: CollectiveImpl, npus: u32) {
        let c = self.color;
        println!();
        println!(
            "  {}{}",
            color::bold(&format!("{algorithm} · {fabric}"), c),
            color::dim(&format!("  {npus} NPUs"), c),
        );
        println!();
        println!("{}", table::indent(&table::dyn_header(&self.cols(), c), 2));
    }

    fn print_row(&self) {
        let mut values = vec![self.workload.clone()];
        values.extend(self.cells.iter().map(|value| fmt::latency_us(*value)));
        let baseline = self.cells.first().copied().unwrap_or(0.0);
        values.extend(self.cells.iter().skip(1).map(|value| {
            let delta = if baseline > 0.0 {
                (value - baseline) / baseline * 100.0
            } else {
                0.0
            };
            format!("{delta:+.0}%")
        }));
        println!(
            "{}",
            table::indent(&table::dyn_row(&self.cols(), &values, self.color), 2)
        );
    }
}

impl ComparisonSink for E2eConsoleSink {
    fn on_result(&mut self, result: &AstraSimResult) {
        let AstraSimResult::E2e(row) = result else {
            return;
        };
        let block = (row.fabric.to_id(), row.algorithm);
        if self.block.as_ref() != Some(&block) {
            self.print_header(&row.fabric.to_string(), row.algorithm, row.npus);
            self.block = Some(block);
        }
        self.workload = row.trace.clone();
        self.cells.push(row.completion_us);
        if self.cells.len() == self.designs.len() {
            self.print_row();
            self.cells.clear();
        }
    }

    fn on_failure(&mut self) {
        self.cells.clear();
    }

    fn finish(&mut self) {}
}
