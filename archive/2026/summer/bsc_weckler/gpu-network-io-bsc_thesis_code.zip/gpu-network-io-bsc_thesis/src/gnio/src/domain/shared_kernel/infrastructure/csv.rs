use std::path::PathBuf;

use color_eyre::eyre::{Result, WrapErr};

use crate::domain::shared_kernel::model::{Dataset, DatasetRecord};
use crate::libs::fs;

pub struct CsvRepository {
    root: PathBuf,
}

impl CsvRepository {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    pub fn load<R: DatasetRecord>(&self) -> Result<Dataset<R>> {
        let path = self.path::<R>();
        let mut dataset = Dataset::default();
        if !path.is_file() {
            return Ok(dataset);
        }
        let mut reader =
            csv::Reader::from_path(&path).wrap_err_with(|| format!("open {}", path.display()))?;
        for record in reader.deserialize::<R>() {
            let row = record.wrap_err_with(|| format!("parse {}", path.display()))?;
            dataset.insert(row);
        }
        Ok(dataset)
    }

    pub fn save<R: DatasetRecord>(&self, dataset: &Dataset<R>) -> Result<()> {
        let mut all: Dataset<R> = self.load()?;
        all.merge(dataset.clone());
        self.write(&all)
    }

    pub fn save_replacing<R: DatasetRecord>(
        &self,
        dataset: &Dataset<R>,
        mut replaces: impl FnMut(&R) -> bool,
    ) -> Result<()> {
        let mut all: Dataset<R> = self.load()?;
        all.retain(|row| !replaces(row));
        all.merge(dataset.clone());
        self.write(&all)
    }

    fn path<R: DatasetRecord>(&self) -> PathBuf {
        self.root.join(R::IDENTITY.path())
    }

    fn write<R: DatasetRecord>(&self, dataset: &Dataset<R>) -> Result<()> {
        let mut writer = csv::Writer::from_writer(Vec::new());
        for row in dataset.iter() {
            writer.serialize(row)?;
        }
        let bytes = writer.into_inner().wrap_err("flush csv buffer")?;
        fs::atomic_write(&self.path::<R>(), &bytes)
    }
}
