/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _UAPI_DMA_HEAP_COH_H
#define _UAPI_DMA_HEAP_COH_H

#include <linux/types.h>
#include <linux/ioctl.h>

struct dc_alloc_data {
    // bytes to allocate
	__u64 len;
	// dmabuf fd
	__u32 fd;
	__u32 fd_flags;
	// must be 0
	__u64 reserved;
};

#define DC_IOC_MAGIC 'S'
#define DC_IOC_ALLOC _IOWR(DC_IOC_MAGIC, 0, struct dc_alloc_data)

#endif /* _UAPI_DMA_HEAP_COH_H */
