// SPDX-License-Identifier: GPL-2.0
#include <linux/module.h>
#include <linux/init.h>
#include <linux/dma-buf.h>
#include <linux/dma-mapping.h>
#include <linux/scatterlist.h>
#include <linux/err.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/pci.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include "dma_heap_coh_uapi.h"

#define DRV_NAME       "dma_heap/coh"
#define MELLANOX_VID   0x15B3   /* fallback PCI vendor ID — first match wins */

static char *target_bdf;
module_param(target_bdf, charp, 0444);
MODULE_PARM_DESC(target_bdf,
    "PCI BDF of the target NIC (e.g. 0000:01:00.0). "
    "If empty, the first Mellanox device found is used.");


struct dc_buffer {
	struct device   *dev;
	struct pci_dev  *pdev;
	void            *vaddr;
	dma_addr_t       dma_addr;
	size_t           size;
};


static struct pci_dev *find_target_pdev(void)
{
	struct pci_dev *pdev;

	if (target_bdf && *target_bdf) {
		unsigned int seg, bus, slot, func;

		if (sscanf(target_bdf, "%x:%x:%x.%x", &seg, &bus, &slot, &func) != 4)
			return ERR_PTR(-EINVAL);

		pdev = pci_get_domain_bus_and_slot(seg, bus, PCI_DEVFN(slot, func));
		return pdev ? pdev : ERR_PTR(-ENODEV);
	}

	pdev = pci_get_device(MELLANOX_VID, PCI_ANY_ID, NULL);
	return pdev ? pdev : ERR_PTR(-ENODEV);
}


// we don't need attachments for now because we allocate for a specific device

static int dc_dmabuf_attach(
    struct dma_buf *dmabuf,
    struct dma_buf_attachment *att
){
	return 0;
}

static void dc_dmabuf_detach(
    struct dma_buf *dmabuf,
    struct dma_buf_attachment *att
){
}

static struct sg_table *dc_dmabuf_map(struct dma_buf_attachment *att,
				      enum dma_data_direction dir)
{
	struct dc_buffer *b = att->dmabuf->priv;
	struct sg_table *sgt;
	int ret;

	if (att->dev != b->dev)
		dev_warn(att->dev, "%s: importer dev != allocator dev\n", DRV_NAME);

	sgt = kzalloc(sizeof(*sgt), GFP_KERNEL);
	if (!sgt)
		return ERR_PTR(-ENOMEM);

	ret = sg_alloc_table(sgt, 1, GFP_KERNEL);
	if (ret) {
		kfree(sgt);
		return ERR_PTR(ret);
	}

	sg_set_page(sgt->sgl, virt_to_page(b->vaddr), b->size, 0);
	sg_dma_address(sgt->sgl) = b->dma_addr;
	sg_dma_len(sgt->sgl)     = b->size;

	return sgt;
}

static void dc_dmabuf_unmap(struct dma_buf_attachment *att,
			    struct sg_table *sgt,
			    enum dma_data_direction dir)
{
	sg_free_table(sgt);
	kfree(sgt);
}

static int dc_dmabuf_mmap(struct dma_buf *dmabuf, struct vm_area_struct *vma)
{
	struct dc_buffer *b = dmabuf->priv;

	if ((vma->vm_flags & (VM_SHARED | VM_MAYSHARE)) == 0)
		return -EINVAL;

	return dma_mmap_coherent(b->dev, vma, b->vaddr, b->dma_addr, b->size);
}

static int dc_dmabuf_vmap(struct dma_buf *dmabuf, struct iosys_map *map)
{
	struct dc_buffer *b = dmabuf->priv;

	iosys_map_set_vaddr(map, b->vaddr);
	return 0;
}

static void dc_dmabuf_vunmap(struct dma_buf *dmabuf, struct iosys_map *map)
{
	iosys_map_clear(map);
}

static void dc_dmabuf_release(struct dma_buf *dmabuf)
{
	struct dc_buffer *b = dmabuf->priv;

	dma_free_coherent(b->dev, b->size, b->vaddr, b->dma_addr);
	pci_dev_put(b->pdev);
	kfree(b);
}

static const struct dma_buf_ops dc_dmabuf_ops = {
	.attach        = dc_dmabuf_attach,
	.detach        = dc_dmabuf_detach,
	.map_dma_buf   = dc_dmabuf_map,
	.unmap_dma_buf = dc_dmabuf_unmap,
	.mmap          = dc_dmabuf_mmap,
	.vmap          = dc_dmabuf_vmap,
	.vunmap        = dc_dmabuf_vunmap,
	.release       = dc_dmabuf_release,
};


static struct dma_buf *dc_allocate(unsigned long len, u32 fd_flags)
{
	DEFINE_DMA_BUF_EXPORT_INFO(exp);
	struct dc_buffer *b;
	struct pci_dev *pdev;
	struct dma_buf *dmabuf;
	size_t size = PAGE_ALIGN(len);
	int ret;

	if (!size)
		return ERR_PTR(-EINVAL);

	pdev = find_target_pdev();
	if (IS_ERR(pdev))
		return ERR_CAST(pdev);

	b = kzalloc(sizeof(*b), GFP_KERNEL);
	if (!b) {
		ret = -ENOMEM;
		goto err_putdev;
	}

	b->pdev = pdev;
	b->dev  = &pdev->dev;
	b->size = size;

	b->vaddr = dma_alloc_coherent(b->dev, size, &b->dma_addr,
				      GFP_KERNEL | __GFP_ZERO);
	if (!b->vaddr) {
		ret = -ENOMEM;
		goto err_freeb;
	}

	exp.ops      = &dc_dmabuf_ops;
	exp.size     = size;
	exp.flags    = fd_flags;
	exp.priv     = b;
	exp.exp_name = DRV_NAME;

	dmabuf = dma_buf_export(&exp);
	if (IS_ERR(dmabuf)) {
		ret = PTR_ERR(dmabuf);
		goto err_freedma;
	}

	dev_info(b->dev,
		 "%s: allocated %zu B coherent, dma_addr=0x%llx, va=%p\n",
		 DRV_NAME, size, (unsigned long long)b->dma_addr, b->vaddr);

	return dmabuf;

err_freedma:
	dma_free_coherent(b->dev, size, b->vaddr, b->dma_addr);
err_freeb:
	kfree(b);
err_putdev:
	pci_dev_put(pdev);
	return ERR_PTR(ret);
}


static long dc_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct dc_alloc_data data;
	struct dma_buf *dmabuf;
	int fd;

	switch (cmd) {
	case DC_IOC_ALLOC:
		if (copy_from_user(&data, (void __user *)arg, sizeof(data)))
			return -EFAULT;

		if (data.reserved)
			return -EINVAL;

		dmabuf = dc_allocate(data.len, data.fd_flags);
		if (IS_ERR(dmabuf))
			return PTR_ERR(dmabuf);

		fd = dma_buf_fd(dmabuf, data.fd_flags);
		if (fd < 0) {
			dma_buf_put(dmabuf);
			return fd;
		}

		data.fd = fd;
		if (copy_to_user((void __user *)arg, &data, sizeof(data))) {
			return -EFAULT;
		}
		return 0;

	default:
		return -ENOTTY;
	}
}

static const struct file_operations dc_fops = {
	.owner          = THIS_MODULE,
	.unlocked_ioctl = dc_ioctl,
	.compat_ioctl   = dc_ioctl,
	.llseek         = noop_llseek,
};

static struct miscdevice dc_miscdev = {
	.minor = MISC_DYNAMIC_MINOR,
	.name  = DRV_NAME,
	.fops  = &dc_fops,
	.mode  = 0666,
};

static int __init dc_init(void)
{
	int ret = misc_register(&dc_miscdev);

	if (ret)
		return ret;

	pr_info("%s: registered /dev/%s\n", DRV_NAME, DRV_NAME);
	return 0;
}

static void __exit dc_exit(void)
{
	misc_deregister(&dc_miscdev);
}

module_init(dc_init);
module_exit(dc_exit);

MODULE_LICENSE("GPL");
MODULE_IMPORT_NS("DMA_BUF");
MODULE_DESCRIPTION("DMA-BUF export for dma buf coherent memory");
