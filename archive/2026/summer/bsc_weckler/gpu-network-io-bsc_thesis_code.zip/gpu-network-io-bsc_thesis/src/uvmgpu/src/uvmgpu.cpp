#include "uvmgpu.hpp"
#include "dma_heap_coh_uapi.h"
#include "uvm_gnio_abi.h"

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <string>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <system_error>
#include <unistd.h>
#include <utility>

namespace uvmgpu {
namespace {

constexpr std::size_t kTimestampSlotBytes = 16;
constexpr std::size_t kTimestampValueOffset = 8;
constexpr std::size_t kTimestampBytes = UVM_GNIO_MAX_TIMESTAMPS * kTimestampSlotBytes;

[[noreturn]] void failSystem(const char* operation)
{
    throw std::system_error(errno, std::generic_category(), operation);
}

void checkStatus(const char* operation, std::uint32_t status)
{
    if (status != 0)
        throw DriverError(operation, status);
}

template <typename Params> void ioctlSubmit(int fd, unsigned command, Params& params, const char* operation)
{
    if (ioctl(fd, command, &params) != 0)
        failSystem(operation);
    checkStatus(operation, params.rmStatus);
}

void freeHandle(int fd, std::uint32_t handle) noexcept
{
    UVM_GNIO_FREE_PARAMS params{};
    params.handle = handle;
    ioctl(fd, UVM_GNIO_FREE, &params);
}

std::uint32_t allocateProtectedHandle(int fd, std::size_t bytes)
{
    UVM_GNIO_ALLOC_PROTECTED_PARAMS params{};
    params.size = bytes;
    ioctlSubmit(fd, UVM_GNIO_ALLOC_PROTECTED, params, "allocate protected region");
    return params.handle_out;
}

std::uint32_t importExposureHandle(int fd, int dmabuf_fd, std::size_t bytes)
{
    UVM_GNIO_IMPORT_EXPOSURE_PARAMS params{};
    params.dmabuf_fd = dmabuf_fd;
    params.size = bytes;
    ioctlSubmit(fd, UVM_GNIO_IMPORT_EXPOSURE, params, "import exposure region");
    return params.handle_out;
}

struct ExposureAllocation {
    int fd;
    void* data;
};

ExposureAllocation allocateExposure(std::size_t bytes)
{
    const int heap = open("/dev/dma_heap/coh", O_RDWR | O_CLOEXEC);
    if (heap < 0)
        failSystem("open coherent DMA heap");

    dc_alloc_data request{};
    request.len = bytes;
    request.fd_flags = O_RDWR | O_CLOEXEC;
    if (ioctl(heap, DC_IOC_ALLOC, &request) != 0)
        failSystem("allocate exposure region");
    close(heap);

    void* data = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_SHARED, request.fd, 0);
    if (data == MAP_FAILED)
        failSystem("map exposure region");

    return {static_cast<int>(request.fd), data};
}

} // namespace

struct Context::State {
    explicit State(int descriptor) : fd(descriptor) {}
    ~State()
    {
        if (timestamp_storage_created) {
            freeHandle(fd, timestamp_protected);
            freeHandle(fd, timestamp_plain);
        }
        if (timestamp_record_created)
            freeHandle(fd, timestamp_record);
        if (timestamp_record_data)
            munmap(timestamp_record_data, timestamp_record_bytes);
        if (timestamp_plain_data)
            munmap(timestamp_plain_data, kTimestampBytes);
        if (timestamp_record_fd >= 0)
            close(timestamp_record_fd);
        if (timestamp_plain_fd >= 0)
            close(timestamp_plain_fd);
        close(fd);
    }

    void createTimestampStorage()
    {
        if (timestamp_storage_created)
            return;

        timestamp_protected = allocateProtectedHandle(fd, kTimestampBytes);

        const auto plain = allocateExposure(kTimestampBytes);
        timestamp_plain_fd = plain.fd;
        timestamp_plain_data = plain.data;
        timestamp_plain = importExposureHandle(fd, timestamp_plain_fd, kTimestampBytes);
        timestamp_storage_created = true;
    }

    void createTimestampRecord()
    {
        if (timestamp_record_created)
            return;

        timestamp_record_bytes = uvm_gnio_record_bytes(kTimestampBytes);
        const auto record = allocateExposure(timestamp_record_bytes);
        timestamp_record_fd = record.fd;
        timestamp_record_data = record.data;
        timestamp_record = importExposureHandle(fd, timestamp_record_fd, timestamp_record_bytes);
        timestamp_record_created = true;
    }

    int fd;
    bool confidential = false;
    bool timestamp_storage_created = false;
    bool timestamp_record_created = false;
    std::uint32_t timestamp_protected = 0;
    std::uint32_t timestamp_record = 0;
    std::uint32_t timestamp_plain = 0;
    int timestamp_record_fd = -1;
    int timestamp_plain_fd = -1;
    void* timestamp_record_data = nullptr;
    void* timestamp_plain_data = nullptr;
    std::size_t timestamp_record_bytes = 0;
};

DriverError::DriverError(const char* operation, std::uint32_t status) : std::runtime_error(std::string(operation) + " failed with NV_STATUS " + std::to_string(status)), status_(status)
{}

Context Context::attachCuda(int cuda_uvm_fd)
{
    if (cuda_uvm_fd < 0)
        throw std::invalid_argument("invalid CUDA UVM descriptor");

    const int fd = fcntl(cuda_uvm_fd, F_DUPFD_CLOEXEC, 0);
    if (fd < 0)
        failSystem("duplicate CUDA UVM descriptor");
    return Context(std::make_shared<State>(fd));
}

ProtectedRegion Context::createProtectedRegion(std::size_t bytes) const
{
    return ProtectedRegion(state_, allocateProtectedHandle(state_->fd, bytes), bytes);
}

ExposureRegion Context::createExposureRegion(std::size_t bytes) const
{
    const auto allocation = allocateExposure(bytes);
    return ExposureRegion(state_, importExposureHandle(state_->fd, allocation.fd, bytes), bytes, allocation.fd, allocation.data);
}

ExposureRegion Context::importExposure(int dmabuf_fd, std::size_t bytes) const
{
    return ExposureRegion(state_, importExposureHandle(state_->fd, dmabuf_fd, bytes), bytes);
}

Push Context::push() const
{
    return Push(state_);
}

SecureChannel Context::secureChannel() const
{
    return SecureChannel(state_);
}

ProtectedRegion::ProtectedRegion(std::shared_ptr<Context::State> state, std::uint32_t handle, std::size_t size) : state_(std::move(state)), handle_(handle), size_(size), valid_(true)
{}

ProtectedRegion::~ProtectedRegion()
{
    reset();
}

ProtectedRegion::ProtectedRegion(ProtectedRegion&& other) noexcept : state_(std::move(other.state_)), handle_(other.handle_), size_(std::exchange(other.size_, 0)), valid_(std::exchange(other.valid_, false)), mapped_(std::exchange(other.mapped_, false))
{}

ProtectedRegion& ProtectedRegion::operator=(ProtectedRegion&& other) noexcept
{
    if (this != &other) {
        reset();
        state_ = std::move(other.state_);
        handle_ = other.handle_;
        size_ = std::exchange(other.size_, 0);
        valid_ = std::exchange(other.valid_, false);
        mapped_ = std::exchange(other.mapped_, false);
    }
    return *this;
}

void ProtectedRegion::map(std::uint64_t cuda_va)
{
    UVM_GNIO_MAP_PROTECTED_PARAMS params{};
    params.handle = handle_;
    params.user_va = cuda_va;
    ioctlSubmit(state_->fd, UVM_GNIO_MAP_PROTECTED, params, "map protected region");
    mapped_ = true;
}

void ProtectedRegion::unmap()
{
    if (!mapped_)
        return;

    UVM_GNIO_UNMAP_PROTECTED_PARAMS params{};
    params.handle = handle_;
    ioctlSubmit(state_->fd, UVM_GNIO_UNMAP_PROTECTED, params, "unmap protected region");
    mapped_ = false;
}

void ProtectedRegion::reset() noexcept
{
    if (!state_ || !valid_)
        return;

    if (mapped_) {
        UVM_GNIO_UNMAP_PROTECTED_PARAMS params{};
        params.handle = handle_;
        ioctl(state_->fd, UVM_GNIO_UNMAP_PROTECTED, &params);
    }
    freeHandle(state_->fd, handle_);
    valid_ = false;
    mapped_ = false;
}

ExposureRegion::ExposureRegion(std::shared_ptr<Context::State> state, std::uint32_t handle, std::size_t size, int owned_fd, void* data) : state_(std::move(state)), handle_(handle), size_(size), owned_fd_(owned_fd), data_(data), valid_(true)
{}

ExposureRegion::~ExposureRegion()
{
    reset();
}

ExposureRegion::ExposureRegion(ExposureRegion&& other) noexcept : state_(std::move(other.state_)), handle_(other.handle_), size_(std::exchange(other.size_, 0)), owned_fd_(std::exchange(other.owned_fd_, -1)), data_(std::exchange(other.data_, nullptr)), valid_(std::exchange(other.valid_, false))
{}

ExposureRegion& ExposureRegion::operator=(ExposureRegion&& other) noexcept
{
    if (this != &other) {
        reset();
        state_ = std::move(other.state_);
        handle_ = other.handle_;
        size_ = std::exchange(other.size_, 0);
        owned_fd_ = std::exchange(other.owned_fd_, -1);
        data_ = std::exchange(other.data_, nullptr);
        valid_ = std::exchange(other.valid_, false);
    }
    return *this;
}

void ExposureRegion::reset() noexcept
{
    if (!state_ || !valid_)
        return;
    freeHandle(state_->fd, handle_);
    if (data_)
        munmap(data_, size_);
    if (owned_fd_ >= 0)
        close(owned_fd_);
    valid_ = false;
    data_ = nullptr;
    owned_fd_ = -1;
}

void Push::requireContext(const std::shared_ptr<Context::State>& state) const
{
    if (state != state_)
        throw std::invalid_argument("push regions belong to different contexts");
}

Push& Push::semaphoreAcquire(const ProtectedRegion& semaphore, std::uint64_t offset, std::uint32_t value)
{
    requireContext(semaphore.state_);
    Operation operation{};
    operation.type = UVM_GNIO_OP_SEMAPHORE_ACQUIRE;
    operation.source_handle = semaphore.handle_;
    operation.source_offset = offset;
    operation.value = value;
    operations_.push_back(operation);
    return *this;
}

Push& Push::semaphoreRelease(const ProtectedRegion& semaphore, std::uint64_t offset, std::uint32_t value)
{
    requireContext(semaphore.state_);
    Operation operation{};
    operation.type = UVM_GNIO_OP_SEMAPHORE_RELEASE;
    operation.source_handle = semaphore.handle_;
    operation.source_offset = offset;
    operation.value = value;
    operations_.push_back(operation);
    return *this;
}

Push& Push::encrypt(const ExposureRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_ENCRYPT, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Push& Push::unseal(const ExposureRegion& source, std::uint64_t source_offset, const ProtectedRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_UNSEAL, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Push& Push::seal(const ProtectedRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_SEAL, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Push& Push::decrypt(const ExposureRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_DECRYPT, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Push& Push::addOperation(std::uint32_t type, std::uint32_t source, std::uint64_t source_offset, std::uint32_t destination, std::uint64_t destination_offset, std::size_t bytes)
{
    Operation operation{};
    operation.type = type;
    operation.source_handle = source;
    operation.destination_handle = destination;
    operation.source_offset = source_offset;
    operation.destination_offset = destination_offset;
    operation.size = bytes;
    operations_.push_back(operation);
    return *this;
}

Push& Push::copy(const ProtectedRegion& source, std::uint64_t source_offset, const ProtectedRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_COPY, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Push& Push::copy(const ProtectedRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_COPY, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Push& Push::copy(const ExposureRegion& source, std::uint64_t source_offset, const ProtectedRegion& destination, std::uint64_t destination_offset, std::size_t bytes)
{
    requireContext(source.state_);
    requireContext(destination.state_);
    return addOperation(UVM_GNIO_OP_COPY, source.handle_, source_offset, destination.handle_, destination_offset, bytes);
}

Timestamp Push::timestamp()
{
    Operation operation{};
    operation.type = UVM_GNIO_OP_TIMESTAMP;
    operation.result_index = timestamp_count_++;
    operations_.push_back(operation);
    return Timestamp{operation.result_index};
}

PushResult Push::submitRaw(const std::vector<Operation>& operations) const
{
    UVM_GNIO_SUBMIT_PARAMS params{};
    params.abi_version = UVM_GNIO_SUBMIT_ABI_VERSION;
    params.op_count = static_cast<std::uint32_t>(operations.size());

    for (std::size_t i = 0; i < operations.size(); ++i) {
        const Operation& source = operations[i];
        UVM_GNIO_PUSH_OP& destination = params.ops[i];
        destination.type = source.type;
        destination.source_handle = source.source_handle;
        destination.destination_handle = source.destination_handle;
        destination.source_offset = source.source_offset;
        destination.destination_offset = source.destination_offset;
        destination.size = source.size;
        destination.value = source.value;
    }

    ioctlSubmit(state_->fd, UVM_GNIO_SUBMIT, params, "submit push");
    state_->confidential = params.confidential;

    PushResult result;
    result.total_ns = params.total_ns;
    result.preprocess_ns = params.preprocess_ns;
    result.postprocess_ns = params.postprocess_ns;
    return result;
}

PushResult Push::submit() const
{
    if (operations_.size() > UVM_GNIO_MAX_OPS || timestamp_count_ > UVM_GNIO_MAX_TIMESTAMPS)
        throw std::length_error("push is too large");

    if (timestamp_count_ == 0)
        return submitRaw(operations_);

    state_->createTimestampStorage();

    std::vector<Operation> measured = operations_;
    for (Operation& operation : measured) {
        if (operation.type == UVM_GNIO_OP_TIMESTAMP) {
            operation.destination_handle = state_->timestamp_protected;
            operation.destination_offset = operation.result_index * kTimestampSlotBytes;
        }
    }

    PushResult result = submitRaw(measured);
    const std::size_t bytes = timestamp_count_ * kTimestampSlotBytes;

    std::vector<Operation> readback;
    if (state_->confidential) {
        state_->createTimestampRecord();

        Operation seal{};
        seal.type = UVM_GNIO_OP_SEAL;
        seal.source_handle = state_->timestamp_protected;
        seal.destination_handle = state_->timestamp_record;
        seal.size = bytes;
        readback.push_back(seal);

        Operation decrypt{};
        decrypt.type = UVM_GNIO_OP_DECRYPT;
        decrypt.source_handle = state_->timestamp_record;
        decrypt.destination_handle = state_->timestamp_plain;
        decrypt.size = bytes;
        readback.push_back(decrypt);
    } else {
        Operation copy{};
        copy.type = UVM_GNIO_OP_COPY;
        copy.source_handle = state_->timestamp_protected;
        copy.destination_handle = state_->timestamp_plain;
        copy.size = bytes;
        readback.push_back(copy);
    }

    submitRaw(readback);

    const auto* plain = static_cast<const std::uint8_t*>(state_->timestamp_plain_data);
    result.timestamps.resize(timestamp_count_);
    for (std::size_t i = 0; i < timestamp_count_; ++i) {
        std::memcpy(&result.timestamps[i], plain + i * kTimestampSlotBytes + kTimestampValueOffset, sizeof(result.timestamps[i]));
    }

    return result;
}

void SecureChannel::seal(const Seal& operation) const
{
    Push push(state_);
    push.semaphoreAcquire(operation.semaphore, operation.acquire_offset, operation.acquire_value).seal(operation.source, operation.source_offset, operation.destination, operation.destination_offset, operation.bytes).semaphoreRelease(operation.semaphore, operation.release_offset, operation.release_value).submit();
}

std::size_t SecureChannel::recordBytes(std::size_t plaintext_bytes) noexcept
{
    if (plaintext_bytes == 0 || plaintext_bytes > std::numeric_limits<std::uint32_t>::max())
        return 0;

    const auto bytes = uvm_gnio_record_bytes(plaintext_bytes);
    if (bytes > std::numeric_limits<std::size_t>::max())
        return 0;
    return static_cast<std::size_t>(bytes);
}

} // namespace uvmgpu
