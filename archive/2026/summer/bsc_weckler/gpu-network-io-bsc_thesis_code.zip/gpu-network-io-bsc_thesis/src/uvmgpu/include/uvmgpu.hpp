#ifndef UVMGPU_HPP
#define UVMGPU_HPP

#include <cstddef>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <vector>

namespace uvmgpu {

class DriverError : public std::runtime_error {
public:
    DriverError(const char* operation, std::uint32_t status);
    std::uint32_t status() const noexcept { return status_; }

private:
    std::uint32_t status_;
};

class ProtectedRegion;
class ExposureRegion;
class SecureChannel;
class Push;

class Context {
public:
    // Duplicate an initialized CUDA /dev/nvidia-uvm descriptor. The caller keeps
    // ownership of cuda_uvm_fd. Destroy all regions before CUDA device teardown.
    static Context attachCuda(int cuda_uvm_fd);

    ProtectedRegion createProtectedRegion(std::size_t bytes) const;
    ExposureRegion createExposureRegion(std::size_t bytes) const;
    // The caller owns synchronization and must provide one CPU-coherent,
    // contiguous DMA-BUF mapping for the lifetime of the returned region.
    ExposureRegion importExposure(int dmabuf_fd, std::size_t bytes) const;
    Push push() const;
    SecureChannel secureChannel() const;

private:
    struct State;
    explicit Context(std::shared_ptr<State> state) : state_(std::move(state)) {}

    std::shared_ptr<State> state_;
    friend class ProtectedRegion;
    friend class ExposureRegion;
    friend class SecureChannel;
    friend class Push;
};

class ProtectedRegion {
public:
    ~ProtectedRegion();
    ProtectedRegion(ProtectedRegion&& other) noexcept;
    ProtectedRegion& operator=(ProtectedRegion&& other) noexcept;
    ProtectedRegion(const ProtectedRegion&) = delete;
    ProtectedRegion& operator=(const ProtectedRegion&) = delete;

    void map(std::uint64_t cuda_va);
    void unmap();
    std::size_t size() const noexcept { return size_; }

private:
    ProtectedRegion(std::shared_ptr<Context::State> state, std::uint32_t handle, std::size_t size);
    void reset() noexcept;

    std::shared_ptr<Context::State> state_;
    std::uint32_t handle_ = 0;
    std::size_t size_ = 0;
    bool valid_ = false;
    bool mapped_ = false;

    friend class Context;
    friend class SecureChannel;
    friend class Push;
};

class ExposureRegion {
public:
    ~ExposureRegion();
    ExposureRegion(ExposureRegion&& other) noexcept;
    ExposureRegion& operator=(ExposureRegion&& other) noexcept;
    ExposureRegion(const ExposureRegion&) = delete;
    ExposureRegion& operator=(const ExposureRegion&) = delete;

    std::size_t size() const noexcept { return size_; }
    void* data() noexcept { return data_; }
    const void* data() const noexcept { return data_; }

private:
    ExposureRegion(std::shared_ptr<Context::State> state, std::uint32_t handle, std::size_t size, int owned_fd = -1, void* data = nullptr);
    void reset() noexcept;

    std::shared_ptr<Context::State> state_;
    std::uint32_t handle_ = 0;
    std::size_t size_ = 0;
    int owned_fd_ = -1;
    void* data_ = nullptr;
    bool valid_ = false;

    friend class Context;
    friend class SecureChannel;
    friend class Push;
};

struct Seal {
    const ProtectedRegion& source;
    std::uint64_t source_offset;
    const ExposureRegion& destination;
    std::uint64_t destination_offset;
    std::size_t bytes;
    const ProtectedRegion& semaphore;
    std::uint64_t acquire_offset;
    std::uint32_t acquire_value;
    std::uint64_t release_offset;
    std::uint32_t release_value;
};

struct Timestamp {
    std::uint32_t index;
};

struct PushResult {
    std::vector<std::uint64_t> timestamps;
    std::uint64_t total_ns = 0;
    std::uint64_t preprocess_ns = 0;
    std::uint64_t postprocess_ns = 0;

    std::uint64_t value(Timestamp timestamp) const { return timestamps.at(timestamp.index); }
    std::uint64_t elapsed(Timestamp begin, Timestamp end) const { return value(end) - value(begin); }
};

class Push {
public:
    Push& semaphoreAcquire(const ProtectedRegion& semaphore, std::uint64_t offset, std::uint32_t value);
    Push& semaphoreRelease(const ProtectedRegion& semaphore, std::uint64_t offset, std::uint32_t value);

    Push& encrypt(const ExposureRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes);
    Push& unseal(const ExposureRegion& source, std::uint64_t source_offset, const ProtectedRegion& destination, std::uint64_t destination_offset, std::size_t bytes);
    Push& seal(const ProtectedRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes);
    Push& decrypt(const ExposureRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes);

    Push& copy(const ProtectedRegion& source, std::uint64_t source_offset, const ProtectedRegion& destination, std::uint64_t destination_offset, std::size_t bytes);
    Push& copy(const ProtectedRegion& source, std::uint64_t source_offset, const ExposureRegion& destination, std::uint64_t destination_offset, std::size_t bytes);
    Push& copy(const ExposureRegion& source, std::uint64_t source_offset, const ProtectedRegion& destination, std::uint64_t destination_offset, std::size_t bytes);

    Timestamp timestamp();
    PushResult submit() const;

private:
    struct Operation {
        std::uint32_t type = 0;
        std::uint32_t result_index = 0;
        std::uint32_t source_handle = 0;
        std::uint32_t destination_handle = 0;
        std::uint64_t source_offset = 0;
        std::uint64_t destination_offset = 0;
        std::uint64_t size = 0;
        std::uint32_t value = 0;
        std::uint32_t reserved = 0;
    };

    explicit Push(std::shared_ptr<Context::State> state) : state_(std::move(state)) {}
    void requireContext(const std::shared_ptr<Context::State>& state) const;
    Push& addOperation(std::uint32_t type, std::uint32_t source, std::uint64_t source_offset, std::uint32_t destination, std::uint64_t destination_offset, std::size_t bytes);
    PushResult submitRaw(const std::vector<Operation>& operations) const;

    std::shared_ptr<Context::State> state_;
    std::vector<Operation> operations_;
    std::uint32_t timestamp_count_ = 0;
    friend class Context;
    friend class SecureChannel;
};

class SecureChannel {
public:
    void seal(const Seal& operation) const;
    static std::size_t recordBytes(std::size_t plaintext_bytes) noexcept;

private:
    explicit SecureChannel(std::shared_ptr<Context::State> state) : state_(std::move(state)) {}

    std::shared_ptr<Context::State> state_;
    friend class Context;
};

} // namespace uvmgpu

#endif // UVMGPU_HPP
