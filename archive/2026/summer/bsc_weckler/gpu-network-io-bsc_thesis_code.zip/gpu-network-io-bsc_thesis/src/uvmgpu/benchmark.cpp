#include "uvm_gnio_abi.h"
#include "uvmgpu.hpp"

#include <cuda.h>
#include <cuda_runtime.h>

#include <dirent.h>
#include <unistd.h>

#include <algorithm>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

enum class Mode {
    Seal,
    Unseal,
    DeviceToDevice,
    DeviceToHost,
    HostToDevice,
};

enum class Metric {
    Latency,
    Bandwidth,
};

struct Arguments {
    Mode mode;
    Metric metric;
    std::size_t size;
    std::uint32_t iterations;
    std::uint32_t warmup;
};

class Benchmark {
public:
    Benchmark(Arguments arguments, uvmgpu::Context context) : args_(arguments), ctx_(std::move(context))
    {
        if (args_.metric == Metric::Bandwidth) {
            const std::uint32_t operationsPerCopy = args_.mode == Mode::Unseal ? 2 : 1;
            const std::uint32_t maxCopies = (UVM_GNIO_MAX_OPS - 2) / operationsPerCopy;
            const std::uint32_t maxWarmup = UVM_GNIO_MAX_OPS / operationsPerCopy;

            if (args_.iterations > maxCopies)
                throw std::length_error("bandwidth iterations exceed push capacity");
            if (args_.warmup > maxWarmup)
                throw std::length_error("bandwidth warmup exceeds push capacity");
        }

        switch (args_.mode) {
            case Mode::Seal:
                createRecordRing(false);
                protSrc = std::make_unique<uvmgpu::ProtectedRegion>(ctx_.createProtectedRegion(args_.size));
                break;
            case Mode::Unseal:
                createRecordRing(true);
                expSrc = std::make_unique<uvmgpu::ExposureRegion>(ctx_.createExposureRegion(args_.size));
                protDest = std::make_unique<uvmgpu::ProtectedRegion>(ctx_.createProtectedRegion(args_.size));
                break;
            case Mode::DeviceToDevice:
                protSrc = std::make_unique<uvmgpu::ProtectedRegion>(ctx_.createProtectedRegion(args_.size));
                protDest = std::make_unique<uvmgpu::ProtectedRegion>(ctx_.createProtectedRegion(args_.size));
                break;
            case Mode::DeviceToHost:
                protSrc = std::make_unique<uvmgpu::ProtectedRegion>(ctx_.createProtectedRegion(args_.size));
                expDst = std::make_unique<uvmgpu::ExposureRegion>(ctx_.createExposureRegion(args_.size));
                break;
            case Mode::HostToDevice:
                expSrc = std::make_unique<uvmgpu::ExposureRegion>(ctx_.createExposureRegion(args_.size));
                protDest = std::make_unique<uvmgpu::ProtectedRegion>(ctx_.createProtectedRegion(args_.size));
                break;
        }
    }

    void run()
    {
        if (args_.metric == Metric::Latency)
            runLatency();
        else
            runBandwidth();
    }

private:
    uvmgpu::Push newPush() const { return ctx_.push(); }

    void createRecordRing(bool batch)
    {
        recordBytes_ = uvmgpu::SecureChannel::recordBytes(args_.size);
        const std::uint32_t recordCount = batch && args_.metric == Metric::Bandwidth ? std::max({args_.iterations, args_.warmup, 1u}) : 1;
        recordRing = std::make_unique<uvmgpu::ExposureRegion>(ctx_.createExposureRegion(recordBytes_ * recordCount));
    }

    void addOperation(uvmgpu::Push& push, std::uint32_t index = 0) const
    {
        switch (args_.mode) {
            case Mode::Seal:
                push.seal(*protSrc, 0, *recordRing, 0, args_.size);
                break;
            case Mode::Unseal: {
                const std::size_t recordOffset = index * recordBytes_;
                push.encrypt(*expSrc, 0, *recordRing, recordOffset, args_.size).unseal(*recordRing, recordOffset, *protDest, 0, args_.size);
                break;
            }
            case Mode::DeviceToDevice:
                push.copy(*protSrc, 0, *protDest, 0, args_.size);
                break;
            case Mode::DeviceToHost:
                push.copy(*protSrc, 0, *expDst, 0, args_.size);
                break;
            case Mode::HostToDevice:
                push.copy(*expSrc, 0, *protDest, 0, args_.size);
                break;
        }
    }

    void runLatency()
    {
        for (std::uint32_t i = 0; i < args_.warmup; ++i) {
            auto push = newPush();
            addOperation(push);
            push.submit();
        }

        std::vector<std::uint64_t> total;
        std::vector<std::uint64_t> preprocess;
        std::vector<std::uint64_t> gpu;
        total.reserve(args_.iterations);
        preprocess.reserve(args_.iterations);
        gpu.reserve(args_.iterations);

        for (std::uint32_t i = 0; i < args_.iterations; ++i) {
            auto totalPush = newPush();
            addOperation(totalPush);
            const auto totalResult = totalPush.submit();
            total.push_back(totalResult.total_ns);
            preprocess.push_back(totalResult.preprocess_ns);

            auto timedPush = newPush();
            const auto begin = timedPush.timestamp();
            addOperation(timedPush);
            const auto end = timedPush.timestamp();
            const auto timedResult = timedPush.submit();
            gpu.push_back(timedResult.elapsed(begin, end));
        }

        std::printf("{\"metric\":\"lat\",\"total_ns\":");
        printArray(total);
        std::printf(",\"preprocess_ns\":");
        printArray(preprocess);
        std::printf(",\"gpu_ns\":");
        printArray(gpu);
        std::puts("}");
    }

    void runBandwidth()
    {
        if (args_.warmup != 0) {
            auto push = newPush();
            for (std::uint32_t i = 0; i < args_.warmup; ++i)
                addOperation(push, i);
            push.submit();
        }

        auto push = newPush();
        const auto begin = push.timestamp();
        for (std::uint32_t i = 0; i < args_.iterations; ++i)
            addOperation(push, i);
        const auto end = push.timestamp();
        const auto result = push.submit();

        std::printf("{\"metric\":\"bw\",\"copies\":%u,\"gpu_ns\":%llu}\n", args_.iterations, static_cast<unsigned long long>(result.elapsed(begin, end)));
    }

    static void printArray(const std::vector<std::uint64_t>& values)
    {
        std::putchar('[');
        for (std::size_t i = 0; i < values.size(); ++i) {
            if (i != 0)
                std::putchar(',');
            std::printf("%llu", static_cast<unsigned long long>(values[i]));
        }
        std::putchar(']');
    }

    Arguments args_;
    uvmgpu::Context ctx_;

    std::unique_ptr<uvmgpu::ProtectedRegion> protSrc;
    std::unique_ptr<uvmgpu::ProtectedRegion> protDest;
    std::unique_ptr<uvmgpu::ExposureRegion> expSrc;
    std::unique_ptr<uvmgpu::ExposureRegion> expDst;
    std::unique_ptr<uvmgpu::ExposureRegion> recordRing;
    std::size_t recordBytes_ = 0;
};

int findCudaUvmFd()
{
    DIR* directory = opendir("/proc/self/fd");
    if (!directory)
        return -1;

    int result = -1;
    char link[300];
    char target[256];
    while (dirent* entry = readdir(directory)) {
        std::snprintf(link, sizeof(link), "/proc/self/fd/%s", entry->d_name);
        const ssize_t size = readlink(link, target, sizeof(target) - 1);
        if (size > 0) {
            target[size] = '\0';
            if (std::strcmp(target, "/dev/nvidia-uvm") == 0) {
                result = std::atoi(entry->d_name);
                break;
            }
        }
    }

    closedir(directory);
    return result;
}

Arguments parseArguments(int argc, char** argv)
{
    if (argc != 6)
        throw std::invalid_argument("usage: uvmgpu_bench MODE lat|bw SIZE ITERATIONS WARMUP");

    Mode mode;
    if (std::strcmp(argv[1], "seal") == 0)
        mode = Mode::Seal;
    else if (std::strcmp(argv[1], "unseal") == 0)
        mode = Mode::Unseal;
    else if (std::strcmp(argv[1], "dtod") == 0)
        mode = Mode::DeviceToDevice;
    else if (std::strcmp(argv[1], "dtoh") == 0)
        mode = Mode::DeviceToHost;
    else if (std::strcmp(argv[1], "htod") == 0)
        mode = Mode::HostToDevice;
    else
        throw std::invalid_argument("mode must be seal, unseal, dtod, dtoh, or htod");

    Metric metric;
    if (std::strcmp(argv[2], "lat") == 0)
        metric = Metric::Latency;
    else if (std::strcmp(argv[2], "bw") == 0)
        metric = Metric::Bandwidth;
    else
        throw std::invalid_argument("metric must be lat or bw");

    return {
        mode,
        metric,
        std::stoull(argv[3]),
        static_cast<std::uint32_t>(std::stoul(argv[4])),
        static_cast<std::uint32_t>(std::stoul(argv[5])),
    };
}

} // namespace

int main(int argc, char** argv)
{
    try {
        const Arguments arguments = parseArguments(argc, argv);
        if (cuInit(0) != CUDA_SUCCESS || cudaSetDevice(0) != cudaSuccess)
            throw std::runtime_error("CUDA initialization failed");

        void* initializeUvm = nullptr;
        if (cudaMallocManaged(&initializeUvm, 4096) != cudaSuccess)
            throw std::runtime_error("CUDA UVM initialization failed");

        const int uvmFd = findCudaUvmFd();
        if (uvmFd < 0)
            throw std::runtime_error("CUDA UVM descriptor not found");

        {
            Benchmark benchmark(arguments, uvmgpu::Context::attachCuda(uvmFd));
            benchmark.run();
        }

        cudaFree(initializeUvm);
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "uvmgpu_bench: %s\n", error.what());
        return 1;
    }
}
